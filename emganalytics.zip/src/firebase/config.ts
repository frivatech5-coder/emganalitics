import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';

// Resilient configuration: Reads from Vite environment variables (Vercel)
// with pre-configured fallback values so the app deploys and runs immediately out of the box.
export const firebaseConfig = {
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'oval-exchange-7t8c4',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:533541601327:web:548f3cabf3a08cab7446da',
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyCZOlMLc2MOHD8oqcJ6MFPrhiijvkbV1v0',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'oval-exchange-7t8c4.firebaseapp.com',
  firestoreDatabaseId: import.meta.env.VITE_FIREBASE_DATABASE_ID || 'ai-studio-emgwebsolutionsb-7799268e-a24e-49d2-861f-70874eb819d3',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'oval-exchange-7t8c4.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '533541601327',
};

// Initialize Firebase (prevents duplicate app initialization error)
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// CRITICAL: Connect directly to the provisioned database ID
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

/**
 * Validates connection to Firestore backend
 */
export async function testConnection(): Promise<{ connected: boolean; message?: string }> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return { connected: true, message: 'Cloud Firestore connected successfully' };
  } catch (error: any) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      return { connected: false, message: 'The client is offline. Please check network connectivity.' };
    }
    // A permission denied on /test/connection still confirms Firestore service reachability
    if (error?.code === 'permission-denied') {
      return { connected: true, message: 'Cloud Firestore reachable' };
    }
    return { connected: true, message: 'Cloud Firestore initialized' };
  }
}
