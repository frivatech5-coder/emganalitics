/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardView } from './components/dashboard/DashboardView';
import { LeadsView } from './components/leads/LeadsView';
import { LeadModal } from './components/leads/LeadModal';
import { LeadDetailsDrawer } from './components/leads/LeadDetailsDrawer';
import { LeadImportExportModal } from './components/leads/LeadImportExportModal';
import { FollowUpsView } from './components/followups/FollowUpsView';
import { QuotationsView } from './components/quotations/QuotationsView';
import { QuotationModal } from './components/quotations/QuotationModal';
import { QuotationPrintView } from './components/quotations/QuotationPrintView';
import { PackagesModal } from './components/quotations/PackagesModal';
import { ClientsView } from './components/clients/ClientsView';
import { ClientModal } from './components/clients/ClientModal';
import { PaymentsView } from './components/payments/PaymentsView';
import { PaymentModal } from './components/payments/PaymentModal';
import { MaintenanceView } from './components/maintenance/MaintenanceView';
import { SubscriptionModal } from './components/maintenance/SubscriptionModal';
import { PortfolioView } from './components/portfolio/PortfolioView';
import { PortfolioModal } from './components/portfolio/PortfolioModal';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import {
  Lead,
  ContactLog,
  ServicePackage,
  Quotation,
  QuotationStatus,
  Client,
  Project,
  Payment,
  Subscription,
  PortfolioItem,
  LeadStatus,
  ContactChannel,
} from './types';
import {
  subscribeToLeads,
  subscribeToContactLogs,
  subscribeToPackages,
  subscribeToQuotations,
  subscribeToClients,
  subscribeToProjects,
  subscribeToPayments,
  subscribeToSubscriptions,
  subscribeToPortfolio,
  saveLead,
  deleteLead,
  addContactLog,
  saveQuotation,
  deleteQuotation,
  saveClient,
  deleteClient,
  convertLeadToClient,
  savePayment,
  deletePayment,
  saveSubscription,
  deleteSubscription,
  savePortfolioItem,
  deletePortfolioItem,
} from './services/db';

function MainApp() {
  const { user, loading, loginWithGoogle, firestoreConnected } = useAuth();

  // Navigation State
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Data Collections State (Persistent Cloud Firestore)
  const [leads, setLeads] = useState<Lead[]>([]);
  const [contactLogs, setContactLogs] = useState<ContactLog[]>([]);
  const [packages, setPackages] = useState<ServicePackage[]>([]);
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([]);

  // Modal & Drawer States
  const [leadModalOpen, setLeadModalOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [leadImportExportOpen, setLeadImportExportOpen] = useState(false);

  const [quotationModalOpen, setQuotationModalOpen] = useState(false);
  const [editingQuotation, setEditingQuotation] = useState<Quotation | null>(null);
  const [quotationTargetLead, setQuotationTargetLead] = useState<Lead | null>(null);
  const [previewQuotation, setPreviewQuotation] = useState<Quotation | null>(null);
  const [packagesModalOpen, setPackagesModalOpen] = useState(false);

  const [clientModalOpen, setClientModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);

  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);
  const [paymentTargetClient, setPaymentTargetClient] = useState<Client | null>(null);

  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null);
  const [subscriptionTargetClient, setSubscriptionTargetClient] = useState<Client | null>(null);

  const [portfolioModalOpen, setPortfolioModalOpen] = useState(false);
  const [editingPortfolioItem, setEditingPortfolioItem] = useState<PortfolioItem | null>(null);

  // Firestore Subscriptions - only active when user is authenticated
  useEffect(() => {
    if (loading || !user) {
      setLeads([]);
      setContactLogs([]);
      setQuotations([]);
      setClients([]);
      setProjects([]);
      setPayments([]);
      setSubscriptions([]);
      return;
    }

    const unsubLeads = subscribeToLeads(setLeads, (e) => console.warn('Leads sub note:', e));
    const unsubLogs = subscribeToContactLogs(setContactLogs, (e) => console.warn('Logs sub note:', e));
    const unsubPackages = subscribeToPackages(setPackages, (e) => console.warn('Packages sub note:', e));
    const unsubQuotes = subscribeToQuotations(setQuotations, (e) => console.warn('Quotes sub note:', e));
    const unsubClients = subscribeToClients(setClients, (e) => console.warn('Clients sub note:', e));
    const unsubProjects = subscribeToProjects(setProjects, (e) => console.warn('Projects sub note:', e));
    const unsubPayments = subscribeToPayments(setPayments, (e) => console.warn('Payments sub note:', e));
    const unsubSubs = subscribeToSubscriptions(setSubscriptions, (e) => console.warn('Subs sub note:', e));
    const unsubPort = subscribeToPortfolio(setPortfolio, (e) => console.warn('Portfolio sub note:', e));

    return () => {
      unsubLeads?.();
      unsubLogs?.();
      unsubPackages?.();
      unsubQuotes?.();
      unsubClients?.();
      unsubProjects?.();
      unsubPayments?.();
      unsubSubs?.();
      unsubPort?.();
    };
  }, [user, loading]);

  // Update selectedLead reference if leads array updates
  useEffect(() => {
    if (selectedLead) {
      const refreshed = leads.find((l) => l.id === selectedLead.id);
      if (refreshed) setSelectedLead(refreshed);
    }
  }, [leads]);

  // Derived notification counts
  const todayStr = new Date().toISOString().split('T')[0];
  const followUpsDueCount = leads.filter(
    (l) => Boolean(l.nextFollowUpDate && l.nextFollowUpDate <= todayStr && !['Won', 'Lost'].includes(l.status))
  ).length;
  const newLeadsCount = leads.filter((l) => l.status === 'New').length;

  // Lead handlers
  const handleSaveLead = async (leadData: Partial<Lead> & { businessName: string; phone: string }) => {
    await saveLead(leadData);
  };

  const handleDeleteLead = async (id: string) => {
    await deleteLead(id);
    if (selectedLead?.id === id) setSelectedLead(null);
  };

  const handleUpdateLeadStatus = async (leadId: string, newStatus: LeadStatus) => {
    const target = leads.find((l) => l.id === leadId);
    if (target) {
      await saveLead({
        ...target,
        status: newStatus,
      });
    }
  };

  const handleAddContactLog = async (
    leadId: string,
    channel: ContactChannel,
    outcome: string,
    notes: string
  ) => {
    await addContactLog({
      leadId,
      channel,
      outcome,
      notes,
      date: new Date().toISOString().split('T')[0],
    });
  };

  // Convert Lead to Client & Project
  const handleConvertLeadToClient = async (lead: Lead) => {
    try {
      const clientId = await convertLeadToClient(lead);
      setSelectedLead(null);
      setCurrentTab('clients');
    } catch (e) {
      console.error('Error converting lead:', e);
    }
  };

  // Create Quotation for Lead
  const handleCreateQuotationForLead = (lead: Lead) => {
    setQuotationTargetLead(lead);
    setEditingQuotation(null);
    setQuotationModalOpen(true);
  };

  // Convert Quotation to Client
  const handleConvertQuoteToClient = async (quote: Quotation) => {
    try {
      const existingClient = clients.find((c) => c.businessName.toLowerCase() === quote.businessName.toLowerCase());
      if (existingClient) {
        setCurrentTab('clients');
        return;
      }

      await saveClient({
        businessName: quote.businessName,
        contactPerson: quote.clientName,
        phone: quote.clientPhone || '+254700000000',
        email: quote.clientEmail,
        location: quote.businessLocation || 'Nairobi, Kenya',
        agreedProjectPrice: quote.totalPrice,
        totalDepositPaid: quote.depositAmount,
        remainingBalance: quote.balanceDue,
        notes: `Converted from quotation ${quote.quoteNumber}`,
      });

      // Update quote status
      await saveQuotation({
        ...quote,
        status: 'Accepted',
      });

      setCurrentTab('clients');
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-9 h-9 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin mb-4" />
        <h2 className="text-sm font-bold text-slate-800">EMG Web Solutions</h2>
        <p className="text-xs text-slate-400 mt-1">Connecting to Cloud Firestore...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl p-8 text-center space-y-6">
          <div className="w-14 h-14 rounded-2xl bg-emerald-700 text-white flex items-center justify-center font-bold text-xl mx-auto shadow-md">
            EMG
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              EMG Web Solutions
            </h1>
            <p className="text-xs font-mono text-slate-400 mt-1">
              Internal Business Growth & Operations
            </p>
          </div>
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl text-xs text-slate-600 text-left space-y-1.5 leading-relaxed">
            <p className="font-semibold text-slate-900">Protected Business System</p>
            <p>
              Please sign in with your authorized Google Account to manage the prospect pipeline, generate quotations, record payments, and track client delivery.
            </p>
            <p className="text-slate-500 font-mono text-[11px] pt-1">
              Authorized Owner: frivatech5@gmail.com
            </p>
          </div>

          <button
            onClick={loginWithGoogle}
            className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Sign In with Google</span>
          </button>


        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col md:flex-row text-slate-900 font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        followUpsDueCount={followUpsDueCount}
        newLeadsCount={newLeadsCount}
        isOpenMobile={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0 md:pl-64">
        {/* Sticky Top Header */}
        <Header
          currentTab={currentTab}
          onOpenMobileSidebar={() => setMobileSidebarOpen(true)}
          onOpenNewLeadModal={() => {
            setEditingLead(null);
            setLeadModalOpen(true);
          }}
          onOpenNewPaymentModal={() => {
            setEditingPayment(null);
            setPaymentTargetClient(null);
            setPaymentModalOpen(true);
          }}
        />

        {/* Tab View Container */}
        <main className="flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto">
          {currentTab === 'dashboard' && (
            <DashboardView
              leads={leads}
              clients={clients}
              projects={projects}
              payments={payments}
              subscriptions={subscriptions}
              contactLogs={contactLogs}
              quotations={quotations}
              onNavigate={setCurrentTab}
              onOpenNewLead={() => {
                setEditingLead(null);
                setLeadModalOpen(true);
              }}
              onSelectLead={(lead) => setSelectedLead(lead)}
            />
          )}

          {currentTab === 'leads' && (
            <LeadsView
              leads={leads}
              packages={packages}
              onOpenAddModal={() => {
                setEditingLead(null);
                setLeadModalOpen(true);
              }}
              onOpenImportExport={() => setLeadImportExportOpen(true)}
              onSelectLead={(lead) => setSelectedLead(lead)}
              onEditLead={(lead) => {
                setEditingLead(lead);
                setLeadModalOpen(true);
              }}
              onDeleteLead={handleDeleteLead}
              onUpdateLeadStatus={handleUpdateLeadStatus}
            />
          )}

          {currentTab === 'followups' && (
            <FollowUpsView
              leads={leads}
              onSelectLead={(lead) => setSelectedLead(lead)}
              onRefresh={() => {}}
            />
          )}

          {currentTab === 'quotations' && (
            <QuotationsView
              quotations={quotations}
              packages={packages}
              leads={leads}
              onOpenNewQuote={() => {
                setEditingQuotation(null);
                setQuotationTargetLead(null);
                setQuotationModalOpen(true);
              }}
              onOpenPackagesModal={() => setPackagesModalOpen(true)}
              onEditQuote={(quote) => {
                setEditingQuotation(quote);
                setQuotationTargetLead(null);
                setQuotationModalOpen(true);
              }}
              onPreviewQuote={(quote) => setPreviewQuotation(quote)}
              onDeleteQuote={deleteQuotation}
              onUpdateQuoteStatus={async (id, status) => {
                const target = quotations.find((q) => q.id === id);
                if (target) await saveQuotation({ ...target, status });
              }}
              onConvertToClient={handleConvertQuoteToClient}
            />
          )}

          {currentTab === 'clients' && (
            <ClientsView
              clients={clients}
              projects={projects}
              onOpenNewClient={() => {
                setEditingClient(null);
                setClientModalOpen(true);
              }}
              onEditClient={(client) => {
                setEditingClient(client);
                setClientModalOpen(true);
              }}
              onDeleteClient={deleteClient}
              onRecordPaymentForClient={(client) => {
                setPaymentTargetClient(client);
                setEditingPayment(null);
                setPaymentModalOpen(true);
              }}
              onCreateSubscriptionForClient={(client) => {
                setSubscriptionTargetClient(client);
                setEditingSubscription(null);
                setSubscriptionModalOpen(true);
              }}
              onRefresh={() => {}}
            />
          )}

          {currentTab === 'payments' && (
            <PaymentsView
              payments={payments}
              clients={clients}
              onOpenNewPayment={() => {
                setEditingPayment(null);
                setPaymentTargetClient(null);
                setPaymentModalOpen(true);
              }}
              onEditPayment={(pay) => {
                setEditingPayment(pay);
                setPaymentTargetClient(null);
                setPaymentModalOpen(true);
              }}
              onDeletePayment={deletePayment}
            />
          )}

          {currentTab === 'maintenance' && (
            <MaintenanceView
              subscriptions={subscriptions}
              clients={clients}
              onOpenNewSubscription={() => {
                setEditingSubscription(null);
                setSubscriptionTargetClient(null);
                setSubscriptionModalOpen(true);
              }}
              onEditSubscription={(sub) => {
                setEditingSubscription(sub);
                setSubscriptionTargetClient(null);
                setSubscriptionModalOpen(true);
              }}
              onDeleteSubscription={deleteSubscription}
              onUpdateStatus={async (id, status) => {
                const target = subscriptions.find((s) => s.id === id);
                if (target) await saveSubscription({ ...target, status });
              }}
            />
          )}

          {currentTab === 'portfolio' && (
            <PortfolioView
              portfolio={portfolio}
              leads={leads}
              onOpenNewItem={() => {
                setEditingPortfolioItem(null);
                setPortfolioModalOpen(true);
              }}
              onEditItem={(item) => {
                setEditingPortfolioItem(item);
                setPortfolioModalOpen(true);
              }}
              onDeleteItem={deletePortfolioItem}
            />
          )}

          {currentTab === 'reports' && (
            <ReportsView
              leads={leads}
              clients={clients}
              payments={payments}
              subscriptions={subscriptions}
              quotations={quotations}
              contactLogs={contactLogs}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              leads={leads}
              clients={clients}
              projects={projects}
              payments={payments}
              subscriptions={subscriptions}
              quotations={quotations}
              portfolio={portfolio}
              packages={packages}
            />
          )}
        </main>
      </div>

      {/* Modals & Slide-out Drawers */}
      <LeadModal
        isOpen={leadModalOpen}
        lead={editingLead}
        existingLeads={leads}
        packages={packages}
        onSave={handleSaveLead}
        onClose={() => {
          setLeadModalOpen(false);
          setEditingLead(null);
        }}
      />

      <LeadDetailsDrawer
        lead={selectedLead}
        logs={contactLogs}
        packages={packages}
        onClose={() => setSelectedLead(null)}
        onEdit={(lead) => {
          setEditingLead(lead);
          setLeadModalOpen(true);
        }}
        onDelete={handleDeleteLead}
        onAddLog={handleAddContactLog}
        onConvertToClient={handleConvertLeadToClient}
        onCreateQuotation={handleCreateQuotationForLead}
      />

      <LeadImportExportModal
        isOpen={leadImportExportOpen}
        leads={leads}
        onClose={() => setLeadImportExportOpen(false)}
        onRefresh={() => {}}
      />

      <QuotationModal
        isOpen={quotationModalOpen}
        quotation={editingQuotation}
        targetLead={quotationTargetLead}
        leads={leads}
        packages={packages}
        onSave={async (quoteData) => {
          await saveQuotation(quoteData);
        }}
        onClose={() => {
          setQuotationModalOpen(false);
          setEditingQuotation(null);
          setQuotationTargetLead(null);
        }}
      />

      <QuotationPrintView
        quotation={previewQuotation}
        onClose={() => setPreviewQuotation(null)}
      />

      <PackagesModal
        isOpen={packagesModalOpen}
        packages={packages}
        onClose={() => setPackagesModalOpen(false)}
        onRefresh={() => {}}
      />

      <ClientModal
        isOpen={clientModalOpen}
        client={editingClient}
        onSave={async (clientData) => {
          await saveClient(clientData);
        }}
        onClose={() => {
          setClientModalOpen(false);
          setEditingClient(null);
        }}
      />

      <PaymentModal
        isOpen={paymentModalOpen}
        payment={editingPayment}
        targetClient={paymentTargetClient}
        clients={clients}
        onSave={async (payData) => {
          await savePayment(payData);
        }}
        onClose={() => {
          setPaymentModalOpen(false);
          setEditingPayment(null);
          setPaymentTargetClient(null);
        }}
      />

      <SubscriptionModal
        isOpen={subscriptionModalOpen}
        subscription={editingSubscription}
        targetClient={subscriptionTargetClient}
        clients={clients}
        onSave={async (subData) => {
          await saveSubscription(subData);
        }}
        onClose={() => {
          setSubscriptionModalOpen(false);
          setEditingSubscription(null);
          setSubscriptionTargetClient(null);
        }}
      />

      <PortfolioModal
        isOpen={portfolioModalOpen}
        item={editingPortfolioItem}
        leads={leads}
        onSave={async (itemData) => {
          await savePortfolioItem(itemData);
        }}
        onClose={() => {
          setPortfolioModalOpen(false);
          setEditingPortfolioItem(null);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
