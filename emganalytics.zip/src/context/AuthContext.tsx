import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import { auth, googleProvider, testConnection } from '../firebase/config';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isOwner: boolean;
  firestoreConnected: boolean;
  connectionMessage: string;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  checkConnection: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const OWNER_EMAIL = 'frivatech5@gmail.com';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [firestoreConnected, setFirestoreConnected] = useState<boolean>(false);
  const [connectionMessage, setConnectionMessage] = useState<string>('Checking database connection...');

  const checkConnection = async () => {
    const res = await testConnection();
    setFirestoreConnected(res.connected);
    if (res.message) setConnectionMessage(res.message);
  };

  useEffect(() => {
    checkConnection();

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error: any) {
      console.error('Logout error:', error);
      throw error;
    }
  };

  const isOwner = Boolean(user && user.email?.toLowerCase() === OWNER_EMAIL.toLowerCase());

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isOwner,
        firestoreConnected,
        connectionMessage,
        loginWithGoogle,
        logout,
        checkConnection,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
