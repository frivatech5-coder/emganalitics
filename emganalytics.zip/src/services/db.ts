import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  onSnapshot,
  query,
  orderBy,
  Unsubscribe,
} from 'firebase/firestore';
import { db, auth } from '../firebase/config';
import { handleFirestoreError, OperationType } from '../firebase/errors';
import {
  Lead,
  ContactLog,
  ServicePackage,
  Quotation,
  Client,
  Project,
  Payment,
  Subscription,
  PortfolioItem,
} from '../types';
import { DEFAULT_PACKAGES, INITIAL_PORTFOLIO_DEMOS } from './defaults';

// Normalization helper for duplicate check
export function normalizeKey(text: string): string {
  return (text || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Check if a lead already exists by normalized business name and location, or phone
 */
export function checkDuplicateLead(
  leads: Lead[],
  businessName: string,
  location: string,
  phone: string,
  currentId?: string
): { isDuplicate: boolean; matchingLead?: Lead; reason?: string } {
  const normName = normalizeKey(businessName);
  const normLoc = normalizeKey(location);
  const normPhone = normalizeKey(phone);

  for (const lead of leads) {
    if (currentId && lead.id === currentId) continue;

    const leadPhone = normalizeKey(lead.phone);
    if (normPhone && leadPhone && (leadPhone === normPhone || leadPhone.endsWith(normPhone.slice(-8)))) {
      return {
        isDuplicate: true,
        matchingLead: lead,
        reason: `Phone number matches existing lead: ${lead.businessName} (${lead.phone})`,
      };
    }

    const leadName = normalizeKey(lead.businessName);
    const leadLoc = normalizeKey(lead.location);
    if (normName && leadName === normName && normLoc && leadLoc === normLoc) {
      return {
        isDuplicate: true,
        matchingLead: lead,
        reason: `Business "${lead.businessName}" in "${lead.location}" already exists.`,
      };
    }
  }

  return { isDuplicate: false };
}

// ==================== LEADS ====================

export function subscribeToLeads(
  onData: (leads: Lead[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'leads';
  try {
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Lead));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function saveLead(lead: Partial<Lead> & { businessName: string; phone: string }): Promise<string> {
  const path = 'leads';
  const id = lead.id || `lead-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const currentUser = auth.currentUser;

  const data: Lead = {
    id,
    businessName: lead.businessName.trim(),
    contactPerson: lead.contactPerson?.trim() || 'Managing Director',
    phone: lead.phone.trim(),
    whatsapp: lead.whatsapp?.trim() || lead.phone.trim(),
    email: lead.email?.trim() || '',
    location: lead.location?.trim() || 'Nairobi',
    category: lead.category?.trim() || 'General Business',
    website: lead.website?.trim() || '',
    socialMedia: lead.socialMedia?.trim() || '',
    source: lead.source || 'Cold Outreach (Phone / WhatsApp)',
    status: lead.status || 'New',
    estimatedBudget: Number(lead.estimatedBudget) || 0,
    potentialValue: Number(lead.potentialValue) || Number(lead.estimatedBudget) || 0,
    assignedPackageId: lead.assignedPackageId || '',
    assignedPackageName: lead.assignedPackageName || '',
    notes: lead.notes || '',
    nextFollowUpDate: lead.nextFollowUpDate || '',
    lastContactDate: lead.lastContactDate || '',
    convertedToClientId: lead.convertedToClientId || '',
    createdAt: lead.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: lead.createdBy || currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data, { merge: true });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deleteLead(id: string): Promise<void> {
  const path = 'leads';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}

// ==================== CONTACT LOGS ====================

export function subscribeToContactLogs(
  onData: (logs: ContactLog[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'contactLogs';
  try {
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as ContactLog));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function addContactLog(log: Omit<ContactLog, 'id' | 'createdAt'>): Promise<string> {
  const path = 'contactLogs';
  const id = `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const currentUser = auth.currentUser;

  const data: ContactLog = {
    ...log,
    id,
    createdAt: new Date().toISOString(),
    createdBy: currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data);
    // Also update lead's lastContactDate
    if (log.leadId) {
      await updateDoc(doc(db, 'leads', log.leadId), {
        lastContactDate: log.date || new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString(),
      });
    }
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

// ==================== SERVICE PACKAGES ====================

export function subscribeToPackages(
  onData: (packages: ServicePackage[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'packages';
  try {
    return onSnapshot(
      collection(db, path),
      (snapshot) => {
        if (snapshot.empty) {
          // Initialize defaults
          seedDefaultPackages();
          onData(DEFAULT_PACKAGES);
          return;
        }
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as ServicePackage));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function seedDefaultPackages(): Promise<void> {
  const path = 'packages';
  try {
    for (const pkg of DEFAULT_PACKAGES) {
      await setDoc(doc(db, path, pkg.id), pkg, { merge: true });
    }
  } catch (error) {
    console.warn('Seeding packages note:', error);
  }
}

export async function savePackage(pkg: ServicePackage): Promise<void> {
  const path = 'packages';
  try {
    await setDoc(doc(db, path, pkg.id), pkg, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${pkg.id}`);
  }
}

export async function deletePackage(id: string): Promise<void> {
  const path = 'packages';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}

// ==================== QUOTATIONS ====================

export function subscribeToQuotations(
  onData: (quotes: Quotation[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'quotations';
  try {
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Quotation));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function saveQuotation(quote: Partial<Quotation> & { businessName: string; totalPrice: number }): Promise<string> {
  const path = 'quotations';
  const id = quote.id || `quote-${Date.now()}`;
  const currentUser = auth.currentUser;

  const depositValue = quote.depositValue !== undefined ? quote.depositValue : 50;
  const depositType = quote.depositType || 'percentage';
  const totalPrice = Number(quote.totalPrice) || 0;
  const depositAmount =
    depositType === 'percentage'
      ? Math.round((totalPrice * depositValue) / 100)
      : Math.min(depositValue, totalPrice);
  const balanceDue = Math.max(0, totalPrice - depositAmount);

  const data: Quotation = {
    id,
    quoteNumber: quote.quoteNumber || `EMG-Q${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    leadId: quote.leadId || '',
    clientName: quote.clientName || 'Valued Client',
    businessName: quote.businessName.trim(),
    clientEmail: quote.clientEmail || '',
    clientPhone: quote.clientPhone || '',
    businessLocation: quote.businessLocation || 'Nairobi, Kenya',
    services: quote.services || [],
    addOns: quote.addOns || [],
    scopeAndDeliverables: quote.scopeAndDeliverables || '',
    totalPrice,
    depositType,
    depositValue,
    depositAmount,
    balanceDue,
    validityDays: quote.validityDays || 14,
    paymentTerms:
      quote.paymentTerms ||
      '50% deposit payable via M-Pesa or Bank Transfer before project kickoff; remaining 50% balance payable upon completion and final client review.',
    status: quote.status || 'Draft',
    sentDate: quote.sentDate || '',
    acceptedDate: quote.acceptedDate || '',
    notes: quote.notes || '',
    createdAt: quote.createdAt || new Date().toISOString(),
    createdBy: quote.createdBy || currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data, { merge: true });
    // If quote is linked to a lead and sent/accepted, update lead status accordingly
    if (quote.leadId) {
      if (data.status === 'Sent') {
        await updateDoc(doc(db, 'leads', quote.leadId), { status: 'Proposal sent' }).catch(() => {});
      } else if (data.status === 'Accepted') {
        await updateDoc(doc(db, 'leads', quote.leadId), { status: 'Won' }).catch(() => {});
      }
    }
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deleteQuotation(id: string): Promise<void> {
  const path = 'quotations';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}

// ==================== CLIENTS ====================

export function subscribeToClients(
  onData: (clients: Client[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'clients';
  try {
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Client));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function saveClient(client: Partial<Client> & { businessName: string; phone: string }): Promise<string> {
  const path = 'clients';
  const id = client.id || `client-${Date.now()}`;
  const currentUser = auth.currentUser;

  const agreedProjectPrice = Number(client.agreedProjectPrice) || 0;
  const totalDepositPaid = Number(client.totalDepositPaid) || 0;
  const remainingBalance = Math.max(0, agreedProjectPrice - totalDepositPaid);

  const data: Client = {
    id,
    leadId: client.leadId || '',
    quotationId: client.quotationId || '',
    businessName: client.businessName.trim(),
    contactPerson: client.contactPerson?.trim() || 'Client',
    phone: client.phone.trim(),
    whatsapp: client.whatsapp?.trim() || client.phone.trim(),
    email: client.email?.trim() || '',
    location: client.location?.trim() || 'Kenya',
    agreedProjectPrice,
    totalDepositPaid,
    remainingBalance,
    domainInfo: client.domainInfo || { domainName: '', registrar: '', renewalDate: '' },
    hostingInfo: client.hostingInfo || { provider: 'EMG Managed Cloud', renewalDate: '', plan: 'Standard' },
    supportExpiryDate: client.supportExpiryDate || '',
    maintenanceStatus: client.maintenanceStatus || 'None',
    notes: client.notes || '',
    createdAt: client.createdAt || new Date().toISOString(),
    createdBy: client.createdBy || currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data, { merge: true });
    // Link back to lead if exists
    if (client.leadId) {
      await updateDoc(doc(db, 'leads', client.leadId), {
        convertedToClientId: id,
        status: 'Won',
      }).catch(() => {});
    }
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deleteClient(id: string): Promise<void> {
  const path = 'clients';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}

// Convert won lead to client
export async function convertLeadToClient(lead: Lead, agreedPrice?: number, initialDeposit = 0): Promise<string> {
  const price = agreedPrice || lead.potentialValue || lead.estimatedBudget || 35000;
  const clientId = await saveClient({
    leadId: lead.id,
    businessName: lead.businessName,
    contactPerson: lead.contactPerson,
    phone: lead.phone,
    whatsapp: lead.whatsapp,
    email: lead.email,
    location: lead.location,
    agreedProjectPrice: price,
    totalDepositPaid: initialDeposit,
    remainingBalance: Math.max(0, price - initialDeposit),
    notes: `Converted from lead pipeline. Original notes: ${lead.notes}`,
  });

  // Also auto-create a primary project record
  await saveProject({
    clientId,
    clientBusinessName: lead.businessName,
    title: `${lead.businessName} Website Revamp`,
    scope: `Design and launch modern responsive website with WhatsApp inquiry integration for ${lead.businessName}.`,
    status: initialDeposit > 0 ? 'Ready to start' : 'Awaiting deposit',
    startDate: new Date().toISOString().split('T')[0],
    deadline: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    tasks: [
      { id: '1', title: 'Collect business assets, logo, photos, and page copy', completed: false },
      { id: '2', title: 'Register/point .co.ke or .com domain and configure DNS', completed: false },
      { id: '3', title: 'Design high-converting mobile layout and interactive wireframes', completed: false },
      { id: '4', title: 'Integrate WhatsApp floating chat and Google Maps location', completed: false },
      { id: '5', title: 'Review staging link with client and implement feedback', completed: false },
      { id: '6', title: 'Receive final balance payment and launch on live domain', completed: false },
    ],
  });

  return clientId;
}

// ==================== PROJECTS ====================

export function subscribeToProjects(
  onData: (projects: Project[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'projects';
  try {
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Project));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function saveProject(project: Partial<Project> & { clientId: string; title: string }): Promise<string> {
  const path = 'projects';
  const id = project.id || `proj-${Date.now()}`;
  const currentUser = auth.currentUser;

  const data: Project = {
    id,
    clientId: project.clientId,
    clientBusinessName: project.clientBusinessName || 'Client Business',
    title: project.title.trim(),
    scope: project.scope || '',
    status: project.status || 'Ready to start',
    startDate: project.startDate || new Date().toISOString().split('T')[0],
    deadline: project.deadline || '',
    tasks: project.tasks || [],
    stagingUrl: project.stagingUrl || '',
    liveUrl: project.liveUrl || '',
    createdAt: project.createdAt || new Date().toISOString(),
    createdBy: project.createdBy || currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data, { merge: true });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deleteProject(id: string): Promise<void> {
  const path = 'projects';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}

// ==================== PAYMENTS ====================

export function subscribeToPayments(
  onData: (payments: Payment[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'payments';
  try {
    const q = query(collection(db, path), orderBy('paymentDate', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Payment));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function savePayment(payment: Partial<Payment> & { clientId: string; amount: number }): Promise<string> {
  const path = 'payments';
  const id = payment.id || `pay-${Date.now()}`;
  const currentUser = auth.currentUser;

  const data: Payment = {
    id,
    clientId: payment.clientId,
    clientBusinessName: payment.clientBusinessName || 'Client',
    projectId: payment.projectId || '',
    quotationId: payment.quotationId || '',
    amount: Number(payment.amount) || 0,
    currency: 'KSh',
    paymentDate: payment.paymentDate || new Date().toISOString().split('T')[0],
    paymentMethod: payment.paymentMethod || 'M-Pesa Paybill/Till',
    transactionReference: (payment.transactionReference || '').toUpperCase().trim(),
    paymentStatus: payment.paymentStatus || 'Confirmed',
    category: payment.category || 'Deposit',
    notes: payment.notes || '',
    createdAt: payment.createdAt || new Date().toISOString(),
    createdBy: payment.createdBy || currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data, { merge: true });

    // If confirmed, update client's deposit paid and remaining balance
    if (data.paymentStatus === 'Confirmed' && data.clientId) {
      try {
        const clientRef = doc(db, 'clients', data.clientId);
        const clientSnap = await getDoc(clientRef);
        if (clientSnap.exists()) {
          const clientData = clientSnap.data() as Client;
          const newDeposit = (clientData.totalDepositPaid || 0) + data.amount;
          const newBalance = Math.max(0, (clientData.agreedProjectPrice || 0) - newDeposit);
          await updateDoc(clientRef, {
            totalDepositPaid: newDeposit,
            remainingBalance: newBalance,
          });
        }
      } catch (e) {
        console.warn('Note updating client balance:', e);
      }
    }

    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deletePayment(id: string): Promise<void> {
  const path = 'payments';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}

// ==================== SUBSCRIPTIONS (MRR) ====================

export function subscribeToSubscriptions(
  onData: (subs: Subscription[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'subscriptions';
  try {
    const q = query(collection(db, path), orderBy('nextBillingDate', 'asc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Subscription));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function saveSubscription(
  sub: Partial<Subscription> & { clientId: string; monthlyFee: number }
): Promise<string> {
  const path = 'subscriptions';
  const id = sub.id || `sub-${Date.now()}`;
  const currentUser = auth.currentUser;

  const data: Subscription = {
    id,
    clientId: sub.clientId,
    clientBusinessName: sub.clientBusinessName || 'Client Business',
    websiteUrl: sub.websiteUrl || '',
    monthlyFee: Number(sub.monthlyFee) || 1500,
    startDate: sub.startDate || new Date().toISOString().split('T')[0],
    nextBillingDate: sub.nextBillingDate || '',
    status: sub.status || 'Active',
    includedServices: sub.includedServices || [
      'Weekly automated cloud backups',
      'Security patching & malware scanner',
      '2 hours monthly content updates',
      'Domain/SSL expiry monitoring',
    ],
    supportLimits: sub.supportLimits || 'Up to 2 hours of revisions per month. Extra hours @ KSh 1,200/hr.',
    renewalNotes: sub.renewalNotes || '',
    createdAt: sub.createdAt || new Date().toISOString(),
    createdBy: sub.createdBy || currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data, { merge: true });

    // Update client maintenance status
    if (sub.clientId) {
      await updateDoc(doc(db, 'clients', sub.clientId), {
        maintenanceStatus: data.status,
      }).catch(() => {});
    }

    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deleteSubscription(id: string): Promise<void> {
  const path = 'subscriptions';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}

// ==================== PORTFOLIO & DEMOS ====================

export function subscribeToPortfolio(
  onData: (items: PortfolioItem[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = 'portfolio';
  try {
    return onSnapshot(
      collection(db, path),
      (snapshot) => {
        if (snapshot.empty) {
          seedDefaultPortfolio();
          onData(INITIAL_PORTFOLIO_DEMOS);
          return;
        }
        const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as PortfolioItem));
        onData(items);
      },
      (error) => {
        onError?.(error);
        handleFirestoreError(error, OperationType.GET, path);
      }
    );
  } catch (err: any) {
    onError?.(err);
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function seedDefaultPortfolio(): Promise<void> {
  const path = 'portfolio';
  try {
    for (const demo of INITIAL_PORTFOLIO_DEMOS) {
      await setDoc(doc(db, path, demo.id), demo, { merge: true });
    }
  } catch (error) {
    console.warn('Seeding portfolio demo note:', error);
  }
}

export async function savePortfolioItem(item: Partial<PortfolioItem> & { name: string; liveUrl: string }): Promise<string> {
  const path = 'portfolio';
  const id = item.id || `demo-${Date.now()}`;
  const currentUser = auth.currentUser;

  const data: PortfolioItem = {
    id,
    name: item.name.trim(),
    category: item.category || 'General',
    liveUrl: item.liveUrl.trim(),
    previewUrl: item.previewUrl || '',
    projectType: item.projectType || 'Concept demo',
    status: item.status || 'Concept demo',
    featuresDemonstrated: item.featuresDemonstrated || [],
    featuresTested: item.featuresTested || [],
    relatedLeadId: item.relatedLeadId || '',
    notes: item.notes || '',
    createdAt: item.createdAt || new Date().toISOString(),
    createdBy: item.createdBy || currentUser?.email || 'admin',
  };

  try {
    await setDoc(doc(db, path, id), data, { merge: true });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deletePortfolioItem(id: string): Promise<void> {
  const path = 'portfolio';
  try {
    await deleteDoc(doc(db, path, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
  }
}
