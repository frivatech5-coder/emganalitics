export interface MessageTemplate {
  id: string;
  name: string;
  description: string;
  category: 'Cold' | 'FollowUp' | 'Proposal' | 'Objection' | 'Closing' | 'Referral';
  content: string;
}

export const OUTREACH_TEMPLATES: MessageTemplate[] = [
  {
    id: 'first-contact',
    name: 'First Contact (Introductory WhatsApp / Email)',
    category: 'Cold',
    description: 'Respectful, high-value introduction highlighting Kenyan local customer search and mobile speed.',
    content: `Habari {contactPerson}, hope you are doing well.

My name is Kelvin from EMG Web Solutions (https://emgwebsolutions.vercel.app). I came across {businessName} while reviewing leading businesses in {location} and noticed your services could attract significantly more inquiries online.

We build modern, lightning-fast websites optimized for Kenyan mobile users and Google search, allowing customers to call, WhatsApp, or order directly with zero friction.

I put together a quick preview of how a streamlined website could look for {businessName}. Would you be open to a quick 5-minute review sometime this week?

Kind regards,
Kelvin — EMG Web Solutions
+254 700 000 000 | Nairobi, Kenya`,
  },
  {
    id: 'follow-up-no-response',
    name: 'Follow-Up (After No Response)',
    category: 'FollowUp',
    description: 'Polite, non-intrusive follow-up 3-5 days after the initial outreach.',
    content: `Hello {contactPerson}, hope your week is off to a productive start.

Just following up on my previous message regarding {businessName}'s web presence. I know you run a busy schedule managing day-to-day operations.

Whenever you have a spare moment, I’d love to share 2 or 3 quick suggestions that can help your brand rank higher when clients in {location} search for {category} services.

No pressure at all — let me know if later this week works better for a brief chat.

Best regards,
Kelvin | EMG Web Solutions`,
  },
  {
    id: 'interested-prospect',
    name: 'Interested Prospect (Discovery & Needs Analysis)',
    category: 'FollowUp',
    description: 'Next steps for a prospect who expressed initial interest.',
    content: `Thank you for getting back to me, {contactPerson}! Great to connect with you.

To make sure we tailor the best solution for {businessName}, could you let me know:
1. What is the primary goal of the website? (e.g., getting more WhatsApp/call inquiries, showcasing your portfolio, or selling products online)
2. Do you have an existing domain name, or will we be starting fresh?
3. What is your preferred launch timeline?

Once you share these details, I’ll prepare a clear scope and a tailored quotation that matches your exact budget.

Looking forward to collaborating!
Kelvin — EMG Web Solutions`,
  },
  {
    id: 'demo-presentation',
    name: 'Live Demo Presentation (Showing Industry Concept)',
    category: 'Proposal',
    description: 'Sharing a tailored interactive demo to create immediate excitement.',
    content: `Hello {contactPerson},

As promised, our team at EMG Web Solutions created a live concept demo tailored specifically for {category} businesses like {businessName}:

🔗 Live Demo: {demoUrl}

Key highlights we integrated:
• Instant WhatsApp & One-tap calling for local Kenyan customers
• Clean mobile-first design that loads in under 2 seconds on Safaricom 4G/5G
• Clear service catalog and Google Maps directions to your premises

Take a quick look on your phone and let me know your thoughts. We can easily customize all photos, text, and branding to your taste.

Best regards,
Kelvin | EMG Web Solutions`,
  },
  {
    id: 'quotation-sent',
    name: 'Quotation Sent (Formal Scope & Deposit Terms)',
    category: 'Proposal',
    description: 'Clear breakdown of deliverables, payment milestones, and guarantee.',
    content: `Habari {contactPerson},

Thank you for your time discussing the website project for {businessName}.

I have officially prepared and attached your formal Quotation (Quote #{quoteNumber}) totaling {quoteTotal}.

Summary of what’s covered:
• Custom mobile-responsive web design
• M-Pesa integration / direct WhatsApp inquiry buttons
• Free SSL certificate, fast hosting setup & SEO submission
• 30-day post-launch technical support

Terms: {paymentTerms}

Please review the document, and feel free to reach out if you would like any adjustment. Once you give the go-ahead and confirm the deposit, our development kickoff starts immediately.

Best regards,
Kelvin — EMG Web Solutions`,
  },
  {
    id: 'price-objection',
    name: 'Price Objection (ROI, Phased Milestones, Starter Option)',
    category: 'Objection',
    description: 'Handling budget pushback gracefully with flexible milestones or phased scope.',
    content: `Hello {contactPerson}, I completely understand and appreciate your honesty regarding budget constraints.

At EMG Web Solutions, our goal is to ensure your investment pays for itself through new paying customers rather than becoming an overhead.

We have two flexible options to help you move forward comfortably:
1. Phased Payment: We can split the balance into two convenient milestones after the initial deposit.
2. Lean Starter Scope: We can launch with our core high-conversion pages for {starterPrice}, and add additional custom modules later once the site starts generating revenue.

Which of these two options would be more comfortable for your cash flow right now?

Warm regards,
Kelvin | EMG Web Solutions`,
  },
  {
    id: 'referral-request',
    name: 'Referral Request (Satisfied Client)',
    category: 'Referral',
    description: 'Asking a happy client for referrals across their business network.',
    content: `Habari {contactPerson}!

It has been an absolute pleasure building and launching the website for {businessName}. We’re excited to see your brand thrive!

Quick favor: do you happen to know 1 or 2 fellow business owners or associates in {location} who might need a modern website, an e-commerce store, or reliable web maintenance?

I would love to offer them the same priority service and quality we delivered for you. A simple WhatsApp intro would mean the world.

Thank you once again for trusting EMG Web Solutions!

Warm regards,
Kelvin | EMG Web Solutions`,
  },
  {
    id: 'polite-closure',
    name: 'Polite Closure (Respectful Door Kept Open)',
    category: 'Closing',
    description: 'Respecting a client who said no or postponed, leaving a positive impression.',
    content: `Hello {contactPerson},

Understood completely! Thank you for taking the time to review our proposals for {businessName}. We completely respect your current priorities and timing.

I will hold onto your file, and if your team decides to revamp your digital presence or explore new online channels in the future, we’d be glad to assist.

Wishing {businessName} continued success this quarter!

Kind regards,
Kelvin — EMG Web Solutions
https://emgwebsolutions.vercel.app`,
  },
];

export function formatKenyanShillings(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) return 'KSh 0';
  return `KSh ${Number(amount).toLocaleString('en-KE')}`;
}

export function populateTemplate(
  templateContent: string,
  variables: Record<string, string | number | undefined>
): string {
  let result = templateContent;
  for (const [key, value] of Object.entries(variables)) {
    const stringValue = value !== undefined && value !== null ? String(value) : '';
    result = result.replaceAll(`{${key}}`, stringValue);
  }
  return result;
}
