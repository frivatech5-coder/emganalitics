import React, { useState, useEffect } from 'react';
import { X, Repeat, Check, AlertCircle, Building2 } from 'lucide-react';
import { Subscription, SubscriptionStatus, Client } from '../../types';

interface SubscriptionModalProps {
  isOpen: boolean;
  subscription?: Subscription | null;
  targetClient?: Client | null;
  clients: Client[];
  onSave: (subData: Partial<Subscription> & { clientId: string; monthlyFee: number }) => Promise<void>;
  onClose: () => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  subscription,
  targetClient,
  clients,
  onSave,
  onClose,
}) => {
  const [clientId, setClientId] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [monthlyFee, setMonthlyFee] = useState<number>(1500);
  const [startDate, setStartDate] = useState('');
  const [nextBillingDate, setNextBillingDate] = useState('');
  const [status, setStatus] = useState<SubscriptionStatus>('Active');
  const [includedServices, setIncludedServices] = useState<string[]>([
    'Weekly automated cloud backups',
    'Security patches and malware monitoring',
    'Up to 2 hours of monthly content updates',
    'Domain and SSL renewal tracking',
  ]);
  const [supportLimits, setSupportLimits] = useState('Up to 2 hours of monthly updates included. Additional hours at KSh 1,200/hr.');
  const [renewalNotes, setRenewalNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (subscription) {
      setClientId(subscription.clientId);
      setWebsiteUrl(subscription.websiteUrl);
      setMonthlyFee(subscription.monthlyFee);
      setStartDate(subscription.startDate);
      setNextBillingDate(subscription.nextBillingDate);
      setStatus(subscription.status);
      setIncludedServices(subscription.includedServices || []);
      setSupportLimits(subscription.supportLimits || '');
      setRenewalNotes(subscription.renewalNotes || '');
    } else if (targetClient) {
      setClientId(targetClient.id);
      setWebsiteUrl(targetClient.domainInfo?.domainName ? `https://${targetClient.domainInfo.domainName}` : '');
      setMonthlyFee(1500);
      const today = new Date().toISOString().split('T')[0];
      setStartDate(today);
      const nextMonth = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      setNextBillingDate(nextMonth);
      setStatus('Active');
      setRenewalNotes('');
    } else {
      setClientId(clients[0]?.id || '');
      setWebsiteUrl('');
      setMonthlyFee(1500);
      const today = new Date().toISOString().split('T')[0];
      setStartDate(today);
      const nextMonth = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      setNextBillingDate(nextMonth);
      setStatus('Active');
      setRenewalNotes('');
    }
  }, [subscription, targetClient, clients, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId) {
      setError('Please select a client.');
      return;
    }
    if (monthlyFee <= 0) {
      setError('Monthly retainer fee must be greater than 0.');
      return;
    }

    setSaving(true);
    setError(null);
    const clientObj = clients.find((c) => c.id === clientId);

    try {
      await onSave({
        id: subscription?.id,
        clientId,
        clientBusinessName: clientObj?.businessName || 'Client Business',
        websiteUrl: websiteUrl.trim(),
        monthlyFee: Number(monthlyFee),
        startDate,
        nextBillingDate,
        status,
        includedServices,
        supportLimits,
        renewalNotes: renewalNotes.trim(),
      });
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to save maintenance subscription.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-2xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {subscription ? 'Edit Maintenance Subscription' : 'Create Recurring Maintenance Retainer'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Build predictable recurring revenue for EMG Web Solutions
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Client Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Client Business *
            </label>
            <select
              required
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-medium"
            >
              <option value="">-- Choose Client --</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.businessName} ({c.contactPerson})
                </option>
              ))}
            </select>
          </div>

          {/* Website URL */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Website URL Under Maintenance
            </label>
            <input
              type="url"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              placeholder="https://clientwebsite.co.ke"
              className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg"
            />
          </div>

          {/* Monthly Fee & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Monthly Retainer Fee (KSh) *
              </label>
              <input
                type="number"
                min="500"
                step="100"
                required
                value={monthlyFee}
                onChange={(e) => setMonthlyFee(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono font-bold text-emerald-800 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subscription Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as SubscriptionStatus)}
                className="w-full px-3 py-2 text-xs font-semibold border border-slate-300 rounded-lg"
              >
                <option value="Active">Active (Generating MRR)</option>
                <option value="Overdue">Overdue Payment</option>
                <option value="Paused">Paused</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {/* Start Date & Next Billing Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Start Date
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Next Billing Date *
              </label>
              <input
                type="date"
                required
                value={nextBillingDate}
                onChange={(e) => setNextBillingDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-semibold"
              />
            </div>
          </div>

          {/* Support Limits */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Support Limits & Included Scope
            </label>
            <input
              type="text"
              value={supportLimits}
              onChange={(e) => setSupportLimits(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Renewal Reminders & Special Notes
            </label>
            <textarea
              rows={2}
              value={renewalNotes}
              onChange={(e) => setRenewalNotes(e.target.value)}
              placeholder="e.g. Invoiced via WhatsApp on the 1st of every month..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 text-xs text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Retainer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
