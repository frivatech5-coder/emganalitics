import React, { useState } from 'react';
import {
  Repeat,
  Plus,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Copy,
  Check,
  MessageCircle,
  ExternalLink,
  Edit,
  Trash2,
  Clock,
  ShieldCheck,
  Globe,
  DollarSign,
  X,
} from 'lucide-react';
import { Subscription, Client, SubscriptionStatus } from '../../types';
import { formatKenyanShillings } from '../../services/templates';
import { EmptyState } from '../common/EmptyState';
import { ConfirmModal } from '../common/ConfirmModal';

interface MaintenanceViewProps {
  subscriptions: Subscription[];
  clients: Client[];
  onOpenNewSubscription: () => void;
  onEditSubscription: (sub: Subscription) => void;
  onDeleteSubscription: (id: string) => void;
  onUpdateStatus: (id: string, status: SubscriptionStatus) => void;
}

export const MaintenanceView: React.FC<MaintenanceViewProps> = ({
  subscriptions,
  clients,
  onOpenNewSubscription,
  onEditSubscription,
  onDeleteSubscription,
  onUpdateStatus,
}) => {
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [reminderModalSub, setReminderModalSub] = useState<Subscription | null>(null);
  const [copiedReminder, setCopiedReminder] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  // Active MRR
  const activeSubs = subscriptions.filter((s) => s.status === 'Active');
  const monthlyRecurringRevenue = activeSubs.reduce((sum, s) => sum + (Number(s.monthlyFee) || 0), 0);
  const annualRunRate = monthlyRecurringRevenue * 12;

  // Overdue and upcoming renewals
  const overdueSubs = subscriptions.filter(
    (s) => s.status === 'Overdue' || (s.status === 'Active' && s.nextBillingDate && s.nextBillingDate < todayStr)
  );
  const upcomingRenewals = subscriptions.filter(
    (s) => s.status === 'Active' && s.nextBillingDate && s.nextBillingDate >= todayStr
  );

  // Generate Renewal Reminder Text for Kenyan clients
  const getReminderText = (sub: Subscription) => {
    const client = clients.find((c) => c.id === sub.clientId);
    const clientName = client?.contactPerson || 'Client';
    const bizName = sub.clientBusinessName;
    const fee = formatKenyanShillings(sub.monthlyFee);

    return `Habari ${clientName}, hope your business is thriving.

This is Kelvin from EMG Web Solutions. Your monthly website maintenance and security retainer for ${bizName} (${sub.websiteUrl || 'your website'}) is scheduled for renewal on ${sub.nextBillingDate}.

Included in this month’s maintenance:
• Weekly off-site cloud backups
• WordPress/system security patch updates
• Uptime monitoring and domain/SSL validity checks
• Up to 2 hours of complimentary content updates

Retainer Amount: ${fee}
Payment can be settled directly via our M-Pesa Till / Paybill. Let us know if you need any text or product updates applied to your site this month!

Best regards,
Kelvin — EMG Web Solutions
https://emgwebsolutions.vercel.app`;
  };

  const handleCopyReminder = (sub: Subscription) => {
    navigator.clipboard.writeText(getReminderText(sub));
    setCopiedReminder(true);
    setTimeout(() => setCopiedReminder(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* MRR Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Monthly Recurring Revenue */}
        <div className="bg-emerald-950 text-white border border-emerald-900 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-emerald-300 mb-1">
            <span className="font-semibold uppercase tracking-wider text-[11px]">
              Monthly Recurring Revenue (MRR)
            </span>
            <span className="px-1.5 py-0.2 bg-emerald-900 text-emerald-300 rounded font-mono text-[10px]">
              Expected / Month
            </span>
          </div>
          <div className="text-3xl font-bold font-mono text-white tabular-nums my-1">
            {formatKenyanShillings(monthlyRecurringRevenue)}
            <span className="text-xs font-normal text-emerald-400 font-sans">/mo</span>
          </div>
          <p className="text-[11px] text-emerald-300 mt-2">
            Annualized run-rate: <strong className="font-mono">{formatKenyanShillings(annualRunRate)}/yr</strong>
          </p>
        </div>

        {/* Active Retainer Subscriptions */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-slate-700">
              Active Retainers
            </span>
            <span className="font-mono text-slate-400 text-[10px]">
              {subscriptions.length} total
            </span>
          </div>
          <div className="text-3xl font-bold font-mono text-slate-900 tabular-nums my-1">
            {activeSubs.length}
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Clients on recurring website care & updates
          </p>
        </div>

        {/* Overdue / Due Renewals */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-amber-800">
              Renewals Due / Overdue
            </span>
            <span className="px-1.5 py-0.2 bg-amber-50 text-amber-800 rounded font-mono text-[10px]">
              Action Required
            </span>
          </div>
          <div className="text-3xl font-bold font-mono text-amber-900 tabular-nums my-1">
            {overdueSubs.length}
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Send manual reminder via WhatsApp or Email
          </p>
        </div>
      </div>

      {/* Main Subscriptions List */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Maintenance Client Retainers ({subscriptions.length})
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Proactive website updates, off-site backups, and hosting maintenance
            </p>
          </div>

          <button
            onClick={onOpenNewSubscription}
            className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Retainer</span>
          </button>
        </div>

        {subscriptions.length === 0 ? (
          <div className="p-8">
            <EmptyState
              icon={Repeat}
              title="No maintenance subscriptions yet"
              description="Offer every completed website client an ongoing maintenance retainer (from KSh 1,500/month) to build predictable recurring income."
              actionLabel="Add Maintenance Retainer"
              onAction={onOpenNewSubscription}
            />
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {subscriptions.map((sub) => {
              const isOverdue =
                sub.status === 'Overdue' ||
                (sub.status === 'Active' && sub.nextBillingDate && sub.nextBillingDate < todayStr);

              return (
                <div key={sub.id} className="p-4 hover:bg-slate-50/70 transition-colors">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-slate-900">
                          {sub.clientBusinessName}
                        </h4>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-semibold font-mono ${
                            sub.status === 'Active' && !isOverdue
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : isOverdue
                              ? 'bg-red-50 text-red-800 border border-red-200'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {isOverdue ? 'Overdue' : sub.status}
                        </span>
                      </div>

                      {sub.websiteUrl && (
                        <a
                          href={sub.websiteUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-xs text-emerald-700 hover:underline flex items-center gap-1 font-mono mt-0.5"
                        >
                          <Globe className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span>{sub.websiteUrl}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      )}

                      <p className="text-[11px] text-slate-500 mt-1">
                        Limits: {sub.supportLimits}
                      </p>
                    </div>

                    <div className="flex items-center gap-4 flex-wrap">
                      <div className="text-right">
                        <span className="text-[11px] text-slate-400 block">Monthly Fee</span>
                        <span className="font-mono text-base font-bold text-emerald-800 tabular-nums">
                          {formatKenyanShillings(sub.monthlyFee)}
                        </span>
                      </div>

                      <div className="text-right min-w-[110px]">
                        <span className="text-[11px] text-slate-400 block">Next Renewal</span>
                        <span
                          className={`font-mono text-xs font-bold tabular-nums ${
                            isOverdue ? 'text-red-700' : 'text-slate-800'
                          }`}
                        >
                          {sub.nextBillingDate || 'Not set'}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200">
                        <button
                          onClick={() => setReminderModalSub(sub)}
                          className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded flex items-center gap-1 transition-colors"
                          title="Generate renewal reminder message"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Reminder</span>
                        </button>

                        <button
                          onClick={() => onEditSubscription(sub)}
                          className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => setDeleteId(sub.id)}
                          className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Manual Reminder Message Modal */}
      {reminderModalSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h4 className="text-sm font-bold text-slate-900">
                  Renewal Notification — {reminderModalSub.clientBusinessName}
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Ready-to-send courtesy message for Kenyan clients
                </p>
              </div>
              <button
                onClick={() => setReminderModalSub(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <textarea
                readOnly
                rows={9}
                value={getReminderText(reminderModalSub)}
                className="w-full p-3 text-xs font-sans leading-relaxed border border-slate-300 rounded-lg bg-slate-50"
              />

              <div className="flex justify-between items-center pt-2">
                <span className="text-[11px] text-slate-400">
                  Direct copy: sends via your own WhatsApp or Email
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopyReminder(reminderModalSub)}
                    className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 flex items-center gap-1.5"
                  >
                    {copiedReminder ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Message</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Subscription Modal */}
      <ConfirmModal
        isOpen={Boolean(deleteId)}
        title="Delete Maintenance Retainer"
        message="Are you sure you want to delete this subscription record?"
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteId) onDeleteSubscription(deleteId);
          setDeleteId(null);
        }}
        onClose={() => setDeleteId(null)}
      />
    </div>
  );
};
