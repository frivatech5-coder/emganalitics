import React, { useState } from 'react';
import {
  Settings,
  Shield,
  Database,
  Download,
  Upload,
  RefreshCw,
  Check,
  AlertCircle,
  ExternalLink,
  Copy,
  Server,
  Building2,
  Key,
} from 'lucide-react';
import { useAuth, OWNER_EMAIL } from '../../context/AuthContext';
import { Lead, Client, Project, Payment, Subscription, Quotation, PortfolioItem, ServicePackage } from '../../types';
import { firebaseConfig } from '../../firebase/config';

interface SettingsViewProps {
  leads: Lead[];
  clients: Client[];
  projects: Project[];
  payments: Payment[];
  subscriptions: Subscription[];
  quotations: Quotation[];
  portfolio: PortfolioItem[];
  packages: ServicePackage[];
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  leads,
  clients,
  projects,
  payments,
  subscriptions,
  quotations,
  portfolio,
  packages,
}) => {
  const { user, isOwner, firestoreConnected, connectionMessage, checkConnection, loginWithGoogle } = useAuth();
  const [checking, setChecking] = useState(false);
  const [copiedEnv, setCopiedEnv] = useState(false);

  const handleTestConnection = async () => {
    setChecking(true);
    await checkConnection();
    setChecking(false);
  };

  // Full System JSON Backup
  const handleExportFullBackup = () => {
    const fullBackup = {
      app: 'EMG Web Solutions Growth System',
      exportedAt: new Date().toISOString(),
      ownerEmail: OWNER_EMAIL,
      currency: 'KES (KSh)',
      stats: {
        totalLeads: leads.length,
        totalClients: clients.length,
        totalProjects: projects.length,
        totalPayments: payments.length,
        totalSubscriptions: subscriptions.length,
        totalQuotations: quotations.length,
        totalPortfolio: portfolio.length,
      },
      data: {
        leads,
        clients,
        projects,
        payments,
        subscriptions,
        quotations,
        portfolio,
        packages,
      },
    };

    const jsonString = JSON.stringify(fullBackup, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `emg-growth-system-full-backup-${new Date().toISOString().split('T')[0]}.json`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const sampleEnv = `# Firebase Configuration for Vercel / Production Deployment
VITE_FIREBASE_PROJECT_ID="${firebaseConfig.projectId}"
VITE_FIREBASE_APP_ID="${firebaseConfig.appId}"
VITE_FIREBASE_API_KEY="${firebaseConfig.apiKey}"
VITE_FIREBASE_AUTH_DOMAIN="${firebaseConfig.authDomain}"
VITE_FIREBASE_DATABASE_ID="${firebaseConfig.firestoreDatabaseId}"
VITE_FIREBASE_STORAGE_BUCKET="${firebaseConfig.storageBucket}"
VITE_FIREBASE_MESSAGING_SENDER_ID="${firebaseConfig.messagingSenderId}"`;

  const handleCopyEnv = () => {
    navigator.clipboard.writeText(sampleEnv);
    setCopiedEnv(true);
    setTimeout(() => setCopiedEnv(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Business Identity Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold text-base shadow-xs">
            EMG
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">
              EMG Web Solutions Identity
            </h3>
            <p className="text-xs text-slate-500">
              Operating Parameters & Business Scope
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-2 text-xs">
          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-[11px] text-slate-400 block">Business Name</span>
            <span className="font-semibold text-slate-900">EMG Web Solutions</span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-[11px] text-slate-400 block">Official Currency</span>
            <span className="font-semibold text-slate-900 font-mono">Kenyan Shillings (KSh / KES)</span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-[11px] text-slate-400 block">Primary Target Market</span>
            <span className="font-semibold text-slate-900">Kenyan Commercial SMBs</span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-[11px] text-slate-400 block">Production Website</span>
            <a
              href="https://emgwebsolutions.vercel.app"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-700 hover:underline flex items-center gap-1 font-mono truncate"
            >
              emgwebsolutions.vercel.app
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-[11px] text-slate-400 block">Designated Admin / Owner</span>
            <span className="font-semibold text-slate-900 font-mono truncate block">
              {OWNER_EMAIL}
            </span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-[11px] text-slate-400 block">Settlement Rails</span>
            <span className="font-semibold text-slate-900">M-Pesa (Till/Paybill) & Bank</span>
          </div>
        </div>
      </div>

      {/* Cloud Firestore & Security Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-emerald-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Cloud Firestore & Firebase Authentication
              </h3>
              <p className="text-xs text-slate-500">
                Persistent database backend and security rules status
              </p>
            </div>
          </div>

          <button
            onClick={handleTestConnection}
            disabled={checking}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${checking ? 'animate-spin' : ''}`} />
            <span>Test DB Connection</span>
          </button>
        </div>

        {/* Database Status Alert */}
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${
            firestoreConnected
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}
        >
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                firestoreConnected ? 'bg-emerald-600' : 'bg-amber-500'
              }`}
            />
            <span className="font-semibold">{connectionMessage}</span>
          </div>
          <span className="font-mono text-[11px] text-slate-600">
            Project: {firebaseConfig.projectId}
          </span>
        </div>

        {/* Auth State */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
          <div>
            <span className="font-bold text-slate-900 block mb-0.5">
              Current Authentication State:
            </span>
            {user ? (
              <p className="text-slate-600">
                Logged in as <strong className="font-mono">{user.email}</strong>{' '}
                {isOwner && (
                  <span className="text-emerald-700 font-bold">(Verified Owner)</span>
                )}
              </p>
            ) : (
              <p className="text-slate-500">
                Unauthenticated. Please sign in with your Google Account ({OWNER_EMAIL}) to enforce security rules.
              </p>
            )}
          </div>

          {!user && (
            <button
              onClick={loginWithGoogle}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs"
            >
              Sign In With Google
            </button>
          )}
        </div>
      </div>

      {/* Complete Data Backup & Export Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Download className="w-5 h-5 text-slate-700" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Full Database Backup (JSON Export)
              </h3>
              <p className="text-xs text-slate-500">
                Export all leads, quotes, clients, projects, payments, and subscriptions in one portable file
              </p>
            </div>
          </div>

          <button
            onClick={handleExportFullBackup}
            className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Full Backup</span>
          </button>
        </div>

        <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-500 space-y-1">
          <p className="font-semibold text-slate-800">Records currently stored:</p>
          <p className="font-mono text-[11px]">
            {leads.length} Leads · {clients.length} Clients · {projects.length} Projects ·{' '}
            {quotations.length} Quotes · {payments.length} Payments · {subscriptions.length} Subscriptions ·{' '}
            {portfolio.length} Demos
          </p>
        </div>
      </div>

      {/* Vercel Deployment Documentation & Environment Variables */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-slate-700" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Vercel Deployment Guide & Environment Variables
              </h3>
              <p className="text-xs text-slate-500">
                How to deploy EMG Web Solutions growth system to your own Vercel domain
              </p>
            </div>
          </div>

          <button
            onClick={handleCopyEnv}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1 transition-colors"
          >
            {copiedEnv ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Env Vars</span>
              </>
            )}
          </button>
        </div>

        <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
          <p>
            This application is built with standard Vite + React and is 100% compatible with Vercel’s
            standard static hosting or custom domain:
          </p>
          <ol className="list-decimal pl-5 space-y-1 text-slate-700">
            <li>Push this repository to your GitHub account.</li>
            <li>Import the repository on <strong>vercel.com</strong>.</li>
            <li>Framework preset will automatically detect <strong>Vite</strong>.</li>
            <li>Build Command: <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">npm run build</code></li>
            <li>Output Directory: <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">dist</code></li>
            <li>Add the configuration environment variables below in Vercel Project Settings:</li>
          </ol>

          <pre className="p-3 bg-slate-900 text-emerald-400 rounded-lg font-mono text-[11px] overflow-x-auto leading-normal">
            {sampleEnv}
          </pre>
        </div>
      </div>
    </div>
  );
};
