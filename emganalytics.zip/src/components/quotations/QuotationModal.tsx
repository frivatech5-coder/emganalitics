import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, FileText, Check, AlertCircle, Building2, User } from 'lucide-react';
import { Quotation, QuotationItem, QuotationStatus, Lead, ServicePackage } from '../../types';
import { formatKenyanShillings } from '../../services/templates';

interface QuotationModalProps {
  isOpen: boolean;
  quotation?: Quotation | null;
  targetLead?: Lead | null;
  leads: Lead[];
  packages: ServicePackage[];
  onSave: (quoteData: Partial<Quotation> & { businessName: string; totalPrice: number }) => Promise<void>;
  onClose: () => void;
}

export const QuotationModal: React.FC<QuotationModalProps> = ({
  isOpen,
  quotation,
  targetLead,
  leads,
  packages,
  onSave,
  onClose,
}) => {
  const [selectedLeadId, setSelectedLeadId] = useState<string>('');
  const [businessName, setBusinessName] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [businessLocation, setBusinessLocation] = useState('Nairobi, Kenya');
  const [quoteNumber, setQuoteNumber] = useState('');
  const [services, setServices] = useState<QuotationItem[]>([]);
  const [scopeAndDeliverables, setScopeAndDeliverables] = useState('');
  const [depositType, setDepositType] = useState<'percentage' | 'fixed'>('percentage');
  const [depositValue, setDepositValue] = useState<number>(50); // 50%
  const [validityDays, setValidityDays] = useState<number>(14);
  const [paymentTerms, setPaymentTerms] = useState(
    '50% deposit payable before project kickoff via M-Pesa or Bank Transfer; 50% balance payable upon client review and live launch approval.'
  );
  const [status, setStatus] = useState<QuotationStatus>('Draft');
  const [sentDate, setSentDate] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // New service item inputs
  const [newServiceName, setNewServiceName] = useState('');
  const [newServicePrice, setNewServicePrice] = useState<number>(15000);

  useEffect(() => {
    if (quotation) {
      setSelectedLeadId(quotation.leadId || '');
      setBusinessName(quotation.businessName);
      setClientName(quotation.clientName);
      setClientEmail(quotation.clientEmail);
      setClientPhone(quotation.clientPhone);
      setBusinessLocation(quotation.businessLocation || 'Nairobi, Kenya');
      setQuoteNumber(quotation.quoteNumber);
      setServices(quotation.services || []);
      setScopeAndDeliverables(quotation.scopeAndDeliverables || '');
      setDepositType(quotation.depositType || 'percentage');
      setDepositValue(quotation.depositValue !== undefined ? quotation.depositValue : 50);
      setValidityDays(quotation.validityDays || 14);
      setPaymentTerms(quotation.paymentTerms || '');
      setStatus(quotation.status || 'Draft');
      setSentDate(quotation.sentDate || '');
    } else if (targetLead) {
      // Pre-fill from target lead
      setSelectedLeadId(targetLead.id);
      setBusinessName(targetLead.businessName);
      setClientName(targetLead.contactPerson);
      setClientEmail(targetLead.email || '');
      setClientPhone(targetLead.phone || '');
      setBusinessLocation(targetLead.location || 'Nairobi, Kenya');
      setQuoteNumber(`EMG-Q${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
      setStatus('Draft');

      const pkg = packages.find((p) => p.id === targetLead.assignedPackageId) || packages[1] || packages[0];
      if (pkg) {
        setServices([{ name: pkg.name, price: pkg.price, description: pkg.description }]);
        setScopeAndDeliverables(
          pkg.features.map((f, i) => `${i + 1}. ${f}`).join('\n') +
            `\n\nDelivery estimate: ${pkg.deliveryEstimate}\nSupport: ${pkg.supportPeriod}`
        );
      } else {
        setServices([{ name: 'Custom Website Design', price: targetLead.potentialValue || 35000 }]);
        setScopeAndDeliverables('Custom bespoke web solution tailored for client specifications.');
      }
    } else {
      // Blank proposal
      setSelectedLeadId('');
      setBusinessName('');
      setClientName('');
      setClientEmail('');
      setClientPhone('');
      setBusinessLocation('Nairobi, Kenya');
      setQuoteNumber(`EMG-Q${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
      setServices([{ name: 'Business Website Package', price: 35000 }]);
      setScopeAndDeliverables(
        '1. Custom responsive mobile-first web layout\n2. WhatsApp chat & click-to-call integration\n3. Google Maps location embed & local SEO setup\n4. 30 days post-launch support and SSL certificate'
      );
      setDepositType('percentage');
      setDepositValue(50);
      setValidityDays(14);
      setStatus('Draft');
      setSentDate('');
    }
  }, [quotation, targetLead, isOpen]);

  // When user selects a lead from dropdown
  const handleLeadSelect = (leadId: string) => {
    setSelectedLeadId(leadId);
    const l = leads.find((lead) => lead.id === leadId);
    if (l) {
      setBusinessName(l.businessName);
      setClientName(l.contactPerson);
      setClientEmail(l.email || '');
      setClientPhone(l.phone || '');
      setBusinessLocation(l.location || 'Nairobi, Kenya');

      const pkg = packages.find((p) => p.id === l.assignedPackageId) || packages[1] || packages[0];
      if (pkg && services.length === 0) {
        setServices([{ name: pkg.name, price: pkg.price }]);
      }
    }
  };

  const handleAddPackageService = (pkgId: string) => {
    const pkg = packages.find((p) => p.id === pkgId);
    if (!pkg) return;
    setServices([...services, { name: pkg.name, price: pkg.price, description: pkg.description }]);
    if (!scopeAndDeliverables.trim()) {
      setScopeAndDeliverables(pkg.features.join('\n'));
    }
  };

  const handleAddCustomService = () => {
    if (!newServiceName.trim()) return;
    setServices([...services, { name: newServiceName.trim(), price: Number(newServicePrice) || 0 }]);
    setNewServiceName('');
    setNewServicePrice(5000);
  };

  const handleRemoveService = (index: number) => {
    setServices(services.filter((_, i) => i !== index));
  };

  // Calculations
  const totalPrice = services.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
  const depositAmount =
    depositType === 'percentage'
      ? Math.round((totalPrice * depositValue) / 100)
      : Math.min(depositValue, totalPrice);
  const balanceDue = Math.max(0, totalPrice - depositAmount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessName.trim()) {
      setError('Business name is required.');
      return;
    }
    if (totalPrice <= 0) {
      setError('Please add at least one service item with a price greater than 0.');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      await onSave({
        id: quotation?.id,
        quoteNumber,
        leadId: selectedLeadId,
        businessName: businessName.trim(),
        clientName: clientName.trim() || 'Client',
        clientEmail: clientEmail.trim(),
        clientPhone: clientPhone.trim(),
        businessLocation,
        services,
        scopeAndDeliverables,
        totalPrice,
        depositType,
        depositValue,
        depositAmount,
        balanceDue,
        validityDays,
        paymentTerms,
        status,
        sentDate: sentDate || (status === 'Sent' ? new Date().toISOString().split('T')[0] : ''),
      });
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to save quotation.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-3xl bg-white border border-slate-200 rounded-xl shadow-2xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {quotation ? `Edit Quote ${quotation.quoteNumber}` : 'Create New Quotation'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              EMG Web Solutions formal scope, deposit terms, and deliverables calculation
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Select Lead & Quote Number */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Link to Prospect / Lead (Optional)
              </label>
              <select
                value={selectedLeadId}
                onChange={(e) => handleLeadSelect(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="">-- Manual Client Entry --</option>
                {leads.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.businessName} ({l.contactPerson})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Quotation Number *
              </label>
              <input
                type="text"
                required
                value={quoteNumber}
                onChange={(e) => setQuoteNumber(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono font-semibold border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Business & Client Contact Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Business Name *
              </label>
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g. Simba Builders Ltd"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Client Contact Person
              </label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="e.g. Patrick Mutiso"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                placeholder="+254 7..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
                placeholder="client@company.co.ke"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Location
              </label>
              <input
                type="text"
                value={businessLocation}
                onChange={(e) => setBusinessLocation(e.target.value)}
                placeholder="Nairobi, Kenya"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* Service Line Items */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Services & Deliverables Items
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-500">Quick add:</span>
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      handleAddPackageService(e.target.value);
                      e.target.value = '';
                    }
                  }}
                  className="text-xs bg-white border border-slate-300 rounded px-2 py-1"
                >
                  <option value="">Choose Catalog Package...</option>
                  {packages.map((pkg) => (
                    <option key={pkg.id} value={pkg.id}>
                      {pkg.name} ({formatKenyanShillings(pkg.price)})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Existing Items */}
            <div className="space-y-2">
              {services.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between gap-3 p-2.5 bg-white border border-slate-200 rounded-lg text-xs"
                >
                  <div className="flex-1 min-w-0">
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => {
                        const updated = [...services];
                        updated[idx].name = e.target.value;
                        setServices(updated);
                      }}
                      className="font-medium text-slate-900 w-full border-b border-transparent hover:border-slate-300 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div className="w-32 shrink-0">
                    <input
                      type="number"
                      step="500"
                      value={item.price}
                      onChange={(e) => {
                        const updated = [...services];
                        updated[idx].price = Number(e.target.value);
                        setServices(updated);
                      }}
                      className="font-mono text-right font-bold text-slate-800 w-full px-2 py-1 border border-slate-200 rounded"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveService(idx)}
                    className="text-slate-400 hover:text-red-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Custom Item Row */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-200">
              <input
                type="text"
                placeholder="Item name (e.g. .co.ke Domain Registration, SEO Copywriting...)"
                value={newServiceName}
                onChange={(e) => setNewServiceName(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
              />
              <input
                type="number"
                step="500"
                placeholder="Price (KSh)"
                value={newServicePrice}
                onChange={(e) => setNewServicePrice(Number(e.target.value))}
                className="w-28 px-3 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
              />
              <button
                type="button"
                onClick={handleAddCustomService}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Add Item
              </button>
            </div>
          </div>

          {/* Scope and Deliverables Details */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Detailed Scope & Deliverables (Included in formal PDF)
            </label>
            <textarea
              rows={4}
              value={scopeAndDeliverables}
              onChange={(e) => setScopeAndDeliverables(e.target.value)}
              placeholder="List specific pages, integrations, responsive specifications, and post-launch guarantees..."
              className="w-full px-3 py-2 text-xs font-sans leading-relaxed border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Price, Deposit & Balance Calculations */}
          <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-semibold text-emerald-950 mb-1">
                  Total Project Price
                </label>
                <div className="text-xl font-bold font-mono text-emerald-950 tabular-nums">
                  {formatKenyanShillings(totalPrice)}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-emerald-950 mb-1">
                  Deposit Setting
                </label>
                <div className="flex items-center gap-2">
                  <select
                    value={depositType}
                    onChange={(e) => setDepositType(e.target.value as any)}
                    className="text-xs bg-white border border-emerald-300 rounded px-2 py-1 font-medium"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount (KSh)</option>
                  </select>
                  <input
                    type="number"
                    value={depositValue}
                    onChange={(e) => setDepositValue(Number(e.target.value))}
                    className="w-20 px-2 py-1 text-xs font-mono bg-white border border-emerald-300 rounded font-bold"
                  />
                </div>
                <span className="text-[11px] text-emerald-800 font-mono mt-1 block">
                  Deposit: {formatKenyanShillings(depositAmount)}
                </span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-emerald-950 mb-1">
                  Balance Due (Post-Launch)
                </label>
                <div className="text-xl font-bold font-mono text-emerald-900 tabular-nums">
                  {formatKenyanShillings(balanceDue)}
                </div>
              </div>
            </div>
          </div>

          {/* Terms & Proposal Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Terms
              </label>
              <textarea
                rows={2}
                value={paymentTerms}
                onChange={(e) => setPaymentTerms(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Quotation Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as QuotationStatus)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-medium"
                >
                  <option value="Draft">Draft (Internal review)</option>
                  <option value="Sent">Sent (Delivered to client)</option>
                  <option value="Negotiating">Negotiating</option>
                  <option value="Accepted">Accepted (Deal Won)</option>
                  <option value="Declined">Declined</option>
                  <option value="Expired">Expired</option>
                </select>
              </div>
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                    Validity (Days)
                  </label>
                  <input
                    type="number"
                    value={validityDays}
                    onChange={(e) => setValidityDays(Number(e.target.value))}
                    className="w-full px-2.5 py-1 text-xs border border-slate-300 rounded-md"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                    Sent Date
                  </label>
                  <input
                    type="date"
                    value={sentDate}
                    onChange={(e) => setSentDate(e.target.value)}
                    className="w-full px-2.5 py-1 text-xs border border-slate-300 rounded-md"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 text-xs text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Saving...' : quotation ? 'Update Quotation' : 'Create Quotation'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
