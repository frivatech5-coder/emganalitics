import React, { useState } from 'react';
import { X, Plus, Trash2, Edit, Check, AlertCircle, Sparkles } from 'lucide-react';
import { ServicePackage } from '../../types';
import { savePackage, deletePackage } from '../../services/db';
import { formatKenyanShillings } from '../../services/templates';

interface PackagesModalProps {
  isOpen: boolean;
  packages: ServicePackage[];
  onClose: () => void;
  onRefresh: () => void;
}

export const PackagesModal: React.FC<PackagesModalProps> = ({
  isOpen,
  packages,
  onClose,
  onRefresh,
}) => {
  const [editingPkg, setEditingPkg] = useState<Partial<ServicePackage> | null>(null);
  const [featureInput, setFeatureInput] = useState('');
  const [exclusionInput, setExclusionInput] = useState('');
  const [addOnInput, setAddOnInput] = useState('');
  const [saving, setSaving] = useState(false);

  if (!isOpen) return null;

  const handleStartEdit = (pkg?: ServicePackage) => {
    if (pkg) {
      setEditingPkg({ ...pkg });
    } else {
      setEditingPkg({
        id: `pkg-${Date.now()}`,
        name: '',
        price: 35000,
        description: '',
        pages: '5 - 7 Pages',
        deliveryEstimate: '7 - 10 business days',
        supportPeriod: '30 days',
        features: ['Mobile responsive design', 'WhatsApp button', 'Free SSL certificate'],
        exclusions: ['E-commerce payment gateway'],
        optionalAddOns: ['.co.ke Domain registration (KSh 1,200/yr)'],
        isRecurring: false,
        createdAt: new Date().toISOString(),
      });
    }
    setFeatureInput('');
    setExclusionInput('');
    setAddOnInput('');
  };

  const handleSavePackage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPkg || !editingPkg.name) return;
    setSaving(true);
    try {
      await savePackage(editingPkg as ServicePackage);
      setEditingPkg(null);
      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  const handleDeletePackage = async (id: string) => {
    if (window.confirm('Delete this service package?')) {
      await deletePackage(id);
      onRefresh();
    }
  };

  const addFeature = () => {
    if (!featureInput.trim() || !editingPkg) return;
    setEditingPkg({
      ...editingPkg,
      features: [...(editingPkg.features || []), featureInput.trim()],
    });
    setFeatureInput('');
  };

  const removeFeature = (idx: number) => {
    if (!editingPkg) return;
    setEditingPkg({
      ...editingPkg,
      features: (editingPkg.features || []).filter((_, i) => i !== idx),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-3xl bg-white border border-slate-200 rounded-xl shadow-2xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Service Package & Pricing Catalog
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Manage editable baseline packages used for proposals and quotations
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {editingPkg ? (
            /* EDIT FORM */
            <form onSubmit={handleSavePackage} className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="text-xs font-bold text-slate-900">
                  {editingPkg.id?.startsWith('pkg-') && !packages.some((p) => p.id === editingPkg.id)
                    ? 'Create New Service Package'
                    : `Editing "${editingPkg.name}"`}
                </span>
                <button
                  type="button"
                  onClick={() => setEditingPkg(null)}
                  className="text-xs text-slate-500 hover:underline"
                >
                  Back to catalog
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Package Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingPkg.name || ''}
                    onChange={(e) => setEditingPkg({ ...editingPkg, name: e.target.value })}
                    placeholder="e.g. Starter Website"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Base Price (KSh) *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="500"
                    value={editingPkg.price || 0}
                    onChange={(e) => setEditingPkg({ ...editingPkg, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Target Audience & Summary Description
                </label>
                <textarea
                  rows={2}
                  value={editingPkg.description || ''}
                  onChange={(e) => setEditingPkg({ ...editingPkg, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Pages Scope
                  </label>
                  <input
                    type="text"
                    value={editingPkg.pages || ''}
                    onChange={(e) => setEditingPkg({ ...editingPkg, pages: e.target.value })}
                    placeholder="e.g. 5 Pages"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Delivery Estimate
                  </label>
                  <input
                    type="text"
                    value={editingPkg.deliveryEstimate || ''}
                    onChange={(e) => setEditingPkg({ ...editingPkg, deliveryEstimate: e.target.value })}
                    placeholder="e.g. 7 - 10 business days"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Post-Launch Support
                  </label>
                  <input
                    type="text"
                    value={editingPkg.supportPeriod || ''}
                    onChange={(e) => setEditingPkg({ ...editingPkg, supportPeriod: e.target.value })}
                    placeholder="e.g. 30 days"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Features List */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Included Features ({editingPkg.features?.length || 0})
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={featureInput}
                    onChange={(e) => setFeatureInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addFeature();
                      }
                    }}
                    placeholder="Add feature and press Enter (e.g. WhatsApp floating button)"
                    className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={addFeature}
                    className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                  >
                    Add
                  </button>
                </div>
                <div className="space-y-1 max-h-36 overflow-y-auto">
                  {editingPkg.features?.map((f, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between px-2.5 py-1 text-xs bg-slate-50 border border-slate-200 rounded-md"
                    >
                      <span className="text-slate-700">{f}</span>
                      <button
                        type="button"
                        onClick={() => removeFeature(i)}
                        className="text-slate-400 hover:text-red-600"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingPkg(null)}
                  className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Package'}
                </button>
              </div>
            </form>
          ) : (
            /* CATALOG LIST */
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-2">
                <span className="text-xs font-semibold text-slate-600">
                  {packages.length} active service packages
                </span>
                <button
                  onClick={() => handleStartEdit()}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Create Package</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {packages.map((pkg) => (
                  <div
                    key={pkg.id}
                    className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 hover:border-slate-300 transition-colors flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <h4 className="font-bold text-sm text-slate-900">{pkg.name}</h4>
                          <span className="text-[11px] text-slate-400">{pkg.pages}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-base font-bold font-mono text-emerald-800 tabular-nums">
                            {formatKenyanShillings(pkg.price)}
                          </span>
                          {pkg.isRecurring && (
                            <span className="text-[10px] text-slate-400 block font-mono">/month</span>
                          )}
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 mb-3 leading-relaxed">
                        {pkg.description}
                      </p>

                      <div className="space-y-1 mb-3">
                        {pkg.features?.slice(0, 3).map((f, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-[11px] text-slate-700 truncate">
                            <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                            <span className="truncate">{f}</span>
                          </div>
                        ))}
                        {(pkg.features?.length || 0) > 3 && (
                          <span className="text-[10px] text-slate-400 pl-4">
                            +{(pkg.features?.length || 0) - 3} more deliverables
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                      <span className="text-[11px] text-slate-400">
                        Est: {pkg.deliveryEstimate || '5-7 days'}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleStartEdit(pkg)}
                          className="p-1 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-200"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeletePackage(pkg.id)}
                          className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
