import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Printer,
  Edit,
  Trash2,
  CheckCircle2,
  AlertCircle,
  PackageCheck,
  Search,
  ArrowRight,
  Send,
  Eye,
  Briefcase,
} from 'lucide-react';
import { Quotation, QuotationStatus, ServicePackage, Lead, Client } from '../../types';
import { formatKenyanShillings } from '../../services/templates';
import { EmptyState } from '../common/EmptyState';
import { ConfirmModal } from '../common/ConfirmModal';

interface QuotationsViewProps {
  quotations: Quotation[];
  packages: ServicePackage[];
  leads: Lead[];
  onOpenNewQuote: () => void;
  onOpenPackagesModal: () => void;
  onEditQuote: (quote: Quotation) => void;
  onPreviewQuote: (quote: Quotation) => void;
  onDeleteQuote: (id: string) => void;
  onUpdateQuoteStatus: (id: string, status: QuotationStatus) => void;
  onConvertToClient: (quote: Quotation) => void;
}

export const QuotationsView: React.FC<QuotationsViewProps> = ({
  quotations,
  packages,
  leads,
  onOpenNewQuote,
  onOpenPackagesModal,
  onEditQuote,
  onPreviewQuote,
  onDeleteQuote,
  onUpdateQuoteStatus,
  onConvertToClient,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filteredQuotes = quotations.filter((q) => {
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      const matchNum = q.quoteNumber?.toLowerCase().includes(query);
      const matchBiz = q.businessName?.toLowerCase().includes(query);
      const matchClient = q.clientName?.toLowerCase().includes(query);
      if (!matchNum && !matchBiz && !matchClient) return false;
    }
    if (statusFilter !== 'all' && q.status !== statusFilter) {
      return false;
    }
    return true;
  });

  const totalValue = filteredQuotes.reduce((sum, q) => sum + (Number(q.totalPrice) || 0), 0);
  const acceptedValue = filteredQuotes
    .filter((q) => q.status === 'Accepted')
    .reduce((sum, q) => sum + (Number(q.totalPrice) || 0), 0);

  return (
    <div className="space-y-4">
      {/* Control Strip */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by quote number, business, or client..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={onOpenPackagesModal}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-1.5"
            >
              <PackageCheck className="w-3.5 h-3.5 text-slate-600" />
              <span>Service Packages Catalog ({packages.length})</span>
            </button>

            <button
              onClick={onOpenNewQuote}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Generate Quotation</span>
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 flex-wrap text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <span className="text-slate-400 text-[11px] font-medium mr-1">Status:</span>
            {['all', 'Draft', 'Sent', 'Negotiating', 'Accepted', 'Declined', 'Expired'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors capitalize ${
                  statusFilter === st
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <div className="text-right text-[11px] text-slate-500">
            <span>
              Total Proposals Value:{' '}
              <strong className="text-slate-900 font-mono">
                {formatKenyanShillings(totalValue)}
              </strong>
            </span>
          </div>
        </div>
      </div>

      {/* Quotations List */}
      {filteredQuotes.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="No quotations generated"
          description="Create customized quotations with scope breakdowns, Kenyan payment terms, and 50% deposit calculations."
          actionLabel="Generate First Quotation"
          onAction={onOpenNewQuote}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredQuotes.map((quote) => {
            const isAccepted = quote.status === 'Accepted';

            return (
              <div
                key={quote.id}
                className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs hover:border-slate-300 transition-colors flex flex-col justify-between space-y-4"
              >
                <div>
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-slate-400">
                        {quote.quoteNumber}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 leading-tight">
                        {quote.businessName}
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                        Attn: {quote.clientName}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <select
                        value={quote.status}
                        onChange={(e) =>
                          onUpdateQuoteStatus(quote.id, e.target.value as QuotationStatus)
                        }
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded border focus:outline-none ${
                          quote.status === 'Accepted'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : quote.status === 'Sent'
                            ? 'bg-purple-50 text-purple-800 border-purple-200'
                            : quote.status === 'Declined'
                            ? 'bg-red-50 text-red-800 border-red-200'
                            : 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        <option value="Draft">Draft</option>
                        <option value="Sent">Sent</option>
                        <option value="Negotiating">Negotiating</option>
                        <option value="Accepted">Accepted</option>
                        <option value="Declined">Declined</option>
                        <option value="Expired">Expired</option>
                      </select>
                    </div>
                  </div>

                  {/* Pricing Breakdown */}
                  <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg space-y-1.5 text-xs my-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Total Project Value:</span>
                      <span className="font-mono font-bold text-slate-900 tabular-nums">
                        {formatKenyanShillings(quote.totalPrice)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-600">
                      <span>Initial Deposit ({quote.depositValue}%):</span>
                      <span className="font-mono text-emerald-700 font-semibold tabular-nums">
                        {formatKenyanShillings(quote.depositAmount)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-600">
                      <span>Balance on Launch:</span>
                      <span className="font-mono tabular-nums">
                        {formatKenyanShillings(quote.balanceDue)}
                      </span>
                    </div>
                  </div>

                  {/* Scope items count */}
                  <div className="text-[11px] text-slate-500 flex items-center justify-between">
                    <span>
                      {quote.services?.length || 0} scope deliverable(s)
                    </span>
                    <span className="font-mono text-[10px]">
                      {quote.sentDate ? `Sent: ${quote.sentDate}` : 'Not sent yet'}
                    </span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onPreviewQuote(quote)}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded flex items-center gap-1 transition-colors"
                      title="Preview and print formal quotation"
                    >
                      <Printer className="w-3 h-3 text-slate-600" />
                      <span>Print / PDF</span>
                    </button>
                    <button
                      onClick={() => onEditQuote(quote)}
                      className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                      title="Edit quote"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteId(quote.id)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                      title="Delete quote"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {isAccepted && (
                    <button
                      onClick={() => onConvertToClient(quote)}
                      className="px-2.5 py-1 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded flex items-center gap-1 shadow-xs"
                      title="Convert to active client project"
                    >
                      <Briefcase className="w-3 h-3" />
                      <span>Convert Client</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={Boolean(deleteId)}
        title="Delete Quotation"
        message="Are you sure you want to permanently delete this quotation record?"
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteId) onDeleteQuote(deleteId);
          setDeleteId(null);
        }}
        onClose={() => setDeleteId(null)}
      />
    </div>
  );
};
