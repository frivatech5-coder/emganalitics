import React from 'react';
import { X, Printer, Download, Check, Building2, Shield, Calendar, Mail, Phone, Globe } from 'lucide-react';
import { Quotation } from '../../types';
import { formatKenyanShillings } from '../../services/templates';

interface QuotationPrintViewProps {
  quotation: Quotation | null;
  onClose: () => void;
}

export const QuotationPrintView: React.FC<QuotationPrintViewProps> = ({
  quotation,
  onClose,
}) => {
  if (!quotation) return null;

  const handlePrint = () => {
    window.print();
  };

  const createdDate = new Date(quotation.createdAt).toLocaleDateString('en-KE', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const validUntilDate = new Date(
    new Date(quotation.createdAt).getTime() + (quotation.validityDays || 14) * 24 * 60 * 60 * 1000
  ).toLocaleDateString('en-KE', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-4xl bg-white rounded-xl shadow-2xl my-6 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Top Control Bar (Hidden on print) */}
        <div className="px-6 py-3.5 bg-slate-900 text-white flex items-center justify-between no-print shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
              {quotation.status}
            </span>
            <span className="text-sm font-bold tracking-tight">
              Quotation Preview #{quotation.quoteNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Formal Printable Document Viewport */}
        <div className="flex-1 overflow-y-auto p-8 md:p-12 print-container bg-white text-slate-900 font-sans">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start gap-6 pb-8 border-b-2 border-slate-900">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-bold text-sm">
                  EMG
                </div>
                <h1 className="text-xl font-bold tracking-tight text-slate-950">
                  EMG Web Solutions
                </h1>
              </div>
              <p className="text-xs text-slate-600 mt-1">
                Custom Web Development & Digital Growth Systems
              </p>
              <div className="mt-3 text-xs text-slate-500 space-y-0.5 font-mono">
                <p>Nairobi, Kenya</p>
                <p>Website: https://emgwebsolutions.vercel.app</p>
                <p>Inquiries: contact@emgwebsolutions.co.ke</p>
              </div>
            </div>

            <div className="text-left md:text-right">
              <span className="text-2xl font-black tracking-tight uppercase text-slate-900 block">
                Formal Quotation
              </span>
              <p className="text-xs font-mono font-bold text-emerald-800 mt-1">
                Quote Ref: {quotation.quoteNumber}
              </p>
              <div className="mt-3 text-xs text-slate-600 space-y-0.5">
                <p>
                  <span className="text-slate-400">Date Issued:</span> {createdDate}
                </p>
                <p>
                  <span className="text-slate-400">Valid Until:</span> {validUntilDate} ({quotation.validityDays} days)
                </p>
              </div>
            </div>
          </div>

          {/* Client Recipient Info */}
          <div className="py-6 border-b border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Quotation Prepared For:
              </span>
              <h3 className="text-base font-bold text-slate-900">
                {quotation.businessName}
              </h3>
              <p className="text-xs text-slate-700 mt-0.5">
                Attn: {quotation.clientName}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                {quotation.businessLocation}
              </p>
              {(quotation.clientPhone || quotation.clientEmail) && (
                <p className="text-xs font-mono text-slate-500 mt-1">
                  {quotation.clientPhone} {quotation.clientEmail && `· ${quotation.clientEmail}`}
                </p>
              )}
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 text-xs">
              <span className="font-bold text-slate-900 block mb-1">
                Project Objective & Commitment
              </span>
              <p className="text-slate-600 leading-relaxed">
                EMG Web Solutions commits to delivering a high-performance web platform designed to convert
                inquiries into paying clients, optimized for Kenyan mobile connectivity and search ranking.
              </p>
            </div>
          </div>

          {/* Services & Deliverables Table */}
          <div className="py-6">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-3">
              Itemized Scope & Deliverables
            </span>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-200 text-slate-500 text-[11px] font-bold uppercase">
                  <th className="py-2.5 px-3">Item / Description</th>
                  <th className="py-2.5 px-3 text-right">Amount (KSh)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {quotation.services.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900">{item.name}</p>
                      {item.description && (
                        <p className="text-[11px] text-slate-500 mt-0.5">{item.description}</p>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatKenyanShillings(item.price)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Scope Details Block */}
            {quotation.scopeAndDeliverables && (
              <div className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                <span className="font-bold text-slate-900 block mb-1">
                  Deliverables Breakdown & Standards:
                </span>
                <p className="text-slate-700 whitespace-pre-line leading-relaxed font-sans">
                  {quotation.scopeAndDeliverables}
                </p>
              </div>
            )}
          </div>

          {/* Total, Deposit & Balance Calculations */}
          <div className="py-4 border-t-2 border-slate-900 flex justify-end">
            <div className="w-full max-w-sm space-y-2 text-xs">
              <div className="flex justify-between py-1 text-slate-600">
                <span>Subtotal / Project Total:</span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {formatKenyanShillings(quotation.totalPrice)}
                </span>
              </div>

              <div className="flex justify-between py-1 text-emerald-900 font-semibold bg-emerald-50 px-2 rounded">
                <span>Initial Deposit Required ({quotation.depositValue}%):</span>
                <span className="font-mono font-bold text-emerald-800 tabular-nums">
                  {formatKenyanShillings(quotation.depositAmount)}
                </span>
              </div>

              <div className="flex justify-between py-1.5 border-t border-slate-200 text-slate-900 font-bold">
                <span>Balance Due Upon Completion:</span>
                <span className="font-mono text-sm tabular-nums">
                  {formatKenyanShillings(quotation.balanceDue)}
                </span>
              </div>
            </div>
          </div>

          {/* Payment Terms & Instructions */}
          <div className="mt-6 pt-6 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div>
              <span className="font-bold text-slate-900 uppercase tracking-wide text-[11px] block mb-1">
                Payment Milestones & Terms
              </span>
              <p className="text-slate-600 leading-relaxed mb-3">
                {quotation.paymentTerms}
              </p>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <p className="font-bold text-slate-900">Settlement Channels:</p>
                <p className="text-slate-600">
                  • <strong>M-Pesa:</strong> Buy Goods Till / Paybill (Details issued on invoice)
                </p>
                <p className="text-slate-600">
                  • <strong>Bank Transfer:</strong> Direct EFT / RTGS to EMG Web Solutions
                </p>
              </div>
            </div>

            <div className="flex flex-col justify-between">
              <div>
                <span className="font-bold text-slate-900 uppercase tracking-wide text-[11px] block mb-1">
                  Acceptance & Authorization
                </span>
                <p className="text-slate-500 text-[11px] leading-relaxed mb-8">
                  To accept this quotation and schedule your project sprint, please sign below or confirm via
                  written email/WhatsApp response.
                </p>
              </div>

              <div className="border-t border-slate-300 pt-2 flex justify-between text-[11px] text-slate-500">
                <div>
                  <p className="font-semibold text-slate-700">Authorized Signature</p>
                  <p>EMG Web Solutions</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-slate-700">Client Approval</p>
                  <p>{quotation.businessName}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
