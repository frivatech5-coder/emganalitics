import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Download,
  DollarSign,
  PieChart,
  HelpCircle,
  FileSpreadsheet,
  Target,
  Users,
} from 'lucide-react';
import { Lead, Client, Payment, Subscription, Quotation, ContactLog } from '../../types';
import { formatKenyanShillings } from '../../services/templates';

interface ReportsViewProps {
  leads: Lead[];
  clients: Client[];
  payments: Payment[];
  subscriptions: Subscription[];
  quotations: Quotation[];
  contactLogs: ContactLog[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  leads,
  clients,
  payments,
  subscriptions,
  quotations,
  contactLogs,
}) => {
  // Calculations strictly from saved records
  const totalLeads = leads.length;
  const contactedLeads = leads.filter((l) => l.status !== 'New').length;
  const respondedLeads = leads.filter((l) =>
    ['Responded', 'Interested', 'Needs analysis', 'Proposal sent', 'Negotiating', 'Won'].includes(l.status)
  ).length;
  const interestedLeads = leads.filter((l) =>
    ['Interested', 'Needs analysis', 'Proposal sent', 'Negotiating', 'Won'].includes(l.status)
  ).length;
  const proposalsSent = quotations.length;
  const dealsWon = leads.filter((l) => l.status === 'Won').length || clients.length;
  const dealsLost = leads.filter((l) => l.status === 'Lost').length;

  // Rate calculations
  const responseRate = contactedLeads > 0 ? Math.round((respondedLeads / contactedLeads) * 100) : 0;
  const interestedRate = contactedLeads > 0 ? Math.round((interestedLeads / contactedLeads) * 100) : 0;

  const closedDeals = dealsWon + dealsLost;
  const dealConversionRate =
    closedDeals > 0
      ? Math.round((dealsWon / closedDeals) * 100)
      : totalLeads > 0
      ? Math.round((dealsWon / totalLeads) * 100)
      : 0;

  // Average Project Value
  const totalAgreedValue = clients.reduce((sum, c) => sum + (c.agreedProjectPrice || 0), 0);
  const averageProjectValue = clients.length > 0 ? Math.round(totalAgreedValue / clients.length) : 35000;

  // Confirmed revenue collected
  const confirmedPayments = payments.filter((p) => p.paymentStatus === 'Confirmed');
  const revenueCollected = confirmedPayments.reduce((sum, p) => sum + (p.amount || 0), 0);

  // Outstanding client balances
  const outstandingBalances = clients.reduce((sum, c) => sum + (c.remainingBalance || 0), 0);

  // Expected MRR
  const mrr = subscriptions
    .filter((s) => s.status === 'Active')
    .reduce((sum, s) => sum + (s.monthlyFee || 0), 0);

  // Lead Source Effectiveness
  const sourceStats = leads.reduce((acc, lead) => {
    const src = lead.source || 'Other';
    if (!acc[src]) {
      acc[src] = { total: 0, won: 0, potentialValue: 0 };
    }
    acc[src].total += 1;
    if (lead.status === 'Won') acc[src].won += 1;
    acc[src].potentialValue += Number(lead.potentialValue) || Number(lead.estimatedBudget) || 0;
    return acc;
  }, {} as Record<string, { total: number; won: number; potentialValue: number }>);

  // Export Report to CSV
  const handleExportReportCSV = () => {
    const reportData = [
      ['Metric', 'Value', 'Formula / Definition'],
      ['Total Leads', totalLeads, 'Total saved prospect records in database'],
      ['Contacted Leads', contactedLeads, 'Leads with status != "New"'],
      ['Response Rate', `${responseRate}%`, '(Responded Leads / Contacted Leads) * 100'],
      ['Interested Prospect Rate', `${interestedRate}%`, '(Interested Leads / Contacted Leads) * 100'],
      ['Formal Proposals Sent', proposalsSent, 'Total generated Quotations'],
      ['Deals Won', dealsWon, 'Leads converted to clients or status == "Won"'],
      ['Deal Conversion Rate', `${dealConversionRate}%`, '(Deals Won / Closed Opportunities) * 100'],
      ['Average Project Value', `KSh ${averageProjectValue.toLocaleString('en-KE')}`, 'Total Agreed Price of Won Clients / Count of Clients'],
      ['Revenue Actually Collected', `KSh ${revenueCollected.toLocaleString('en-KE')}`, 'Sum of all confirmed M-Pesa, Bank, and Cash payment records'],
      ['Outstanding Client Balances', `KSh ${outstandingBalances.toLocaleString('en-KE')}`, 'Sum of remaining uncollected balances on active clients'],
      ['Expected Monthly Recurring Revenue (MRR)', `KSh ${mrr.toLocaleString('en-KE')}`, 'Sum of active maintenance subscription monthly fees'],
    ];

    const csvContent = reportData.map((row) => row.map((cell) => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `emg-business-report-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            EMG Web Solutions Business Performance Insights
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Calculated strictly from verified database records. Formula transparently defined.
          </p>
        </div>

        <button
          onClick={handleExportReportCSV}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg flex items-center gap-1.5 shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Analytics Report (CSV)</span>
        </button>
      </div>

      {/* Conversion Funnel Table & Mathematical Definitions */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">
            Pipeline Conversion Ratios & Exact Definitions
          </span>
          <span className="text-[11px] text-slate-400">
            Truth in metrics: correlation does not imply causation
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Metric</th>
                <th className="py-3 px-4 text-right">Current Value</th>
                <th className="py-3 px-4">Mathematical Formula / Derivation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-900">Prospect Response Rate</td>
                <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                  {responseRate}%
                </td>
                <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                  (Responded Prospects / Total Contacted Leads) × 100 [{respondedLeads}/{contactedLeads || 1}]
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-900">Interested Prospect Rate</td>
                <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                  {interestedRate}%
                </td>
                <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                  (Interested + Negotiating + Won / Total Contacted Leads) × 100 [{interestedLeads}/{contactedLeads || 1}]
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-900">Proposal Close / Won Rate</td>
                <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800 tabular-nums">
                  {dealConversionRate}%
                </td>
                <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                  (Deals Won / Total Closed Outcomes) × 100 [{dealsWon}/{closedDeals || totalLeads || 1}]
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-900">Average Client Contract Price</td>
                <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                  {formatKenyanShillings(averageProjectValue)}
                </td>
                <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                  Total Agreed Price across all converted clients / Count of paying clients
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-900">Monthly Recurring Revenue (MRR)</td>
                <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800 tabular-nums">
                  {formatKenyanShillings(mrr)}/mo
                </td>
                <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                  Sum of active monthly maintenance retainers ({subscriptions.filter((s) => s.status === 'Active').length} subscriptions)
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Lead Channel Effectiveness */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 bg-slate-50">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
            Lead Source Channel Performance
          </h4>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Evaluate which marketing or outreach channels yield the highest conversion and deal volume
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Acquisition Channel</th>
                <th className="py-3 px-4 text-right">Total Leads</th>
                <th className="py-3 px-4 text-right">Deals Won</th>
                <th className="py-3 px-4 text-right">Conversion %</th>
                <th className="py-3 px-4 text-right">Pipeline Value</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {Object.keys(sourceStats).length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    No lead records logged yet to generate source performance.
                  </td>
                </tr>
              ) : (
                Object.entries(sourceStats).map(([src, stat]) => {
                  const rate = stat.total > 0 ? Math.round((stat.won / stat.total) * 100) : 0;
                  return (
                    <tr key={src} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-semibold text-slate-900">{src}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{stat.total}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800 tabular-nums">
                        {stat.won}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold tabular-nums">
                        {rate}%
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-800 tabular-nums">
                        {formatKenyanShillings(stat.potentialValue)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
