import React, { useState } from 'react';
import {
  Sparkles,
  Plus,
  Globe,
  Copy,
  Check,
  ExternalLink,
  Edit,
  Trash2,
  CheckCircle2,
  Tag,
  Building2,
  Search,
  Filter,
} from 'lucide-react';
import { PortfolioItem, Lead } from '../../types';
import { EmptyState } from '../common/EmptyState';
import { ConfirmModal } from '../common/ConfirmModal';

interface PortfolioViewProps {
  portfolio: PortfolioItem[];
  leads: Lead[];
  onOpenNewItem: () => void;
  onEditItem: (item: PortfolioItem) => void;
  onDeleteItem: (id: string) => void;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  portfolio,
  leads,
  onOpenNewItem,
  onEditItem,
  onDeleteItem,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filteredItems = portfolio.filter((item) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.name?.toLowerCase().includes(q);
      const matchCat = item.category?.toLowerCase().includes(q);
      const matchType = item.projectType?.toLowerCase().includes(q);
      if (!matchName && !matchCat && !matchType) return false;
    }
    if (categoryFilter !== 'all' && item.category !== categoryFilter) return false;
    if (statusFilter !== 'all' && item.status !== statusFilter) return false;
    return true;
  });

  const handleCopyLink = (item: PortfolioItem) => {
    navigator.clipboard.writeText(item.liveUrl);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Distinct categories
  const categories = Array.from(new Set(portfolio.map((p) => p.category))).filter(Boolean);

  return (
    <div className="space-y-4">
      {/* Top Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search demos by industry or project name..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenNewItem}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Demo / Showcase</span>
            </button>
          </div>
        </div>

        {/* Filter chips */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 flex-wrap text-xs">
          <div className="flex items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="all">All Statuses ({portfolio.length})</option>
              <option value="Concept demo">Concept Demos Only</option>
              <option value="Client project">Active Client Work</option>
              <option value="Completed project">Completed Projects</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-2.5 py-1 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="all">All Industries</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <span className="text-[11px] text-slate-400">
            Concept demos are labeled transparently for prospects
          </span>
        </div>
      </div>

      {/* Demos Grid */}
      {filteredItems.length === 0 ? (
        <EmptyState
          icon={Sparkles}
          title="No demos in catalog"
          description="Create live concept demos for key Kenyan niches (Safari, Hardware, Law Firms, Clinics) to pitch prospects with concrete visual evidence."
          actionLabel="Add Industry Demo"
          onAction={onOpenNewItem}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredItems.map((item) => {
            const isConcept = item.status === 'Concept demo';
            const relatedLead = leads.find((l) => l.id === item.relatedLeadId);

            return (
              <div
                key={item.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs hover:border-slate-300 transition-colors flex flex-col justify-between"
              >
                <div className="p-5 space-y-3">
                  {/* Category & Status */}
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-semibold text-slate-500 text-[11px]">
                      {item.category}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-mono font-semibold ${
                        isConcept
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  {/* Title & Type */}
                  <div>
                    <h4 className="text-base font-bold text-slate-900 leading-snug">
                      {item.name}
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {item.projectType}
                    </p>
                  </div>

                  {/* Live URL */}
                  <div className="p-2.5 bg-slate-50 border border-slate-200/80 rounded-lg flex items-center justify-between gap-2">
                    <a
                      href={item.liveUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs text-emerald-700 hover:underline flex items-center gap-1.5 font-mono truncate"
                    >
                      <Globe className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                      <span className="truncate">{item.liveUrl}</span>
                      <ExternalLink className="w-3 h-3 shrink-0" />
                    </a>

                    <button
                      onClick={() => handleCopyLink(item)}
                      className="p-1 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-200 shrink-0"
                      title="Copy URL for outreach pitch"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  {/* Features Demonstrated */}
                  {item.featuresDemonstrated && item.featuresDemonstrated.length > 0 && (
                    <div className="space-y-1 text-xs">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                        Features Demonstrated
                      </span>
                      {item.featuresDemonstrated.map((feat, idx) => (
                        <p key={idx} className="text-slate-600 flex items-start gap-1.5 leading-snug">
                          <span className="text-emerald-600 font-bold shrink-0">•</span>
                          <span>{feat}</span>
                        </p>
                      ))}
                    </div>
                  )}

                  {/* Features Tested */}
                  {item.featuresTested && item.featuresTested.length > 0 && (
                    <div className="pt-2 border-t border-slate-100 text-xs">
                      <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block mb-1">
                        Verified & Tested
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {item.featuresTested.map((test, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] rounded"
                          >
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>{test}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {relatedLead && (
                    <p className="text-[11px] text-slate-500 pt-1">
                      Pitched to lead: <strong>{relatedLead.businessName}</strong>
                    </p>
                  )}
                </div>

                {/* Footer Controls */}
                <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-400">
                    {new Date(item.createdAt).toLocaleDateString('en-KE')}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCopyLink(item)}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded hover:bg-slate-100 flex items-center gap-1"
                    >
                      {copiedId === item.id ? 'Copied!' : 'Copy Link'}
                    </button>
                    <button
                      onClick={() => onEditItem(item)}
                      className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-200"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteId(item.id)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Item Confirm */}
      <ConfirmModal
        isOpen={Boolean(deleteId)}
        title="Delete Portfolio Demo"
        message="Are you sure you want to delete this portfolio demo link?"
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteId) onDeleteItem(deleteId);
          setDeleteId(null);
        }}
        onClose={() => setDeleteId(null)}
      />
    </div>
  );
};
