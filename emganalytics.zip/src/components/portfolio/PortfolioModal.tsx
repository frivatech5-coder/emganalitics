import React, { useState, useEffect } from 'react';
import { X, Sparkles, Check, AlertCircle, Globe, Link } from 'lucide-react';
import { PortfolioItem, Lead } from '../../types';
import { BUSINESS_CATEGORIES } from '../../services/defaults';

interface PortfolioModalProps {
  isOpen: boolean;
  item?: PortfolioItem | null;
  leads: Lead[];
  onSave: (data: Partial<PortfolioItem> & { name: string; liveUrl: string }) => Promise<void>;
  onClose: () => void;
}

export const PortfolioModal: React.FC<PortfolioModalProps> = ({
  isOpen,
  item,
  leads,
  onSave,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState(BUSINESS_CATEGORIES[0]);
  const [liveUrl, setLiveUrl] = useState('');
  const [projectType, setProjectType] = useState('');
  const [status, setStatus] = useState<'Concept demo' | 'Client project' | 'Completed project'>('Concept demo');
  const [featuresDemonstrated, setFeaturesDemonstrated] = useState<string[]>([]);
  const [featuresTested, setFeaturesTested] = useState<string[]>([]);
  const [relatedLeadId, setRelatedLeadId] = useState('');
  const [notes, setNotes] = useState('');
  const [featureInput, setFeatureInput] = useState('');
  const [testInput, setTestInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (item) {
      setName(item.name);
      setCategory(item.category);
      setLiveUrl(item.liveUrl);
      setProjectType(item.projectType);
      setStatus(item.status);
      setFeaturesDemonstrated(item.featuresDemonstrated || []);
      setFeaturesTested(item.featuresTested || []);
      setRelatedLeadId(item.relatedLeadId || '');
      setNotes(item.notes || '');
    } else {
      setName('');
      setCategory(BUSINESS_CATEGORIES[0]);
      setLiveUrl('');
      setProjectType('Industry Concept Demo');
      setStatus('Concept demo');
      setFeaturesDemonstrated(['Mobile responsive design', 'WhatsApp quick booking', 'Google Maps embed']);
      setFeaturesTested(['Mobile viewport speed tested', 'WhatsApp deep linking']);
      setRelatedLeadId('');
      setNotes('');
    }
  }, [item, isOpen]);

  const addDemonstratedFeature = () => {
    if (!featureInput.trim()) return;
    setFeaturesDemonstrated([...featuresDemonstrated, featureInput.trim()]);
    setFeatureInput('');
  };

  const addTestedFeature = () => {
    if (!testInput.trim()) return;
    setFeaturesTested([...featuresTested, testInput.trim()]);
    setTestInput('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !liveUrl.trim()) {
      setError('Project name and live URL are required.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSave({
        id: item?.id,
        name: name.trim(),
        category,
        liveUrl: liveUrl.trim(),
        projectType: projectType.trim(),
        status,
        featuresDemonstrated,
        featuresTested,
        relatedLeadId,
        notes: notes.trim(),
      });
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to save portfolio showcase.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-xl shadow-2xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {item ? 'Edit Demo / Portfolio Item' : 'Add Website Demo or Showcase'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Curate live links used for outreach pitches to Kenyan prospects
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Name & Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Project / Demo Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Savannah Horizon Expeditions"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Target Business Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              >
                {BUSINESS_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Live URL & Project Type */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Live URL *
              </label>
              <input
                type="url"
                required
                value={liveUrl}
                onChange={(e) => setLiveUrl(e.target.value)}
                placeholder="https://demo.emgwebsolutions.co.ke"
                className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Project Type / Niche
              </label>
              <input
                type="text"
                value={projectType}
                onChange={(e) => setProjectType(e.target.value)}
                placeholder="e.g. Tour Operator Safari Portal"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* Status & Related Lead */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Status Classification *
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-medium"
              >
                <option value="Concept demo">Concept demo (Speculative showcase)</option>
                <option value="Client project">Client project (Active client)</option>
                <option value="Completed project">Completed project (Launched)</option>
              </select>
              <p className="text-[10px] text-slate-400 mt-1">
                Transparently labeled so concept demos are never represented as client work.
              </p>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Link to Prospect / Lead (Optional)
              </label>
              <select
                value={relatedLeadId}
                onChange={(e) => setRelatedLeadId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              >
                <option value="">-- None (General Demo) --</option>
                {leads.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.businessName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Features Demonstrated */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Features Demonstrated
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={featureInput}
                onChange={(e) => setFeatureInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addDemonstratedFeature();
                  }
                }}
                placeholder="Add feature (e.g. Instant WhatsApp inquiry with tour date)"
                className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
              />
              <button
                type="button"
                onClick={addDemonstratedFeature}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {featuresDemonstrated.map((f, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs bg-slate-100 text-slate-700 rounded-md"
                >
                  {f}
                  <button
                    type="button"
                    onClick={() => setFeaturesDemonstrated(featuresDemonstrated.filter((_, idx) => idx !== i))}
                    className="text-slate-400 hover:text-red-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Features Actually Tested */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Features Actually Tested (Truth in Engineering)
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTestedFeature();
                  }
                }}
                placeholder="Verified functionality (e.g. Safaricom 4G mobile load in 1.8s)"
                className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
              />
              <button
                type="button"
                onClick={addTestedFeature}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {featuresTested.map((t, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs bg-emerald-50 text-emerald-800 rounded-md border border-emerald-200"
                >
                  <Check className="w-3 h-3 text-emerald-600" />
                  {t}
                  <button
                    type="button"
                    onClick={() => setFeaturesTested(featuresTested.filter((_, idx) => idx !== i))}
                    className="text-emerald-400 hover:text-red-600 ml-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Pitch Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Outreach & Pitch Talking Points
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Why this demo resonates with target clients in this industry..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 text-xs text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Showcase Item'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
