import React from 'react';
import {
  Menu,
  Plus,
  LogIn,
  LogOut,
  Wallet,
} from 'lucide-react';
import { useAuth, OWNER_EMAIL } from '../../context/AuthContext';
import { NavTab } from './Sidebar';

interface HeaderProps {
  currentTab: NavTab;
  onOpenMobileSidebar: () => void;
  onOpenNewLeadModal: () => void;
  onOpenNewPaymentModal: () => void;
}

const TAB_TITLES: Record<NavTab, { title: string; subtitle: string }> = {
  dashboard: {
    title: 'Business Overview',
    subtitle: 'Revenue metrics, sales pipeline, and follow-up priorities',
  },
  leads: {
    title: 'Leads & Prospects Pipeline',
    subtitle: 'Track outreach, status stages, and qualification for Kenyan businesses',
  },
  followups: {
    title: 'Follow-Up Queue',
    subtitle: 'Due conversations, follow-up actions, and Kenya-tailored message templates',
  },
  quotations: {
    title: 'Quotations & Service Packages',
    subtitle: 'Generate formal proposals, scope breakdown, and track proposal status',
  },
  clients: {
    title: 'Active Clients & Project Delivery',
    subtitle: 'Manage client deliverables, milestone checklists, and domain hosting',
  },
  payments: {
    title: 'Cash Flow & Payment Ledger',
    subtitle: 'M-Pesa, bank transfers, deposits, and confirmed revenue tracking',
  },
  maintenance: {
    title: 'Recurring Maintenance Subscriptions',
    subtitle: 'Track monthly retainer plans, renewal dates, and projected MRR',
  },
  portfolio: {
    title: 'Portfolio & Concept Demos',
    subtitle: 'Industry-specific demo links to share with prospects during outreach',
  },
  reports: {
    title: 'Performance Reports & Analytics',
    subtitle: 'Conversion metrics, deal velocity, and lead channel performance',
  },
  settings: {
    title: 'System Settings & Backups',
    subtitle: 'Firebase connection, database export, and business configuration',
  },
};

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onOpenMobileSidebar,
  onOpenNewLeadModal,
  onOpenNewPaymentModal,
}) => {
  const { user, loginWithGoogle, logout } = useAuth();
  const info = TAB_TITLES[currentTab] || { title: 'Dashboard', subtitle: '' };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 md:px-6 py-3 no-print">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile hamburger + Breadcrumbs */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onOpenMobileSidebar}
            className="p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 md:hidden"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>EMG Web Solutions</span>
              <span>/</span>
              <span className="text-slate-600 font-medium capitalize truncate">
                {currentTab}
              </span>
            </div>
            <h2 className="text-base font-bold text-slate-900 truncate tracking-tight">
              {info.title}
            </h2>
          </div>
        </div>

        {/* Right: Quick actions + User Auth */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenNewPaymentModal}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap"
            title="Record M-Pesa or Bank payment"
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Record Payment</span>
          </button>

          <button
            onClick={onOpenNewLeadModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors shadow-xs whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Lead</span>
          </button>

          {/* User Auth control */}
          <div className="pl-2 border-l border-slate-200 flex items-center">
            {user ? (
              <div className="flex items-center gap-2">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-7 h-7 rounded-full border border-slate-200"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-xs font-bold">
                    {user.email?.charAt(0).toUpperCase()}
                  </div>
                )}
                <button
                  onClick={logout}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-100 transition-colors"
                  title="Sign out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={loginWithGoogle}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors"
                title={`Sign in with Google (${OWNER_EMAIL})`}
              >
                <LogIn className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden sm:inline">Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
