import React from 'react';
import {
  LayoutDashboard,
  Users,
  CalendarClock,
  FileText,
  Briefcase,
  Wallet,
  Repeat,
  Sparkles,
  BarChart3,
  Settings,
  ExternalLink,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export type NavTab =
  | 'dashboard'
  | 'leads'
  | 'followups'
  | 'quotations'
  | 'clients'
  | 'payments'
  | 'maintenance'
  | 'portfolio'
  | 'reports'
  | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  followUpsDueCount?: number;
  newLeadsCount?: number;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  followUpsDueCount = 0,
  newLeadsCount = 0,
  isOpenMobile = false,
  onCloseMobile,
}) => {
  const { user, isOwner, firestoreConnected } = useAuth();

  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: undefined,
    },
    {
      id: 'leads' as NavTab,
      label: 'Leads Pipeline',
      icon: Users,
      badge: newLeadsCount > 0 ? `${newLeadsCount} new` : undefined,
    },
    {
      id: 'followups' as NavTab,
      label: 'Follow-Ups',
      icon: CalendarClock,
      badge: followUpsDueCount > 0 ? `${followUpsDueCount} due` : undefined,
      badgeUrgent: followUpsDueCount > 0,
    },
    {
      id: 'quotations' as NavTab,
      label: 'Quotations & Packages',
      icon: FileText,
      badge: undefined,
    },
    {
      id: 'clients' as NavTab,
      label: 'Clients & Projects',
      icon: Briefcase,
      badge: undefined,
    },
    {
      id: 'payments' as NavTab,
      label: 'Cash Flow & Payments',
      icon: Wallet,
      badge: undefined,
    },
    {
      id: 'maintenance' as NavTab,
      label: 'Recurring Maintenance',
      icon: Repeat,
      badge: undefined,
    },
    {
      id: 'portfolio' as NavTab,
      label: 'Portfolio & Demos',
      icon: Sparkles,
      badge: undefined,
    },
    {
      id: 'reports' as NavTab,
      label: 'Reports & Insights',
      icon: BarChart3,
      badge: undefined,
    },
    {
      id: 'settings' as NavTab,
      label: 'Settings & Database',
      icon: Settings,
      badge: undefined,
    },
  ];

  const handleTabClick = (tab: NavTab) => {
    onSelectTab(tab);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs md:hidden"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        } no-print`}
      >
        {/* Brand Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm tracking-tight shadow-xs">
              EMG
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-900 tracking-tight leading-none">
                EMG Web Solutions
              </h1>
              <p className="text-[11px] text-slate-400 mt-1 font-mono">
                Growth & Operations
              </p>
            </div>
          </div>
        </div>


        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-slate-900 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-emerald-400' : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                      isActive
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : item.badgeUrgent
                        ? 'bg-amber-100 text-amber-800 font-medium'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer info & external link */}
        <div className="p-3 border-t border-slate-200 bg-slate-50/50 space-y-2">
          <a
            href="https://emgwebsolutions.vercel.app"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between px-3 py-1.5 text-[11px] text-slate-500 hover:text-slate-900 rounded-md hover:bg-slate-100 transition-colors"
          >
            <span className="flex items-center gap-1.5 truncate">
              <Building2 className="w-3.5 h-3.5 text-slate-400" />
              emgwebsolutions.vercel.app
            </span>
            <ExternalLink className="w-3 h-3 text-slate-400 shrink-0" />
          </a>

          {user && (
            <div className="px-3 py-1 text-[11px] text-slate-500 border-t border-slate-200/60 pt-2 flex items-center justify-between">
              <div className="truncate">
                <p className="truncate font-medium text-slate-700">{user.email}</p>
                <p className="text-[10px] text-slate-400 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  {isOwner ? 'System Owner' : 'Team Member'}
                </p>
              </div>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
