import React from 'react';
import {
  Users,
  Target,
  FileCheck,
  Trophy,
  DollarSign,
  TrendingUp,
  AlertCircle,
  Calendar,
  ArrowRight,
  Briefcase,
  Repeat,
  PhoneCall,
  MessageSquare,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import {
  Lead,
  Client,
  Project,
  Payment,
  Subscription,
  ContactLog,
  Quotation,
} from '../../types';
import { formatKenyanShillings } from '../../services/templates';
import { EmptyState } from '../common/EmptyState';
import { NavTab } from '../layout/Sidebar';

interface DashboardViewProps {
  leads: Lead[];
  clients: Client[];
  projects: Project[];
  payments: Payment[];
  subscriptions: Subscription[];
  contactLogs: ContactLog[];
  quotations: Quotation[];
  onNavigate: (tab: NavTab) => void;
  onOpenNewLead: () => void;
  onSelectLead?: (lead: Lead) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  leads,
  clients,
  projects,
  payments,
  subscriptions,
  contactLogs,
  quotations,
  onNavigate,
  onOpenNewLead,
  onSelectLead,
}) => {
  // Calculations strictly from saved records
  const totalLeads = leads.length;
  const newLeads = leads.filter((l) => l.status === 'New').length;
  const interestedProspects = leads.filter((l) =>
    ['Interested', 'Needs analysis', 'Negotiating'].includes(l.status)
  ).length;
  const proposalsSent = quotations.length || leads.filter((l) => l.status === 'Proposal sent').length;
  const dealsWon = leads.filter((l) => l.status === 'Won').length || clients.length;
  const dealsLost = leads.filter((l) => l.status === 'Lost').length;

  // Active opportunities: leads not yet won or lost
  const activeLeads = leads.filter((l) => !['Won', 'Lost'].includes(l.status));
  const totalActiveOpportunityValue = activeLeads.reduce(
    (sum, l) => sum + (Number(l.potentialValue) || Number(l.estimatedBudget) || 0),
    0
  );

  // Confirmed cash received
  const confirmedPayments = payments.filter((p) => p.paymentStatus === 'Confirmed');
  const totalRevenueReceived = confirmedPayments.reduce(
    (sum, p) => sum + (Number(p.amount) || 0),
    0
  );

  const depositsReceived = confirmedPayments
    .filter((p) => p.category === 'Deposit')
    .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

  // Outstanding client balances
  const outstandingBalances = clients.reduce(
    (sum, c) => sum + (Number(c.remainingBalance) || 0),
    0
  );

  // Monthly Recurring Revenue from active subscriptions
  const activeSubscriptions = subscriptions.filter((s) => s.status === 'Active');
  const monthlyRecurringRevenue = activeSubscriptions.reduce(
    (sum, s) => sum + (Number(s.monthlyFee) || 0),
    0
  );

  // Follow-ups due today or overdue
  const todayStr = new Date().toISOString().split('T')[0];
  const pendingFollowUps = leads
    .filter((l) => l.nextFollowUpDate && !['Won', 'Lost'].includes(l.status))
    .map((l) => {
      const isDueToday = l.nextFollowUpDate === todayStr;
      const isOverdue = (l.nextFollowUpDate || '') < todayStr;
      return { lead: l, isDueToday, isOverdue };
    })
    .filter((item) => item.isDueToday || item.isOverdue)
    .sort((a, b) => (a.lead.nextFollowUpDate || '').localeCompare(b.lead.nextFollowUpDate || ''));

  // Conversion Rate: won / (won + lost) if any closed, or won / totalLeads
  const closedCount = dealsWon + dealsLost;
  const conversionRate =
    closedCount > 0
      ? Math.round((dealsWon / closedCount) * 100)
      : totalLeads > 0
      ? Math.round((dealsWon / totalLeads) * 100)
      : 0;

  const hasAnyData =
    totalLeads > 0 ||
    clients.length > 0 ||
    payments.length > 0 ||
    subscriptions.length > 0;

  if (!hasAnyData) {
    return (
      <div className="space-y-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Welcome to EMG Web Solutions Growth System
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
            This internal system tracks your Kenyan web development business from initial outreach to
            cash collected in M-Pesa/Bank and recurring maintenance retainers. All numbers on this
            dashboard calculate dynamically from real records.
          </p>
        </div>

        <EmptyState
          icon={Users}
          title="No business records saved yet"
          description="Start building your sales pipeline by adding your first Kenyan prospect, importing contacts from CSV, or setting up your service packages."
          actionLabel="Add First Lead"
          onAction={onOpenNewLead}
          secondaryActionLabel="Explore Outreach Templates"
          onSecondaryAction={() => onNavigate('followups')}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Distinction Header: Projected Pipeline vs Actual Cash Received */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Actual Cash Collected */}
        <div className="bg-emerald-950 text-white border border-emerald-900 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-emerald-300 mb-2">
            <span className="font-semibold tracking-wide uppercase text-[11px]">
              Actual Cash Received (Confirmed)
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-900/60 text-emerald-200 text-[10px] font-mono">
              Bank & M-Pesa
            </span>
          </div>
          <div className="text-3xl font-bold font-mono tracking-tight text-white tabular-nums">
            {formatKenyanShillings(totalRevenueReceived)}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 text-xs border-t border-emerald-800/60 pt-3">
            <div>
              <span className="text-emerald-400 block text-[11px]">Project Deposits</span>
              <span className="font-semibold font-mono tabular-nums text-emerald-100">
                {formatKenyanShillings(depositsReceived)}
              </span>
            </div>
            <div>
              <span className="text-emerald-400 block text-[11px]">Monthly Retainers (MRR)</span>
              <span className="font-semibold font-mono tabular-nums text-emerald-100">
                {formatKenyanShillings(monthlyRecurringRevenue)}/mo
              </span>
            </div>
          </div>
        </div>

        {/* Projected Pipeline & Pending Receivables */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold tracking-wide uppercase text-[11px] text-slate-700">
              Active Pipeline & Receivables (Projected)
            </span>
            <span className="text-slate-400 text-[11px]">Uncollected</span>
          </div>
          <div className="text-3xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
            {formatKenyanShillings(totalActiveOpportunityValue)}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 text-xs border-t border-slate-100 pt-3">
            <div>
              <span className="text-slate-500 block text-[11px]">Outstanding Client Balances</span>
              <span className="font-semibold font-mono tabular-nums text-amber-700">
                {formatKenyanShillings(outstandingBalances)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Active Opportunities</span>
              <span className="font-semibold font-mono tabular-nums text-slate-900">
                {activeLeads.length} prospects
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Stat Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white border border-slate-200 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-slate-500 block truncate">Total Leads</span>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {totalLeads}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">In database</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-slate-500 block truncate">New Leads</span>
          <div className="text-2xl font-bold font-mono text-emerald-600 mt-1 tabular-nums">
            {newLeads}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Awaiting outreach</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-slate-500 block truncate">Interested</span>
          <div className="text-2xl font-bold font-mono text-blue-600 mt-1 tabular-nums">
            {interestedProspects}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">In conversation</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-slate-500 block truncate">Proposals Sent</span>
          <div className="text-2xl font-bold font-mono text-purple-600 mt-1 tabular-nums">
            {proposalsSent}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Formal quotes</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-slate-500 block truncate">Deals Won</span>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            {dealsWon}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {conversionRate}% conversion
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-3.5">
          <span className="text-[11px] font-medium text-slate-500 block truncate">Active Retainers</span>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {activeSubscriptions.length}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Maintenance clients</span>
        </div>
      </div>

      {/* Two Column Layout: Follow-Ups Due & Recent Business Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent Follow-Ups Due */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Follow-Ups Due Today & Overdue
                </h3>
              </div>
              <button
                onClick={() => onNavigate('followups')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
              >
                View all ({pendingFollowUps.length})
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {pendingFollowUps.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                <p className="font-semibold text-slate-800">You are all caught up!</p>
                <p className="text-slate-400 mt-0.5">
                  No outreach follow-ups are currently overdue.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                {pendingFollowUps.slice(0, 5).map(({ lead, isOverdue }) => (
                  <div
                    key={lead.id}
                    onClick={() => onSelectLead?.(lead)}
                    className="py-3 flex items-center justify-between hover:bg-slate-50/80 px-2 rounded-lg cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900 truncate">
                          {lead.businessName}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                            isOverdue
                              ? 'bg-red-50 text-red-700 font-semibold'
                              : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {isOverdue ? 'Overdue' : 'Due Today'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">
                        {lead.contactPerson} · {lead.phone} · {lead.location}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-[11px] font-mono font-medium text-slate-700 block">
                        {lead.potentialValue ? formatKenyanShillings(lead.potentialValue) : 'No quote'}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {lead.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Consistent follow-up doubles conversion for Kenyan SMBs</span>
            <button
              onClick={() => onNavigate('followups')}
              className="text-xs font-semibold text-slate-900 hover:underline"
            >
              Open Follow-Up Assistant
            </button>
          </div>
        </div>

        {/* Active Client Projects Status */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-slate-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  Active Client Projects ({projects.filter((p) => p.status !== 'Completed').length})
                </h3>
              </div>
              <button
                onClick={() => onNavigate('clients')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
              >
                Manage clients
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {projects.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">
                <Briefcase className="w-6 h-6 text-slate-300 mx-auto mb-2" />
                <p className="font-semibold text-slate-800">No active projects yet</p>
                <p className="text-slate-400 mt-0.5">
                  When a lead accepts your quotation, convert them to a client to track delivery.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                {projects.slice(0, 5).map((project) => {
                  const completedTasks = project.tasks.filter((t) => t.completed).length;
                  const totalTasks = project.tasks.length;
                  const percent = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

                  return (
                    <div key={project.id} className="py-3 px-2">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-900 truncate">
                          {project.title}
                        </span>
                        <span className="text-[11px] font-medium text-slate-600 font-mono">
                          {project.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                        <span>{project.clientBusinessName}</span>
                        <span>
                          {completedTasks}/{totalTasks} tasks ({percent}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-emerald-600 h-1.5 rounded-full transition-all duration-300"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Outstanding balance collection is tied to final review delivery</span>
            <button
              onClick={() => onNavigate('payments')}
              className="text-xs font-semibold text-slate-900 hover:underline"
            >
              Record Cash Inflow
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
