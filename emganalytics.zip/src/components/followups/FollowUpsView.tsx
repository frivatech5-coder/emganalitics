import React, { useState } from 'react';
import {
  CalendarClock,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Copy,
  Check,
  Send,
  MessageCircle,
  Phone,
  Calendar,
  Edit3,
  RefreshCw,
  Search,
  Building2,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { Lead, ContactLog, ContactChannel } from '../../types';
import {
  OUTREACH_TEMPLATES,
  MessageTemplate,
  populateTemplate,
  formatKenyanShillings,
} from '../../services/templates';
import { saveLead, addContactLog } from '../../services/db';

interface FollowUpsViewProps {
  leads: Lead[];
  onSelectLead: (lead: Lead) => void;
  onRefresh: () => void;
}

export const FollowUpsView: React.FC<FollowUpsViewProps> = ({
  leads,
  onSelectLead,
  onRefresh,
}) => {
  const [filterTab, setFilterTab] = useState<'today' | 'overdue' | 'upcoming' | 'waiting' | 'all'>('today');
  const [selectedLeadId, setSelectedLeadId] = useState<string>(leads[0]?.id || '');
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('first-contact');
  const [copied, setCopied] = useState(false);
  const [editableMessage, setEditableMessage] = useState<string>('');
  const [rescheduleDate, setRescheduleDate] = useState<string>('');
  const [outcomeNote, setOutcomeNote] = useState<string>('');
  const [markingComplete, setMarkingComplete] = useState<boolean>(false);

  const todayStr = new Date().toISOString().split('T')[0];

  // Group leads for tabs
  const dueTodayLeads = leads.filter(
    (l) => l.nextFollowUpDate === todayStr && !['Won', 'Lost'].includes(l.status)
  );
  const overdueLeads = leads.filter(
    (l) => Boolean(l.nextFollowUpDate && l.nextFollowUpDate < todayStr && !['Won', 'Lost'].includes(l.status))
  );
  const upcomingLeads = leads.filter(
    (l) => Boolean(l.nextFollowUpDate && l.nextFollowUpDate > todayStr && !['Won', 'Lost'].includes(l.status))
  );
  const waitingLeads = leads.filter(
    (l) => ['Contacted', 'Proposal sent'].includes(l.status) && !['Won', 'Lost'].includes(l.status)
  );

  const currentList =
    filterTab === 'today'
      ? dueTodayLeads
      : filterTab === 'overdue'
      ? overdueLeads
      : filterTab === 'upcoming'
      ? upcomingLeads
      : filterTab === 'waiting'
      ? waitingLeads
      : leads.filter((l) => !['Won', 'Lost'].includes(l.status));

  // Currently selected lead for message generation
  const activeLead = leads.find((l) => l.id === selectedLeadId) || currentList[0] || leads[0];
  const activeTemplate = OUTREACH_TEMPLATES.find((t) => t.id === selectedTemplateId) || OUTREACH_TEMPLATES[0];

  // Update editable message when activeLead or activeTemplate changes
  React.useEffect(() => {
    if (activeLead && activeTemplate) {
      const populated = populateTemplate(activeTemplate.content, {
        contactPerson: activeLead.contactPerson || 'Business Owner',
        businessName: activeLead.businessName || 'your business',
        location: activeLead.location || 'Nairobi',
        category: activeLead.category || 'business',
        demoUrl: 'https://emgwebsolutions.vercel.app',
        quoteNumber: `EMG-Q${new Date().getFullYear()}-01`,
        quoteTotal: formatKenyanShillings(activeLead.potentialValue || 35000),
        starterPrice: formatKenyanShillings(15000),
        paymentTerms: '50% initial deposit, 50% upon final launch review',
      });
      setEditableMessage(populated);
    }
  }, [activeLead?.id, activeTemplate?.id]);

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(editableMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Mark follow-up complete & optionally reschedule
  const handleCompleteFollowUp = async (newStatus?: string) => {
    if (!activeLead) return;
    setMarkingComplete(true);

    try {
      const today = new Date().toISOString().split('T')[0];
      // Log contact activity
      await addContactLog({
        leadId: activeLead.id,
        channel: 'WhatsApp',
        outcome: outcomeNote.trim() || 'Follow-up executed',
        notes: `Follow-up completed on ${today}. Notes: ${outcomeNote.trim() || 'None provided'}`,
        date: today,
      });

      // Update lead
      await saveLead({
        ...activeLead,
        lastContactDate: today,
        nextFollowUpDate: rescheduleDate || '',
        status: (newStatus as any) || (activeLead.status === 'New' ? 'Contacted' : activeLead.status),
      });

      setOutcomeNote('');
      setRescheduleDate('');
      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setMarkingComplete(false);
    }
  };

  // Mark as declined / lost
  const handleMarkDeclined = async () => {
    if (!activeLead) return;
    setMarkingComplete(true);
    try {
      await saveLead({
        ...activeLead,
        status: 'Lost',
        notes: `${activeLead.notes}\n[${todayStr}] Prospect politely declined further contact.`,
        nextFollowUpDate: '',
      });
      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setMarkingComplete(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Follow-up Queue Tabs */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setFilterTab('today')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              filterTab === 'today'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <span>Due Today</span>
            <span
              className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                filterTab === 'today'
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-slate-200 text-slate-700'
              }`}
            >
              {dueTodayLeads.length}
            </span>
          </button>

          <button
            onClick={() => setFilterTab('overdue')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              filterTab === 'overdue'
                ? 'bg-red-700 text-white shadow-xs'
                : 'text-red-700 hover:bg-red-50'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Overdue</span>
            <span
              className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                filterTab === 'overdue'
                  ? 'bg-white/20 text-white'
                  : 'bg-red-100 text-red-800'
              }`}
            >
              {overdueLeads.length}
            </span>
          </button>

          <button
            onClick={() => setFilterTab('upcoming')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              filterTab === 'upcoming'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <span>Upcoming Scheduled</span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-100 text-slate-700">
              {upcomingLeads.length}
            </span>
          </button>

          <button
            onClick={() => setFilterTab('waiting')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              filterTab === 'waiting'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <span>Awaiting Client Response</span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-100 text-slate-700">
              {waitingLeads.length}
            </span>
          </button>
        </div>
      </div>

      {/* Main Split: Left = List of Prospects, Right = Outreach Assistant & Action Box */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Follow-up list (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs flex flex-col h-[700px]">
          <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Priority Contacts ({currentList.length})
            </span>
            <span className="text-[11px] text-slate-400">Click to compose outreach</span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {currentList.length === 0 ? (
              <div className="py-12 px-6 text-center text-slate-400 text-xs">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="font-semibold text-slate-800">Queue is clear</p>
                <p className="mt-1">No leads match this follow-up filter right now.</p>
              </div>
            ) : (
              currentList.map((lead) => {
                const isSelected = lead.id === activeLead?.id;
                const isDueToday = lead.nextFollowUpDate === todayStr;
                const isOverdue = Boolean(lead.nextFollowUpDate && lead.nextFollowUpDate < todayStr);

                return (
                  <div
                    key={lead.id}
                    onClick={() => setSelectedLeadId(lead.id)}
                    className={`p-3.5 cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-slate-100/90 border-l-2 border-slate-900'
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-bold text-xs text-slate-900 truncate">
                            {lead.businessName}
                          </h4>
                          {isOverdue && (
                            <span className="text-[9px] px-1 py-0.2 bg-red-100 text-red-800 rounded font-semibold">
                              Overdue
                            </span>
                          )}
                          {isDueToday && (
                            <span className="text-[9px] px-1 py-0.2 bg-amber-100 text-amber-800 rounded font-semibold">
                              Today
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                          {lead.contactPerson} · {lead.phone}
                        </p>
                        <p className="text-[10px] text-slate-400 mt-0.5">
                          {lead.location} · {lead.category}
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-mono text-xs font-bold text-emerald-800 tabular-nums block">
                          {formatKenyanShillings(lead.potentialValue)}
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {lead.status}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Outreach Assistant & Action Box (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {activeLead ? (
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              {/* Active Lead Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                    Composing Message For
                  </span>
                  <h3 className="text-base font-bold text-slate-900">
                    {activeLead.businessName}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {activeLead.contactPerson} · {activeLead.phone} · {activeLead.location}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/${(activeLead.whatsapp || activeLead.phone || '').replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                      editableMessage
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Open in WhatsApp</span>
                  </a>
                </div>
              </div>

              {/* Template Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Select Kenya-Tailored Outreach Template:
                </label>
                <select
                  value={selectedTemplateId}
                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  {OUTREACH_TEMPLATES.map((tmpl) => (
                    <option key={tmpl.id} value={tmpl.id}>
                      {tmpl.name} ({tmpl.category})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-400 mt-1 italic">
                  {activeTemplate.description}
                </p>
              </div>

              {/* Editable Message Box */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-slate-700">
                    Message Preview (Personalized for {activeLead.contactPerson}):
                  </span>
                  <button
                    onClick={handleCopyMessage}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 hover:text-slate-900 px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 transition-colors"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span className="text-emerald-700">Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Message</span>
                      </>
                    )}
                  </button>
                </div>
                <textarea
                  rows={8}
                  value={editableMessage}
                  onChange={(e) => setEditableMessage(e.target.value)}
                  className="w-full p-3 text-xs font-sans leading-relaxed border border-slate-300 rounded-lg bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Follow-up Completion & Rescheduling Action Card */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Record Follow-Up Outcome & Reschedule
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Next Follow-Up Date (Reschedule)
                    </label>
                    <input
                      type="date"
                      value={rescheduleDate}
                      onChange={(e) => setRescheduleDate(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Outcome Note / Prospect Reaction
                    </label>
                    <input
                      type="text"
                      value={outcomeNote}
                      onChange={(e) => setOutcomeNote(e.target.value)}
                      placeholder="e.g. Sent WhatsApp, will check quotation tonight"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={handleMarkDeclined}
                    disabled={markingComplete}
                    className="px-3 py-1.5 text-xs text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-1"
                    title="Respect prospect decision and close file"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Prospect Declined</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleCompleteFollowUp('Contacted')}
                      disabled={markingComplete}
                      className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors shadow-xs"
                    >
                      Mark Contacted
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCompleteFollowUp('Interested')}
                      disabled={markingComplete}
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-700 rounded-lg hover:bg-emerald-800 transition-colors shadow-xs"
                    >
                      {markingComplete ? 'Saving...' : 'Mark Complete & Interested'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-slate-400">
              Select a prospect from the queue to start composing personalized outreach.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
