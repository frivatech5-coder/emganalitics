import React, { useState } from 'react';
import { X, Upload, Download, FileSpreadsheet, Check, AlertCircle } from 'lucide-react';
import { Lead } from '../../types';
import { saveLead } from '../../services/db';

interface LeadImportExportModalProps {
  isOpen: boolean;
  leads: Lead[];
  onClose: () => void;
  onRefresh: () => void;
}

export const LeadImportExportModal: React.FC<LeadImportExportModalProps> = ({
  isOpen,
  leads,
  onClose,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<'import' | 'export'>('import');
  const [csvContent, setCsvContent] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Export leads to CSV
  const handleExportCSV = () => {
    const headers = [
      'Business Name',
      'Contact Person',
      'Phone',
      'WhatsApp',
      'Email',
      'Location',
      'Category',
      'Status',
      'Estimated Budget (KSh)',
      'Potential Value (KSh)',
      'Source',
      'Website',
      'Next Follow-Up Date',
      'Notes',
    ];

    const rows = leads.map((l) => [
      `"${(l.businessName || '').replace(/"/g, '""')}"`,
      `"${(l.contactPerson || '').replace(/"/g, '""')}"`,
      `"${(l.phone || '').replace(/"/g, '""')}"`,
      `"${(l.whatsapp || '').replace(/"/g, '""')}"`,
      `"${(l.email || '').replace(/"/g, '""')}"`,
      `"${(l.location || '').replace(/"/g, '""')}"`,
      `"${(l.category || '').replace(/"/g, '""')}"`,
      `"${l.status}"`,
      l.estimatedBudget || 0,
      l.potentialValue || 0,
      `"${(l.source || '').replace(/"/g, '""')}"`,
      `"${(l.website || '').replace(/"/g, '""')}"`,
      `"${l.nextFollowUpDate || ''}"`,
      `"${(l.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvString = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `emg-leads-export-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Download Sample CSV template
  const handleDownloadSample = () => {
    const sampleHeaders = [
      'Business Name',
      'Contact Person',
      'Phone',
      'WhatsApp',
      'Email',
      'Location',
      'Category',
      'Estimated Budget',
      'Website',
      'Notes',
    ];

    const sampleRows = [
      [
        'Maasai Gate Safaris',
        'James Kariuki',
        '+254712345678',
        '+254712345678',
        'info@maasaigate.co.ke',
        'Nairobi — CBD & Industrial Area',
        'Safari, Travel & Tour Operations',
        '45000',
        'https://maasaigate.co.ke',
        'Looking for direct WhatsApp inquiry booking on mobile',
      ],
      [
        'Amani Medical Clinic',
        'Dr. Mercy Odhiambo',
        '+254722998877',
        '+254722998877',
        'contact@amaniclinic.ke',
        'Kisumu',
        'Clinics, Pharmacies & Healthcare',
        '35000',
        '',
        'Needs doctor appointment booking and pharmacy hours page',
      ],
    ];

    const csv = [sampleHeaders.join(','), ...sampleRows.map((r) => r.map((c) => `"${c}"`).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'emg-leads-sample-template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle CSV file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvContent(text);
    };
    reader.readAsText(file);
  };

  // Process CSV text and save to Firestore
  const handleProcessImport = async () => {
    if (!csvContent.trim()) {
      setError('Please paste CSV text or upload a CSV file.');
      return;
    }

    setImporting(true);
    setError(null);
    setImportStatus('Parsing CSV rows...');

    try {
      const lines = csvContent
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean);
      if (lines.length < 2) {
        throw new Error('CSV must contain a header row and at least one data row.');
      }

      // Simple CSV row parser handling quotes
      const parseCSVLine = (line: string): string[] => {
        const values: string[] = [];
        let current = '';
        let insideQuote = false;

        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"' && insideQuote && line[i + 1] === '"') {
            current += '"';
            i++;
          } else if (char === '"') {
            insideQuote = !insideQuote;
          } else if (char === ',' && !insideQuote) {
            values.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        values.push(current.trim());
        return values;
      };

      const headers = parseCSVLine(lines[0]).map((h) => h.toLowerCase());
      const findIndex = (keys: string[]) => headers.findIndex((h) => keys.some((k) => h.includes(k)));

      const nameIdx = findIndex(['business', 'name', 'company']);
      const contactIdx = findIndex(['contact', 'person']);
      const phoneIdx = findIndex(['phone', 'mobile', 'tel']);
      const waIdx = findIndex(['whatsapp', 'wa']);
      const emailIdx = findIndex(['email', 'mail']);
      const locIdx = findIndex(['location', 'city', 'town', 'area']);
      const catIdx = findIndex(['category', 'industry']);
      const budgetIdx = findIndex(['budget', 'price', 'value']);
      const webIdx = findIndex(['website', 'url']);
      const notesIdx = findIndex(['notes', 'details', 'comment']);

      let importedCount = 0;
      let skippedCount = 0;

      for (let i = 1; i < lines.length; i++) {
        const row = parseCSVLine(lines[i]);
        const businessName = nameIdx >= 0 ? row[nameIdx] : row[0];
        const phone = phoneIdx >= 0 ? row[phoneIdx] : row[2] || '';

        if (!businessName || !phone) {
          skippedCount++;
          continue;
        }

        const contactPerson = contactIdx >= 0 && row[contactIdx] ? row[contactIdx] : 'Business Owner';
        const whatsapp = waIdx >= 0 && row[waIdx] ? row[waIdx] : phone;
        const email = emailIdx >= 0 && row[emailIdx] ? row[emailIdx] : '';
        const location = locIdx >= 0 && row[locIdx] ? row[locIdx] : 'Nairobi';
        const category = catIdx >= 0 && row[catIdx] ? row[catIdx] : 'General Business';
        const budget = budgetIdx >= 0 ? Number(row[budgetIdx].replace(/[^0-9]/g, '')) || 35000 : 35000;
        const website = webIdx >= 0 && row[webIdx] ? row[webIdx] : '';
        const notes = notesIdx >= 0 && row[notesIdx] ? row[notesIdx] : 'Imported via CSV';

        await saveLead({
          businessName,
          contactPerson,
          phone,
          whatsapp,
          email,
          location,
          category,
          source: 'CSV Import',
          status: 'New',
          estimatedBudget: budget,
          potentialValue: budget,
          website,
          notes,
          nextFollowUpDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        });

        importedCount++;
      }

      setImportStatus(`Successfully imported ${importedCount} leads! (Skipped ${skippedCount} invalid rows)`);
      onRefresh();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to parse CSV. Please review the sample template.');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">
              CSV Import & Export Leads
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-200 px-6 pt-3">
          <button
            onClick={() => setActiveTab('import')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'import'
                ? 'border-emerald-600 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Import Leads from CSV
          </button>
          <button
            onClick={() => setActiveTab('export')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'export'
                ? 'border-emerald-600 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Export All Leads ({leads.length})
          </button>
        </div>

        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {importStatus && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{importStatus}</span>
            </div>
          )}

          {activeTab === 'import' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span>Upload a CSV spreadsheet or paste raw CSV text below:</span>
                <button
                  type="button"
                  onClick={handleDownloadSample}
                  className="font-semibold text-emerald-700 hover:underline flex items-center gap-1"
                >
                  <Download className="w-3 h-3" />
                  Download Sample CSV
                </button>
              </div>

              {/* File upload input */}
              <div className="border-2 border-dashed border-slate-300 rounded-xl p-5 text-center hover:border-slate-400 transition-colors">
                <Upload className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                <label className="text-xs font-semibold text-slate-700 cursor-pointer block">
                  <span>Choose CSV file to upload</span>
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                <p className="text-[11px] text-slate-400 mt-1">
                  Required columns: Business Name, Phone Number
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Or Paste CSV Text Directly:
                </label>
                <textarea
                  rows={4}
                  value={csvContent}
                  onChange={(e) => setCsvContent(e.target.value)}
                  placeholder={`"Business Name","Contact Person","Phone","Location","Budget"\n"Simba Hardware","John","+254712345678","Nairobi",35000`}
                  className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Close
                </button>
                <button
                  onClick={handleProcessImport}
                  disabled={importing || !csvContent}
                  className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50"
                >
                  {importing ? 'Importing...' : 'Start Import'}
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                Export all {leads.length} prospect records, phone numbers, WhatsApp contacts,
                potential values, and follow-up dates to a CSV file for offline backup or spreadsheet analysis.
              </p>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5 text-slate-700">
                <p className="font-semibold text-slate-900">Fields included in CSV:</p>
                <p className="text-slate-500">
                  Business Name, Contact Person, Phone, WhatsApp, Email, Location, Category, Pipeline Status,
                  Budget, Potential Value, Source, Website, Next Follow-Up, Notes.
                </p>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Close
                </button>
                <button
                  onClick={handleExportCSV}
                  className="px-5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg flex items-center gap-1.5 shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Leads CSV</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
