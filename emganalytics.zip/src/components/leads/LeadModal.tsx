import React, { useState, useEffect } from 'react';
import { X, AlertCircle, Sparkles, Building2, User, Phone, MapPin, Tag } from 'lucide-react';
import { Lead, LeadStatus, ServicePackage } from '../../types';
import { KENYAN_LOCATIONS, BUSINESS_CATEGORIES, LEAD_SOURCES } from '../../services/defaults';
import { checkDuplicateLead } from '../../services/db';

interface LeadModalProps {
  isOpen: boolean;
  lead?: Lead | null;
  existingLeads: Lead[];
  packages: ServicePackage[];
  onSave: (leadData: Partial<Lead> & { businessName: string; phone: string }) => Promise<void>;
  onClose: () => void;
}

export const LeadModal: React.FC<LeadModalProps> = ({
  isOpen,
  lead,
  existingLeads,
  packages,
  onSave,
  onClose,
}) => {
  const [businessName, setBusinessName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState(KENYAN_LOCATIONS[0]);
  const [category, setCategory] = useState(BUSINESS_CATEGORIES[0]);
  const [website, setWebsite] = useState('');
  const [socialMedia, setSocialMedia] = useState('');
  const [source, setSource] = useState(LEAD_SOURCES[0]);
  const [status, setStatus] = useState<LeadStatus>('New');
  const [estimatedBudget, setEstimatedBudget] = useState<number>(35000);
  const [potentialValue, setPotentialValue] = useState<number>(35000);
  const [assignedPackageId, setAssignedPackageId] = useState('');
  const [notes, setNotes] = useState('');
  const [nextFollowUpDate, setNextFollowUpDate] = useState('');
  const [lastContactDate, setLastContactDate] = useState('');
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (lead) {
      setBusinessName(lead.businessName || '');
      setContactPerson(lead.contactPerson || '');
      setPhone(lead.phone || '');
      setWhatsapp(lead.whatsapp || lead.phone || '');
      setEmail(lead.email || '');
      setLocation(lead.location || KENYAN_LOCATIONS[0]);
      setCategory(lead.category || BUSINESS_CATEGORIES[0]);
      setWebsite(lead.website || '');
      setSocialMedia(lead.socialMedia || '');
      setSource(lead.source || LEAD_SOURCES[0]);
      setStatus(lead.status || 'New');
      setEstimatedBudget(lead.estimatedBudget || 0);
      setPotentialValue(lead.potentialValue || 0);
      setAssignedPackageId(lead.assignedPackageId || '');
      setNotes(lead.notes || '');
      setNextFollowUpDate(lead.nextFollowUpDate || '');
      setLastContactDate(lead.lastContactDate || '');
    } else {
      // Defaults for new lead
      setBusinessName('');
      setContactPerson('');
      setPhone('');
      setWhatsapp('');
      setEmail('');
      setLocation(KENYAN_LOCATIONS[0]);
      setCategory(BUSINESS_CATEGORIES[0]);
      setWebsite('');
      setSocialMedia('');
      setSource(LEAD_SOURCES[0]);
      setStatus('New');
      setEstimatedBudget(35000);
      setPotentialValue(35000);
      setAssignedPackageId('pkg-business');
      setNotes('');
      // Default follow up in 2 days
      const inTwoDays = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      setNextFollowUpDate(inTwoDays);
      setLastContactDate(new Date().toISOString().split('T')[0]);
    }
    setDuplicateWarning(null);
    setError(null);
  }, [lead, isOpen]);

  // Handle assigned package price autofill
  const handlePackageChange = (pkgId: string) => {
    setAssignedPackageId(pkgId);
    const selected = packages.find((p) => p.id === pkgId);
    if (selected && (!potentialValue || potentialValue === 35000 || potentialValue === 15000)) {
      setPotentialValue(selected.price);
      setEstimatedBudget(selected.price);
    }
  };

  // Check duplicate when businessName or phone changes
  const handleCheckDuplicate = () => {
    if (!businessName && !phone) return;
    const dup = checkDuplicateLead(existingLeads, businessName, location, phone, lead?.id);
    if (dup.isDuplicate && dup.reason) {
      setDuplicateWarning(dup.reason);
    } else {
      setDuplicateWarning(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessName.trim()) {
      setError('Business name is required.');
      return;
    }
    if (!phone.trim()) {
      setError('Contact phone number is required.');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const selectedPkg = packages.find((p) => p.id === assignedPackageId);

      await onSave({
        id: lead?.id,
        businessName: businessName.trim(),
        contactPerson: contactPerson.trim() || 'Business Owner',
        phone: phone.trim(),
        whatsapp: whatsapp.trim() || phone.trim(),
        email: email.trim(),
        location,
        category,
        website: website.trim(),
        socialMedia: socialMedia.trim(),
        source,
        status,
        estimatedBudget: Number(estimatedBudget) || 0,
        potentialValue: Number(potentialValue) || Number(estimatedBudget) || 0,
        assignedPackageId,
        assignedPackageName: selectedPkg?.name || '',
        notes: notes.trim(),
        nextFollowUpDate,
        lastContactDate,
      });
      onClose();
    } catch (err: any) {
      console.error('Error saving lead:', err);
      setError(err?.message || 'Failed to save lead. Please check database permissions.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-xl shadow-2xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {lead ? 'Edit Lead Record' : 'Add New Prospect'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Enter verified contact information to track qualification and outreach
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {duplicateWarning && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
              <div>
                <p className="font-semibold">Potential Duplicate Lead Detected</p>
                <p className="mt-0.5">{duplicateWarning}</p>
              </div>
            </div>
          )}

          {/* Business & Contact Name */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Business Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                onBlur={handleCheckDuplicate}
                placeholder="e.g. Apex Dental Clinic"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Contact Person Name
              </label>
              <input
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="e.g. Dr. Jane Mwangi (Director)"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Phone & WhatsApp */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Phone Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value);
                  if (!whatsapp) setWhatsapp(e.target.value);
                }}
                onBlur={handleCheckDuplicate}
                placeholder="e.g. +254 712 345 678"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                WhatsApp Number
              </label>
              <input
                type="tel"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                placeholder="e.g. +254 712 345 678"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Email & Location */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="info@business.co.ke"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Location (Kenyan Region)
              </label>
              <select
                value={location}
                onChange={(e) => {
                  setLocation(e.target.value);
                  handleCheckDuplicate();
                }}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              >
                {KENYAN_LOCATIONS.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Category & Lead Source */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Business Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              >
                {BUSINESS_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Source of Lead
              </label>
              <select
                value={source}
                onChange={(e) => setSource(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              >
                {LEAD_SOURCES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Existing Website & Social Media */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Existing Website URL (if any)
              </label>
              <input
                type="url"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="https://example.co.ke"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Social Media Links
              </label>
              <input
                type="text"
                value={socialMedia}
                onChange={(e) => setSocialMedia(e.target.value)}
                placeholder="Instagram: @apex_dental, Facebook..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Status & Service Package */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Pipeline Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as LeadStatus)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 font-medium"
              >
                <option value="New">1. New (Fresh contact)</option>
                <option value="Contacted">2. Contacted</option>
                <option value="Responded">3. Responded</option>
                <option value="Interested">4. Interested</option>
                <option value="Needs analysis">5. Needs analysis</option>
                <option value="Proposal sent">6. Proposal sent</option>
                <option value="Negotiating">7. Negotiating</option>
                <option value="Won">8. Won (Client ready)</option>
                <option value="Lost">9. Lost</option>
                <option value="Follow up later">10. Follow up later</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Target Service Package
              </label>
              <select
                value={assignedPackageId}
                onChange={(e) => handlePackageChange(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              >
                <option value="">-- Custom Scope --</option>
                {packages.map((pkg) => (
                  <option key={pkg.id} value={pkg.id}>
                    {pkg.name} — KSh {pkg.price.toLocaleString('en-KE')}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Financial Value: Budget & Potential Value */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Estimated Budget (KSh)
              </label>
              <input
                type="number"
                min="0"
                step="500"
                value={estimatedBudget}
                onChange={(e) => setEstimatedBudget(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Potential Project Value (KSh)
              </label>
              <input
                type="number"
                min="0"
                step="500"
                value={potentialValue}
                onChange={(e) => setPotentialValue(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 font-semibold text-emerald-800"
              />
            </div>
          </div>

          {/* Follow-Up Dates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Next Follow-Up Date
              </label>
              <input
                type="date"
                value={nextFollowUpDate}
                onChange={(e) => setNextFollowUpDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Last Contact Date
              </label>
              <input
                type="date"
                value={lastContactDate}
                onChange={(e) => setLastContactDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Internal Discovery Notes
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Key business pain points, existing domain status, specific features requested, best time to call..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          {/* Footer Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50 shadow-xs"
            >
              {saving ? 'Saving...' : lead ? 'Save Changes' : 'Add Prospect'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
