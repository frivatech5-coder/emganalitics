import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Plus,
  ArrowUpDown,
  Download,
  Upload,
  Phone,
  MessageCircle,
  MapPin,
  Calendar,
  Building2,
  Table as TableIcon,
  Kanban,
  CheckCircle2,
  Clock,
  Eye,
  Trash2,
  Edit,
  DollarSign,
  Tag,
} from 'lucide-react';
import { Lead, LeadStatus, ServicePackage } from '../../types';
import { formatKenyanShillings } from '../../services/templates';
import { KENYAN_LOCATIONS, BUSINESS_CATEGORIES } from '../../services/defaults';
import { EmptyState } from '../common/EmptyState';

interface LeadsViewProps {
  leads: Lead[];
  packages: ServicePackage[];
  onOpenAddModal: () => void;
  onOpenImportExport: () => void;
  onSelectLead: (lead: Lead) => void;
  onEditLead: (lead: Lead) => void;
  onDeleteLead: (id: string) => void;
  onUpdateLeadStatus: (leadId: string, newStatus: LeadStatus) => void;
}

const ALL_STATUSES: LeadStatus[] = [
  'New',
  'Contacted',
  'Responded',
  'Interested',
  'Needs analysis',
  'Proposal sent',
  'Negotiating',
  'Won',
  'Lost',
  'Follow up later',
];

export const LeadsView: React.FC<LeadsViewProps> = ({
  leads,
  packages,
  onOpenAddModal,
  onOpenImportExport,
  onSelectLead,
  onEditLead,
  onDeleteLead,
  onUpdateLeadStatus,
}) => {
  const [viewMode, setViewMode] = useState<'table' | 'kanban'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [locationFilter, setLocationFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [followUpFilter, setFollowUpFilter] = useState<'all' | 'today' | 'overdue' | 'future'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'followup' | 'value'>('newest');

  const todayStr = new Date().toISOString().split('T')[0];

  // Filtered & sorted leads
  const filteredLeads = useMemo(() => {
    return leads
      .filter((lead) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = lead.businessName?.toLowerCase().includes(q);
          const matchContact = lead.contactPerson?.toLowerCase().includes(q);
          const matchPhone = lead.phone?.toLowerCase().includes(q);
          const matchNotes = lead.notes?.toLowerCase().includes(q);
          if (!matchName && !matchContact && !matchPhone && !matchNotes) return false;
        }

        // Status filter
        if (statusFilter !== 'all' && lead.status !== statusFilter) {
          return false;
        }

        // Location filter
        if (locationFilter !== 'all' && lead.location !== locationFilter) {
          return false;
        }

        // Category filter
        if (categoryFilter !== 'all' && lead.category !== categoryFilter) {
          return false;
        }

        // Follow-up date filter
        if (followUpFilter === 'today') {
          return lead.nextFollowUpDate === todayStr;
        }
        if (followUpFilter === 'overdue') {
          return Boolean(lead.nextFollowUpDate && lead.nextFollowUpDate < todayStr);
        }
        if (followUpFilter === 'future') {
          return Boolean(lead.nextFollowUpDate && lead.nextFollowUpDate > todayStr);
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return (b.createdAt || '').localeCompare(a.createdAt || '');
        }
        if (sortBy === 'followup') {
          if (!a.nextFollowUpDate) return 1;
          if (!b.nextFollowUpDate) return -1;
          return a.nextFollowUpDate.localeCompare(b.nextFollowUpDate);
        }
        if (sortBy === 'value') {
          const valA = Number(a.potentialValue) || Number(a.estimatedBudget) || 0;
          const valB = Number(b.potentialValue) || Number(b.estimatedBudget) || 0;
          return valB - valA;
        }
        return 0;
      });
  }, [leads, searchQuery, statusFilter, locationFilter, categoryFilter, followUpFilter, sortBy, todayStr]);

  const totalFilteredValue = filteredLeads.reduce(
    (sum, l) => sum + (Number(l.potentialValue) || Number(l.estimatedBudget) || 0),
    0
  );

  return (
    <div className="space-y-4">
      {/* Top Filter and Search Strip */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search box */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by business name, contact person, or phone..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          {/* Action buttons + View switcher */}
          <div className="flex items-center gap-2 flex-wrap justify-between md:justify-end">
            {/* View Mode Segmented Control */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1 ${
                  viewMode === 'table'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Table view"
              >
                <TableIcon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Table</span>
              </button>
              <button
                onClick={() => setViewMode('kanban')}
                className={`p-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1 ${
                  viewMode === 'kanban'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Pipeline stages view"
              >
                <Kanban className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Pipeline</span>
              </button>
            </div>

            <button
              onClick={onOpenImportExport}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Import / Export CSV</span>
            </button>

            <button
              onClick={onOpenAddModal}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Lead</span>
            </button>
          </div>
        </div>

        {/* Dropdown filters strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2 pt-2 border-t border-slate-100 text-xs">
          {/* Status filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Statuses ({leads.length})</option>
              {ALL_STATUSES.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Location filter */}
          <div>
            <select
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Kenyan Locations</option>
              {KENYAN_LOCATIONS.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          {/* Category filter */}
          <div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Industries</option>
              {BUSINESS_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Follow-up filter */}
          <div>
            <select
              value={followUpFilter}
              onChange={(e) => setFollowUpFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
            >
              <option value="all">All Follow-Up Dates</option>
              <option value="today">Due Today</option>
              <option value="overdue">Overdue</option>
              <option value="future">Upcoming</option>
            </select>
          </div>

          {/* Sort order */}
          <div className="col-span-2 sm:col-span-1">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
            >
              <option value="newest">Sort: Newest First</option>
              <option value="followup">Sort: Follow-Up Date</option>
              <option value="value">Sort: Potential Value (KSh)</option>
            </select>
          </div>
        </div>

        {/* Counter Summary */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
          <span>
            Showing <strong className="text-slate-800">{filteredLeads.length}</strong> of{' '}
            {leads.length} leads
          </span>
          <span className="font-mono tabular-nums text-slate-700 font-medium">
            Pipeline Value: <strong>{formatKenyanShillings(totalFilteredValue)}</strong>
          </span>
        </div>
      </div>

      {/* Main Content: Table or Kanban */}
      {filteredLeads.length === 0 ? (
        <EmptyState
          icon={Building2}
          title={searchQuery || statusFilter !== 'all' ? 'No matching leads found' : 'No prospects in pipeline'}
          description={
            searchQuery || statusFilter !== 'all'
              ? 'Try adjusting your search criteria or resetting the filters.'
              : 'Add your first Kenyan business prospect to start tracking outreach, proposals, and deal closing.'
          }
          actionLabel="Add Prospect"
          onAction={onOpenAddModal}
        />
      ) : viewMode === 'table' ? (
        /* TABLE VIEW */
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Business & Contact</th>
                  <th className="py-3 px-4">Location & Category</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Potential Value</th>
                  <th className="py-3 px-4">Next Follow-Up</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLeads.map((lead) => {
                  const isDueToday = lead.nextFollowUpDate === todayStr;
                  const isOverdue = Boolean(lead.nextFollowUpDate && lead.nextFollowUpDate < todayStr);

                  return (
                    <tr
                      key={lead.id}
                      className="hover:bg-slate-50/70 transition-colors group cursor-pointer"
                      onClick={() => onSelectLead(lead)}
                    >
                      {/* Business & Contact */}
                      <td className="py-3 px-4 min-w-[200px]">
                        <div className="font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                          {lead.businessName}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1.5">
                          <span>{lead.contactPerson}</span>
                          <span>·</span>
                          <span className="font-mono text-slate-600">{lead.phone}</span>
                        </div>
                      </td>

                      {/* Location & Category */}
                      <td className="py-3 px-4 min-w-[170px] text-slate-600">
                        <div className="truncate max-w-[180px]">{lead.location}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[180px]">
                          {lead.category}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 min-w-[130px]">
                        <span className="font-medium text-slate-800 block text-xs">
                          {lead.status}
                        </span>
                        <span className="text-[10px] text-slate-400 block">
                          {lead.source}
                        </span>
                      </td>

                      {/* Potential Value */}
                      <td className="py-3 px-4 text-right min-w-[120px]">
                        <span className="font-bold font-mono text-emerald-800 tabular-nums">
                          {formatKenyanShillings(lead.potentialValue || lead.estimatedBudget || 0)}
                        </span>
                        <span className="text-[10px] text-slate-400 block truncate">
                          {lead.assignedPackageName || 'Custom'}
                        </span>
                      </td>

                      {/* Next Follow-Up */}
                      <td className="py-3 px-4 min-w-[130px]">
                        {lead.nextFollowUpDate ? (
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`text-[11px] font-mono tabular-nums ${
                                isOverdue
                                  ? 'text-red-700 font-bold'
                                  : isDueToday
                                  ? 'text-amber-700 font-bold'
                                  : 'text-slate-700'
                              }`}
                            >
                              {lead.nextFollowUpDate}
                            </span>
                            {isOverdue && (
                              <span className="text-[10px] px-1 py-0.2 bg-red-50 text-red-700 rounded font-semibold">
                                Overdue
                              </span>
                            )}
                            {isDueToday && (
                              <span className="text-[10px] px-1 py-0.2 bg-amber-50 text-amber-800 rounded font-semibold">
                                Today
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px]">No date</span>
                        )}
                        <span className="text-[10px] text-slate-400 block">
                          Last: {lead.lastContactDate || 'Never'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td
                        className="py-3 px-4 text-right min-w-[110px]"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onSelectLead(lead)}
                            className="p-1.5 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-200/60"
                            title="View details & outreach"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onEditLead(lead)}
                            className="p-1.5 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-200/60"
                            title="Edit lead"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteLead(lead.id)}
                            className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                            title="Delete lead"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* KANBAN PIPELINE VIEW */
        <div className="overflow-x-auto pb-4">
          <div className="flex gap-4 min-w-[1200px]">
            {ALL_STATUSES.map((status) => {
              const columnLeads = filteredLeads.filter((l) => l.status === status);
              const columnValue = columnLeads.reduce(
                (sum, l) => sum + (Number(l.potentialValue) || Number(l.estimatedBudget) || 0),
                0
              );

              return (
                <div
                  key={status}
                  className="w-72 shrink-0 bg-slate-100/70 border border-slate-200 rounded-xl p-3 flex flex-col max-h-[75vh]"
                >
                  {/* Column Header */}
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200">
                    <div>
                      <h4 className="font-bold text-xs text-slate-900 tracking-tight">
                        {status}
                      </h4>
                      <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                        {columnLeads.length} leads · {formatKenyanShillings(columnValue)}
                      </span>
                    </div>
                  </div>

                  {/* Cards in column */}
                  <div className="space-y-2.5 overflow-y-auto flex-1 pr-1">
                    {columnLeads.length === 0 ? (
                      <div className="py-6 text-center text-slate-400 text-[11px] border border-dashed border-slate-200 rounded-lg">
                        Empty stage
                      </div>
                    ) : (
                      columnLeads.map((lead) => (
                        <div
                          key={lead.id}
                          onClick={() => onSelectLead(lead)}
                          className="bg-white border border-slate-200 rounded-lg p-3 shadow-xs hover:border-slate-300 transition-all cursor-pointer space-y-2"
                        >
                          <div className="flex items-start justify-between gap-1">
                            <h5 className="font-bold text-xs text-slate-900 leading-snug">
                              {lead.businessName}
                            </h5>
                            <span className="font-bold font-mono text-[11px] text-emerald-800 tabular-nums shrink-0">
                              {formatKenyanShillings(lead.potentialValue)}
                            </span>
                          </div>

                          <div className="text-[11px] text-slate-500">
                            <p className="truncate">{lead.contactPerson} · {lead.location}</p>
                            <p className="text-[10px] text-slate-400 truncate mt-0.5">
                              {lead.category}
                            </p>
                          </div>

                          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px]">
                            <span className="font-mono text-slate-500">
                              {lead.nextFollowUpDate ? `Due: ${lead.nextFollowUpDate}` : 'No follow-up'}
                            </span>
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="flex items-center gap-1"
                            >
                              <select
                                value={lead.status}
                                onChange={(e) =>
                                  onUpdateLeadStatus(lead.id, e.target.value as LeadStatus)
                                }
                                className="text-[10px] bg-slate-50 border border-slate-200 rounded px-1 py-0.5 font-medium text-slate-700"
                              >
                                {ALL_STATUSES.map((s) => (
                                  <option key={s} value={s}>
                                    Move to {s}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
