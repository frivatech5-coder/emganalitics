import React, { useState } from 'react';
import {
  X,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Calendar,
  Globe,
  Tag,
  DollarSign,
  Plus,
  Clock,
  Briefcase,
  FileText,
  Trash2,
  Edit,
  ExternalLink,
  CheckCircle,
} from 'lucide-react';
import { Lead, ContactLog, ContactChannel, ServicePackage } from '../../types';
import { formatKenyanShillings } from '../../services/templates';
import { ConfirmModal } from '../common/ConfirmModal';

interface LeadDetailsDrawerProps {
  lead: Lead | null;
  logs: ContactLog[];
  packages: ServicePackage[];
  onClose: () => void;
  onEdit: (lead: Lead) => void;
  onDelete: (id: string) => Promise<void>;
  onAddLog: (leadId: string, channel: ContactChannel, outcome: string, notes: string) => Promise<void>;
  onConvertToClient: (lead: Lead) => void;
  onCreateQuotation: (lead: Lead) => void;
}

export const LeadDetailsDrawer: React.FC<LeadDetailsDrawerProps> = ({
  lead,
  logs,
  packages,
  onClose,
  onEdit,
  onDelete,
  onAddLog,
  onConvertToClient,
  onCreateQuotation,
}) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showLogForm, setShowLogForm] = useState(false);
  const [channel, setChannel] = useState<ContactChannel>('WhatsApp');
  const [outcome, setOutcome] = useState('Prospect requested quotation');
  const [logNotes, setLogNotes] = useState('');
  const [savingLog, setSavingLog] = useState(false);

  if (!lead) return null;

  // Filter logs for this lead
  const leadLogs = logs
    .filter((l) => l.leadId === lead.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  // Clean Kenyan phone for WhatsApp wa.me link: 0712... -> 254712...
  const rawPhone = lead.whatsapp || lead.phone || '';
  const cleanPhone = rawPhone.replace(/[^0-9]/g, '');
  const waNumber = cleanPhone.startsWith('0')
    ? `254${cleanPhone.slice(1)}`
    : cleanPhone.startsWith('254')
    ? cleanPhone
    : `254${cleanPhone}`;

  const defaultWaText = encodeURIComponent(
    `Habari ${lead.contactPerson}, this is Kelvin from EMG Web Solutions following up on ${lead.businessName}'s website.`
  );
  const waUrl = `https://wa.me/${waNumber}?text=${defaultWaText}`;

  const handleSaveLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!logNotes.trim()) return;
    setSavingLog(true);
    try {
      await onAddLog(lead.id, channel, outcome, logNotes.trim());
      setLogNotes('');
      setShowLogForm(false);
    } catch (e) {
      console.error(e);
    } finally {
      setSavingLog(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs flex justify-end">
        <div className="w-full max-w-xl bg-white h-full shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-200">
          {/* Top Bar */}
          <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <div className="min-w-0 pr-3">
              <span className="text-[11px] font-mono text-slate-500 uppercase tracking-wider block">
                {lead.status}
              </span>
              <h2 className="text-base font-bold text-slate-900 truncate">
                {lead.businessName}
              </h2>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => onEdit(lead)}
                className="p-1.5 text-slate-600 hover:text-slate-900 rounded-md hover:bg-slate-200/60 transition-colors"
                title="Edit lead"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="p-1.5 text-red-600 hover:text-red-700 rounded-md hover:bg-red-50 transition-colors"
                title="Delete lead"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-200/60 transition-colors ml-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Outreach Action Bar */}
          <div className="px-5 py-3 bg-white border-b border-slate-100 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <a
                href={waUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                <span>WhatsApp Outreach</span>
              </a>

              <a
                href={`tel:${lead.phone}`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-slate-600" />
                <span>Call ({lead.phone})</span>
              </a>
            </div>

            <button
              onClick={() => onCreateQuotation(lead)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Quote</span>
            </button>
          </div>

          {/* Main Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6">
            {/* Convert to Client Banner if Won or Negotiating */}
            {lead.status === 'Won' && !lead.convertedToClientId && (
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-emerald-950">Deal Closed / Won!</p>
                  <p className="text-[11px] text-emerald-800">
                    Ready to convert this lead into an active Client & Project record.
                  </p>
                </div>
                <button
                  onClick={() => onConvertToClient(lead)}
                  className="px-3 py-1.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs whitespace-nowrap"
                >
                  Convert to Client
                </button>
              </div>
            )}

            {lead.convertedToClientId && (
              <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg text-xs text-slate-700 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Converted to Client Record #{lead.convertedToClientId}</span>
              </div>
            )}

            {/* Core Details Grid */}
            <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 space-y-3">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Prospect Profile
              </h3>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Contact Person</span>
                  <span className="font-semibold text-slate-800">{lead.contactPerson || 'Not provided'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Location</span>
                  <span className="font-semibold text-slate-800 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    {lead.location}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Business Category</span>
                  <span className="font-semibold text-slate-800">{lead.category}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Lead Source</span>
                  <span className="font-semibold text-slate-800">{lead.source}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Potential Project Value</span>
                  <span className="font-bold font-mono text-emerald-700 tabular-nums">
                    {formatKenyanShillings(lead.potentialValue)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Target Package</span>
                  <span className="font-semibold text-slate-800">
                    {lead.assignedPackageName || 'Custom Scope'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Next Follow-Up Date</span>
                  <span className="font-semibold font-mono text-slate-800">
                    {lead.nextFollowUpDate || 'None set'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Last Contact Date</span>
                  <span className="font-semibold font-mono text-slate-800">
                    {lead.lastContactDate || 'Never'}
                  </span>
                </div>
              </div>

              {lead.website && (
                <div className="pt-2 border-t border-slate-200/60 text-xs">
                  <span className="text-slate-400 block text-[11px]">Existing Website</span>
                  <a
                    href={lead.website.startsWith('http') ? lead.website : `https://${lead.website}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-700 hover:underline flex items-center gap-1 font-mono truncate"
                  >
                    <Globe className="w-3 h-3 shrink-0" />
                    {lead.website}
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>
              )}

              {lead.notes && (
                <div className="pt-2 border-t border-slate-200/60 text-xs">
                  <span className="text-slate-400 block text-[11px]">Discovery Notes</span>
                  <p className="text-slate-700 whitespace-pre-line mt-0.5 leading-relaxed bg-white p-2.5 rounded-lg border border-slate-200/60">
                    {lead.notes}
                  </p>
                </div>
              )}
            </div>

            {/* Interaction History Timeline */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-slate-600" />
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    Contact History & Outcomes ({leadLogs.length})
                  </h3>
                </div>
                <button
                  onClick={() => setShowLogForm(!showLogForm)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Activity</span>
                </button>
              </div>

              {/* Log Entry Form */}
              {showLogForm && (
                <form
                  onSubmit={handleSaveLog}
                  className="mb-4 p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3"
                >
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Channel
                      </label>
                      <select
                        value={channel}
                        onChange={(e) => setChannel(e.target.value as ContactChannel)}
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="WhatsApp">WhatsApp</option>
                        <option value="Phone Call">Phone Call</option>
                        <option value="Demo Presentation">Demo Presentation</option>
                        <option value="In-Person Meeting">In-Person Meeting</option>
                        <option value="Email">Email</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Outcome
                      </label>
                      <input
                        type="text"
                        value={outcome}
                        onChange={(e) => setOutcome(e.target.value)}
                        placeholder="e.g. Discussed starter package"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Conversation Notes
                    </label>
                    <textarea
                      required
                      rows={2}
                      value={logNotes}
                      onChange={(e) => setLogNotes(e.target.value)}
                      placeholder="What was discussed, client objections, agreement on next steps..."
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowLogForm(false)}
                      className="px-3 py-1 text-xs text-slate-600 hover:bg-slate-200/60 rounded"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={savingLog}
                      className="px-3 py-1 text-xs font-semibold text-white bg-slate-900 rounded hover:bg-slate-800 disabled:opacity-50"
                    >
                      {savingLog ? 'Saving...' : 'Save Log'}
                    </button>
                  </div>
                </form>
              )}

              {/* Log Timeline List */}
              {leadLogs.length === 0 ? (
                <div className="py-6 text-center text-slate-400 text-xs border border-dashed border-slate-200 rounded-lg">
                  No contact logged yet. Click "Log Activity" after reaching out to this prospect.
                </div>
              ) : (
                <div className="space-y-3">
                  {leadLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3 bg-white border border-slate-200 rounded-lg text-xs"
                    >
                      <div className="flex items-center justify-between text-slate-500 mb-1">
                        <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                          <Tag className="w-3 h-3 text-emerald-600" />
                          {log.channel} — {log.outcome}
                        </span>
                        <span className="font-mono text-[10px]">
                          {new Date(log.createdAt).toLocaleDateString('en-KE')}
                        </span>
                      </div>
                      <p className="text-slate-600 leading-relaxed mt-1">
                        {log.notes}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={showDeleteConfirm}
        title="Delete Lead Record"
        message={`Are you sure you want to permanently delete "${lead.businessName}"? This action cannot be undone.`}
        confirmLabel="Delete Lead"
        onConfirm={() => {
          onDelete(lead.id);
          onClose();
        }}
        onClose={() => setShowDeleteConfirm(false)}
      />
    </>
  );
};
