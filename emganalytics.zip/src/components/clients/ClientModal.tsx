import React, { useState, useEffect } from 'react';
import { X, Building2, User, Phone, MapPin, DollarSign, Globe, Server, AlertCircle } from 'lucide-react';
import { Client } from '../../types';
import { KENYAN_LOCATIONS } from '../../services/defaults';

interface ClientModalProps {
  isOpen: boolean;
  client?: Client | null;
  onSave: (clientData: Partial<Client> & { businessName: string; phone: string }) => Promise<void>;
  onClose: () => void;
}

export const ClientModal: React.FC<ClientModalProps> = ({
  isOpen,
  client,
  onSave,
  onClose,
}) => {
  const [businessName, setBusinessName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState(KENYAN_LOCATIONS[0]);
  const [agreedProjectPrice, setAgreedProjectPrice] = useState<number>(35000);
  const [totalDepositPaid, setTotalDepositPaid] = useState<number>(17500);
  const [domainName, setDomainName] = useState('');
  const [domainRegistrar, setDomainRegistrar] = useState('Kenya Web Experts / EACodes');
  const [domainRenewalDate, setDomainRenewalDate] = useState('');
  const [hostingProvider, setHostingProvider] = useState('EMG Managed Vercel / Cloud');
  const [hostingRenewalDate, setHostingRenewalDate] = useState('');
  const [supportExpiryDate, setSupportExpiryDate] = useState('');
  const [maintenanceStatus, setMaintenanceStatus] = useState<'None' | 'Active' | 'Paused' | 'Overdue'>('None');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (client) {
      setBusinessName(client.businessName);
      setContactPerson(client.contactPerson);
      setPhone(client.phone);
      setWhatsapp(client.whatsapp || client.phone);
      setEmail(client.email || '');
      setLocation(client.location || KENYAN_LOCATIONS[0]);
      setAgreedProjectPrice(client.agreedProjectPrice || 0);
      setTotalDepositPaid(client.totalDepositPaid || 0);
      setDomainName(client.domainInfo?.domainName || '');
      setDomainRegistrar(client.domainInfo?.registrar || 'Kenya Web Experts');
      setDomainRenewalDate(client.domainInfo?.renewalDate || '');
      setHostingProvider(client.hostingInfo?.provider || 'EMG Managed Cloud');
      setHostingRenewalDate(client.hostingInfo?.renewalDate || '');
      setSupportExpiryDate(client.supportExpiryDate || '');
      setMaintenanceStatus(client.maintenanceStatus || 'None');
      setNotes(client.notes || '');
    } else {
      setBusinessName('');
      setContactPerson('');
      setPhone('');
      setWhatsapp('');
      setEmail('');
      setLocation(KENYAN_LOCATIONS[0]);
      setAgreedProjectPrice(35000);
      setTotalDepositPaid(17500);
      setDomainName('');
      setDomainRegistrar('Kenya Web Experts / HostPinnacle');
      setDomainRenewalDate('');
      setHostingProvider('EMG Managed Vercel');
      setHostingRenewalDate('');
      setSupportExpiryDate('');
      setMaintenanceStatus('None');
      setNotes('');
    }
  }, [client, isOpen]);

  const remainingBalance = Math.max(0, agreedProjectPrice - totalDepositPaid);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessName.trim() || !phone.trim()) {
      setError('Business name and contact phone are required.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSave({
        id: client?.id,
        businessName: businessName.trim(),
        contactPerson: contactPerson.trim() || 'Client',
        phone: phone.trim(),
        whatsapp: whatsapp.trim() || phone.trim(),
        email: email.trim(),
        location,
        agreedProjectPrice: Number(agreedProjectPrice) || 0,
        totalDepositPaid: Number(totalDepositPaid) || 0,
        remainingBalance,
        domainInfo: {
          domainName: domainName.trim(),
          registrar: domainRegistrar.trim(),
          renewalDate: domainRenewalDate,
        },
        hostingInfo: {
          provider: hostingProvider.trim(),
          renewalDate: hostingRenewalDate,
          plan: 'Standard',
        },
        supportExpiryDate,
        maintenanceStatus,
        notes: notes.trim(),
      });
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to save client details.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-xl shadow-2xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {client ? `Edit Client: ${client.businessName}` : 'Add New Paying Client'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Client profile, contract value, balance calculation, and hosting records
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Business & Contact Name */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Business Name *
              </label>
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g. Simba Builders Hardware"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Contact Person Name
              </label>
              <input
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="e.g. John Kamau"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* Phone & WhatsApp */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Phone Number *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+254 7..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                WhatsApp Number
              </label>
              <input
                type="tel"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                placeholder="+254 7..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* Email & Location */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="contact@client.co.ke"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Location
              </label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
              >
                {KENYAN_LOCATIONS.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Agreed Price, Deposit Paid & Remaining Balance */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wide block">
              Financial Contract & Cash Inflow
            </span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Agreed Project Price (KSh)
                </label>
                <input
                  type="number"
                  step="500"
                  value={agreedProjectPrice}
                  onChange={(e) => setAgreedProjectPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Deposit Confirmed (KSh)
                </label>
                <input
                  type="number"
                  step="500"
                  value={totalDepositPaid}
                  onChange={(e) => setTotalDepositPaid(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono font-bold text-emerald-800 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Remaining Balance (KSh)
                </label>
                <div className="px-3 py-2 text-xs font-mono font-bold text-amber-800 bg-white border border-slate-200 rounded-lg tabular-nums">
                  KSh {remainingBalance.toLocaleString('en-KE')}
                </div>
              </div>
            </div>
          </div>

          {/* Domain & Hosting Information (Encrypted / Clean, NO plain passwords) */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wide block">
              Domain & Hosting Records (Security Compliant)
            </span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Domain Name
                </label>
                <input
                  type="text"
                  value={domainName}
                  onChange={(e) => setDomainName(e.target.value)}
                  placeholder="e.g. simbabuilders.co.ke"
                  className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Registrar / Provider
                </label>
                <input
                  type="text"
                  value={domainRegistrar}
                  onChange={(e) => setDomainRegistrar(e.target.value)}
                  placeholder="e.g. Kenya Web Experts"
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Domain Expiry Date
                </label>
                <input
                  type="date"
                  value={domainRenewalDate}
                  onChange={(e) => setDomainRenewalDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-200">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Hosting Provider
                </label>
                <input
                  type="text"
                  value={hostingProvider}
                  onChange={(e) => setHostingProvider(e.target.value)}
                  placeholder="e.g. EMG Managed Vercel"
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Support Expiry Date (Post-Launch)
                </label>
                <input
                  type="date"
                  value={supportExpiryDate}
                  onChange={(e) => setSupportExpiryDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Internal Client Notes & Scope Summary
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Design preferences, agreed deliverables, launch conditions..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 text-xs text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Saving...' : client ? 'Save Changes' : 'Save Client'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
