import React, { useState } from 'react';
import {
  Briefcase,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  Calendar,
  Globe,
  Server,
  DollarSign,
  Wallet,
  Repeat,
  CheckSquare,
  Square,
  Search,
  ExternalLink,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Client, Project, ProjectStatus, ProjectTask } from '../../types';
import { formatKenyanShillings } from '../../services/templates';
import { EmptyState } from '../common/EmptyState';
import { ConfirmModal } from '../common/ConfirmModal';
import { saveProject } from '../../services/db';

interface ClientsViewProps {
  clients: Client[];
  projects: Project[];
  onOpenNewClient: () => void;
  onEditClient: (client: Client) => void;
  onDeleteClient: (id: string) => void;
  onRecordPaymentForClient: (client: Client) => void;
  onCreateSubscriptionForClient: (client: Client) => void;
  onRefresh: () => void;
}

export const ClientsView: React.FC<ClientsViewProps> = ({
  clients,
  projects,
  onOpenNewClient,
  onEditClient,
  onDeleteClient,
  onRecordPaymentForClient,
  onCreateSubscriptionForClient,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedClientId, setExpandedClientId] = useState<string | null>(clients[0]?.id || null);
  const [deleteClientId, setDeleteClientId] = useState<string | null>(null);
  const [newTaskTitle, setNewTaskTitle] = useState('');

  const filteredClients = clients.filter((c) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchBiz = c.businessName?.toLowerCase().includes(q);
      const matchContact = c.contactPerson?.toLowerCase().includes(q);
      const matchPhone = c.phone?.toLowerCase().includes(q);
      if (!matchBiz && !matchContact && !matchPhone) return false;
    }
    return true;
  });

  const totalContractValue = clients.reduce((sum, c) => sum + (c.agreedProjectPrice || 0), 0);
  const totalDeposits = clients.reduce((sum, c) => sum + (c.totalDepositPaid || 0), 0);
  const totalReceivables = clients.reduce((sum, c) => sum + (c.remainingBalance || 0), 0);

  // Toggle task completion in a project
  const handleToggleTask = async (project: Project, taskId: string) => {
    const updatedTasks = project.tasks.map((t) =>
      t.id === taskId ? { ...t, completed: !t.completed } : t
    );
    await saveProject({
      ...project,
      tasks: updatedTasks,
    });
    onRefresh();
  };

  // Add new task to project
  const handleAddTask = async (project: Project) => {
    if (!newTaskTitle.trim()) return;
    const newTask: ProjectTask = {
      id: `task-${Date.now()}`,
      title: newTaskTitle.trim(),
      completed: false,
    };
    await saveProject({
      ...project,
      tasks: [...project.tasks, newTask],
    });
    setNewTaskTitle('');
    onRefresh();
  };

  // Update project status
  const handleUpdateProjectStatus = async (project: Project, status: ProjectStatus) => {
    await saveProject({
      ...project,
      status,
    });
    onRefresh();
  };

  return (
    <div className="space-y-4">
      {/* Top Strip */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search clients by business name or contact person..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenNewClient}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Client Record</span>
            </button>
          </div>
        </div>

        {/* Financial KPI Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100 text-xs">
          <div className="p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg">
            <span className="text-[11px] text-slate-500 block">Total Agreed Contracts</span>
            <span className="text-sm font-bold font-mono text-slate-900 tabular-nums">
              {formatKenyanShillings(totalContractValue)}
            </span>
          </div>

          <div className="p-2.5 bg-emerald-50/70 border border-emerald-200/60 rounded-lg">
            <span className="text-[11px] text-emerald-800 block">Deposits Collected</span>
            <span className="text-sm font-bold font-mono text-emerald-900 tabular-nums">
              {formatKenyanShillings(totalDeposits)}
            </span>
          </div>

          <div className="p-2.5 bg-amber-50/70 border border-amber-200/60 rounded-lg">
            <span className="text-[11px] text-amber-800 block">Outstanding Client Receivables</span>
            <span className="text-sm font-bold font-mono text-amber-900 tabular-nums">
              {formatKenyanShillings(totalReceivables)}
            </span>
          </div>
        </div>
      </div>

      {/* Clients & Projects View */}
      {filteredClients.length === 0 ? (
        <EmptyState
          icon={Briefcase}
          title="No client records yet"
          description="When a lead agrees to work with EMG Web Solutions or accepts a quotation, convert them into an active client project."
          actionLabel="Add First Client"
          onAction={onOpenNewClient}
        />
      ) : (
        <div className="space-y-4">
          {filteredClients.map((client) => {
            const isExpanded = expandedClientId === client.id;
            const clientProject = projects.find((p) => p.clientId === client.id);
            const tasks = clientProject?.tasks || [];
            const completedTasks = tasks.filter((t) => t.completed).length;
            const taskPercent = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

            return (
              <div
                key={client.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs hover:border-slate-300 transition-colors"
              >
                {/* Client Banner / Summary Bar */}
                <div
                  onClick={() => setExpandedClientId(isExpanded ? null : client.id)}
                  className="p-4 bg-slate-50/70 flex flex-col md:flex-row md:items-center justify-between gap-3 cursor-pointer hover:bg-slate-100/60 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      {client.businessName.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-slate-900">
                          {client.businessName}
                        </h3>
                        {client.maintenanceStatus === 'Active' && (
                          <span className="text-[10px] px-1.5 py-0.2 bg-emerald-100 text-emerald-800 font-semibold rounded">
                            Retainer Active
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">
                        {client.contactPerson} · {client.phone} · {client.location}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs">
                    <div className="text-right">
                      <span className="text-[11px] text-slate-400 block">Agreed Price</span>
                      <span className="font-bold font-mono text-slate-900 tabular-nums">
                        {formatKenyanShillings(client.agreedProjectPrice)}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[11px] text-slate-400 block">Balance Due</span>
                      <span
                        className={`font-bold font-mono tabular-nums ${
                          client.remainingBalance > 0 ? 'text-amber-800' : 'text-emerald-700'
                        }`}
                      >
                        {formatKenyanShillings(client.remainingBalance)}
                      </span>
                    </div>

                    <div className="pl-2 border-l border-slate-200 text-slate-400">
                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5" />
                      ) : (
                        <ChevronDown className="w-5 h-5" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded Details & Delivery Tracker */}
                {isExpanded && (
                  <div className="p-5 border-t border-slate-200 space-y-5 animate-in fade-in duration-150">
                    {/* Quick Client Action Strip */}
                    <div className="flex items-center justify-between gap-2 flex-wrap pb-3 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onRecordPaymentForClient(client)}
                          className="px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 flex items-center gap-1.5"
                        >
                          <Wallet className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Record Payment (M-Pesa / Bank)</span>
                        </button>

                        <button
                          onClick={() => onCreateSubscriptionForClient(client)}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 flex items-center gap-1.5"
                        >
                          <Repeat className="w-3.5 h-3.5 text-slate-600" />
                          <span>Set Up Maintenance Retainer</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onEditClient(client)}
                          className="p-1.5 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-100"
                          title="Edit client record"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeleteClientId(client.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                          title="Delete client record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Delivery & Project Milestone Checklist */}
                    {clientProject ? (
                      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider">
                              Project Delivery Plan
                            </span>
                            <h4 className="text-sm font-bold text-slate-900">
                              {clientProject.title}
                            </h4>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-xs text-slate-500">Status:</span>
                            <select
                              value={clientProject.status}
                              onChange={(e) =>
                                handleUpdateProjectStatus(clientProject, e.target.value as ProjectStatus)
                              }
                              className="text-xs font-semibold bg-white border border-slate-300 rounded px-2.5 py-1 focus:outline-none"
                            >
                              <option value="Awaiting deposit">Awaiting deposit</option>
                              <option value="Ready to start">Ready to start</option>
                              <option value="In progress">In progress</option>
                              <option value="Awaiting client feedback">Awaiting client feedback</option>
                              <option value="Testing">Testing</option>
                              <option value="Completed">Completed</option>
                              <option value="On hold">On hold</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div>
                          <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
                            <span>Checklist Progress</span>
                            <span className="font-mono tabular-nums font-bold">
                              {completedTasks}/{tasks.length} tasks completed ({taskPercent}%)
                            </span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                            <div
                              className="bg-emerald-600 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${taskPercent}%` }}
                            />
                          </div>
                        </div>

                        {/* Tasks list */}
                        <div className="space-y-1.5 pt-2">
                          {tasks.map((task) => (
                            <div
                              key={task.id}
                              onClick={() => handleToggleTask(clientProject, task.id)}
                              className="flex items-center gap-2.5 p-2 bg-white border border-slate-200 rounded-lg text-xs cursor-pointer hover:bg-slate-50 transition-colors"
                            >
                              {task.completed ? (
                                <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                              ) : (
                                <Square className="w-4 h-4 text-slate-400 shrink-0" />
                              )}
                              <span
                                className={`flex-1 ${
                                  task.completed ? 'line-through text-slate-400' : 'text-slate-800'
                                }`}
                              >
                                {task.title}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Add Task Input */}
                        <div className="flex gap-2 pt-1">
                          <input
                            type="text"
                            value={newTaskTitle}
                            onChange={(e) => setNewTaskTitle(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleAddTask(clientProject);
                              }
                            }}
                            placeholder="Add deliverable or checklist task (e.g. Test M-Pesa STK push)..."
                            className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={() => handleAddTask(clientProject)}
                            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                          >
                            Add Task
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-500">
                        No active project checklist initialized for this client.
                      </div>
                    )}

                    {/* Domain, Hosting & Support Expiry Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <div>
                        <span className="text-[11px] text-slate-400 block mb-0.5">
                          Domain Registration
                        </span>
                        <p className="font-semibold font-mono text-slate-800">
                          {client.domainInfo?.domainName || 'Not configured'}
                        </p>
                        <p className="text-[10px] text-slate-500">
                          {client.domainInfo?.registrar || 'Registrar N/A'} · Expiry:{' '}
                          {client.domainInfo?.renewalDate || 'None'}
                        </p>
                      </div>

                      <div>
                        <span className="text-[11px] text-slate-400 block mb-0.5">
                          Hosting Environment
                        </span>
                        <p className="font-semibold text-slate-800">
                          {client.hostingInfo?.provider || 'EMG Cloud'}
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Renewal: {client.hostingInfo?.renewalDate || 'Ongoing'}
                        </p>
                      </div>

                      <div>
                        <span className="text-[11px] text-slate-400 block mb-0.5">
                          Post-Launch Support
                        </span>
                        <p className="font-semibold text-slate-800">
                          {client.supportExpiryDate
                            ? `Valid until ${client.supportExpiryDate}`
                            : 'Standard 30 days'}
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Maintenance: {client.maintenanceStatus}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Client Confirm */}
      <ConfirmModal
        isOpen={Boolean(deleteClientId)}
        title="Delete Client Record"
        message="Are you sure you want to delete this client record? This will also remove associated delivery projects."
        confirmLabel="Delete Client"
        onConfirm={() => {
          if (deleteClientId) onDeleteClient(deleteClientId);
          setDeleteClientId(null);
        }}
        onClose={() => setDeleteClientId(null)}
      />
    </div>
  );
};
