import React, { useState } from 'react';
import {
  Wallet,
  Plus,
  ArrowDownLeft,
  DollarSign,
  Calendar,
  CheckCircle2,
  Clock,
  Trash2,
  Edit,
  Search,
  Filter,
  BarChart2,
  PieChart,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import { Payment, Client, PaymentMethod, PaymentCategory } from '../../types';
import { formatKenyanShillings } from '../../services/templates';
import { EmptyState } from '../common/EmptyState';
import { ConfirmModal } from '../common/ConfirmModal';

interface PaymentsViewProps {
  payments: Payment[];
  clients: Client[];
  onOpenNewPayment: () => void;
  onEditPayment: (payment: Payment) => void;
  onDeletePayment: (id: string) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  payments,
  clients,
  onOpenNewPayment,
  onEditPayment,
  onDeletePayment,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Confirmed payments only for real revenue
  const confirmedPayments = payments.filter((p) => p.paymentStatus === 'Confirmed');
  const totalRevenue = confirmedPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const pendingPayments = payments.filter((p) => p.paymentStatus === 'Pending');
  const totalPending = pendingPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

  // Total outstanding client debt
  const totalOutstanding = clients.reduce((sum, c) => sum + (c.remainingBalance || 0), 0);

  // Filtered transactions
  const filteredPayments = payments.filter((p) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchClient = p.clientBusinessName?.toLowerCase().includes(q);
      const matchRef = p.transactionReference?.toLowerCase().includes(q);
      const matchNotes = p.notes?.toLowerCase().includes(q);
      if (!matchClient && !matchRef && !matchNotes) return false;
    }
    if (methodFilter !== 'all' && p.paymentMethod !== methodFilter) return false;
    if (categoryFilter !== 'all' && p.category !== categoryFilter) return false;
    return true;
  });

  // Revenue by Month (Confirmed only)
  const revenueByMonth = confirmedPayments.reduce((acc, p) => {
    const monthKey = (p.paymentDate || '').substring(0, 7) || 'Unspecified'; // YYYY-MM
    acc[monthKey] = (acc[monthKey] || 0) + Number(p.amount);
    return acc;
  }, {} as Record<string, number>);

  // Revenue by Payment Method
  const revenueByMethod = confirmedPayments.reduce((acc, p) => {
    acc[p.paymentMethod] = (acc[p.paymentMethod] || 0) + Number(p.amount);
    return acc;
  }, {} as Record<string, number>);

  // Revenue by Client
  const revenueByClient = confirmedPayments.reduce((acc, p) => {
    const name = p.clientBusinessName || 'Direct Payment';
    acc[name] = (acc[name] || 0) + Number(p.amount);
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      {/* Financial Health Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Actual Confirmed Money Received */}
        <div className="bg-emerald-950 text-white border border-emerald-900 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-emerald-300 mb-1">
            <span className="font-semibold uppercase tracking-wider text-[11px]">
              Total Revenue Collected
            </span>
            <span className="px-1.5 py-0.2 bg-emerald-900 text-emerald-300 rounded font-mono text-[10px]">
              Confirmed Cash
            </span>
          </div>
          <div className="text-3xl font-bold font-mono text-white tabular-nums my-1">
            {formatKenyanShillings(totalRevenue)}
          </div>
          <p className="text-[11px] text-emerald-400 mt-2">
            Settled via M-Pesa, EFT Bank Transfer, or Cash receipts
          </p>
        </div>

        {/* Outstanding Receivables */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-amber-800">
              Outstanding Client Balances
            </span>
            <span className="px-1.5 py-0.2 bg-amber-50 text-amber-800 rounded font-mono text-[10px]">
              Due on Launch
            </span>
          </div>
          <div className="text-3xl font-bold font-mono text-amber-900 tabular-nums my-1">
            {formatKenyanShillings(totalOutstanding)}
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Remaining 50% balances on active development projects
          </p>
        </div>

        {/* Pending Verification */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold uppercase tracking-wider text-[11px] text-slate-600">
              Pending Transactions
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {pendingPayments.length} records
            </span>
          </div>
          <div className="text-3xl font-bold font-mono text-slate-800 tabular-nums my-1">
            {formatKenyanShillings(totalPending)}
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Awaiting bank clearance or M-Pesa statement confirmation
          </p>
        </div>
      </div>

      {/* Analytics Breakdown Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        {/* Month by month revenue */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
          <h4 className="font-bold text-slate-900 uppercase tracking-wide text-[11px] flex items-center gap-1.5">
            <BarChart2 className="w-3.5 h-3.5 text-emerald-600" />
            Revenue by Month (Confirmed)
          </h4>
          {Object.keys(revenueByMonth).length === 0 ? (
            <p className="text-slate-400 py-3">No confirmed payments yet.</p>
          ) : (
            <div className="space-y-1.5 pt-1">
              {Object.entries(revenueByMonth)
                .sort((a, b) => b[0].localeCompare(a[0]))
                .slice(0, 5)
                .map(([month, val]) => (
                  <div key={month} className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="font-mono text-slate-600">{month}</span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      {formatKenyanShillings(val)}
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Payment Channels */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
          <h4 className="font-bold text-slate-900 uppercase tracking-wide text-[11px] flex items-center gap-1.5">
            <PieChart className="w-3.5 h-3.5 text-slate-600" />
            Payment Channels
          </h4>
          {Object.keys(revenueByMethod).length === 0 ? (
            <p className="text-slate-400 py-3">No transactions recorded.</p>
          ) : (
            <div className="space-y-1.5 pt-1">
              {Object.entries(revenueByMethod).map(([method, val]) => (
                <div key={method} className="flex justify-between items-center py-1 border-b border-slate-100">
                  <span className="text-slate-600 truncate">{method}</span>
                  <span className="font-mono font-bold text-emerald-800 tabular-nums">
                    {formatKenyanShillings(val)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Top Clients by Cash Paid */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
          <h4 className="font-bold text-slate-900 uppercase tracking-wide text-[11px] flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-slate-600" />
            Top Clients by Revenue
          </h4>
          {Object.keys(revenueByClient).length === 0 ? (
            <p className="text-slate-400 py-3">No client transactions yet.</p>
          ) : (
            <div className="space-y-1.5 pt-1">
              {Object.entries(revenueByClient)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5)
                .map(([clientName, val]) => (
                  <div key={clientName} className="flex justify-between items-center py-1 border-b border-slate-100">
                    <span className="text-slate-700 truncate max-w-[150px]">{clientName}</span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      {formatKenyanShillings(val)}
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>

      {/* Transaction Ledger Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs space-y-3">
        {/* Table Filters */}
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-50/50">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by client or M-Pesa ref..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="all">All Channels</option>
              <option value="M-Pesa Paybill/Till">M-Pesa</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cash">Cash</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="all">All Categories</option>
              <option value="Deposit">Deposits</option>
              <option value="Project Balance">Project Balances</option>
              <option value="Maintenance">Maintenance Retainers</option>
            </select>

            <button
              onClick={onOpenNewPayment}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Payment</span>
            </button>
          </div>
        </div>

        {/* Ledger */}
        {filteredPayments.length === 0 ? (
          <div className="p-8">
            <EmptyState
              icon={Wallet}
              title="No payments recorded"
              description="Record verified M-Pesa, bank transfer, or cash deposits to keep an accurate cash flow ledger."
              actionLabel="Record First Payment"
              onAction={onOpenNewPayment}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Client Business</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Method & Ref</th>
                  <th className="py-3 px-4 text-right">Amount (KSh)</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPayments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-600 whitespace-nowrap">
                      {payment.paymentDate}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {payment.clientBusinessName}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {payment.category}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800 block">
                        {payment.paymentMethod}
                      </span>
                      {payment.transactionReference && (
                        <span className="font-mono text-[10px] text-slate-500">
                          Ref: {payment.transactionReference}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800 tabular-nums">
                      {formatKenyanShillings(payment.amount)}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-semibold font-mono ${
                          payment.paymentStatus === 'Confirmed'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}
                      >
                        {payment.paymentStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onEditPayment(payment)}
                          className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                          title="Edit transaction"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteId(payment.id)}
                          className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                          title="Delete transaction"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ConfirmModal
        isOpen={Boolean(deleteId)}
        title="Delete Payment Record"
        message="Are you sure you want to delete this payment record from the cash ledger?"
        confirmLabel="Delete"
        onConfirm={() => {
          if (deleteId) onDeletePayment(deleteId);
          setDeleteId(null);
        }}
        onClose={() => setDeleteId(null)}
      />
    </div>
  );
};
