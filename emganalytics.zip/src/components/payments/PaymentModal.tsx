import React, { useState, useEffect } from 'react';
import { X, Wallet, Check, AlertCircle, Building2, Calendar, Tag } from 'lucide-react';
import { Payment, PaymentMethod, PaymentCategory, Client } from '../../types';

interface PaymentModalProps {
  isOpen: boolean;
  payment?: Payment | null;
  targetClient?: Client | null;
  clients: Client[];
  onSave: (paymentData: Partial<Payment> & { clientId: string; amount: number }) => Promise<void>;
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  payment,
  targetClient,
  clients,
  onSave,
  onClose,
}) => {
  const [clientId, setClientId] = useState('');
  const [amount, setAmount] = useState<number>(17500);
  const [paymentDate, setPaymentDate] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('M-Pesa Paybill/Till');
  const [transactionReference, setTransactionReference] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'Confirmed' | 'Pending'>('Confirmed');
  const [category, setCategory] = useState<PaymentCategory>('Deposit');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (payment) {
      setClientId(payment.clientId);
      setAmount(payment.amount);
      setPaymentDate(payment.paymentDate || new Date().toISOString().split('T')[0]);
      setPaymentMethod(payment.paymentMethod || 'M-Pesa Paybill/Till');
      setTransactionReference(payment.transactionReference || '');
      setPaymentStatus(payment.paymentStatus || 'Confirmed');
      setCategory(payment.category || 'Deposit');
      setNotes(payment.notes || '');
    } else if (targetClient) {
      setClientId(targetClient.id);
      // Default to deposit or remaining balance
      const balance = targetClient.remainingBalance > 0 ? targetClient.remainingBalance : targetClient.agreedProjectPrice / 2;
      setAmount(balance || 17500);
      setPaymentDate(new Date().toISOString().split('T')[0]);
      setPaymentMethod('M-Pesa Paybill/Till');
      setTransactionReference('');
      setPaymentStatus('Confirmed');
      setCategory(targetClient.totalDepositPaid > 0 ? 'Project Balance' : 'Deposit');
      setNotes('');
    } else {
      setClientId(clients[0]?.id || '');
      setAmount(17500);
      setPaymentDate(new Date().toISOString().split('T')[0]);
      setPaymentMethod('M-Pesa Paybill/Till');
      setTransactionReference('');
      setPaymentStatus('Confirmed');
      setCategory('Deposit');
      setNotes('');
    }
  }, [payment, targetClient, clients, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId) {
      setError('Please select a client for this transaction.');
      return;
    }
    if (Number(amount) <= 0) {
      setError('Payment amount must be greater than zero.');
      return;
    }

    setSaving(true);
    setError(null);

    const clientObj = clients.find((c) => c.id === clientId);

    try {
      await onSave({
        id: payment?.id,
        clientId,
        clientBusinessName: clientObj?.businessName || 'Client Business',
        amount: Number(amount),
        currency: 'KSh',
        paymentDate,
        paymentMethod,
        transactionReference: transactionReference.trim(),
        paymentStatus,
        category,
        notes: notes.trim(),
      });
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to record payment.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-2xl my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {payment ? 'Edit Payment Record' : 'Record Confirmed Payment'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Record cash, M-Pesa, or bank remittance received from clients
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Client Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Client Business *
            </label>
            <select
              required
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
            >
              <option value="">-- Choose Client --</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.businessName} (Balance: KSh {c.remainingBalance.toLocaleString('en-KE')})
                </option>
              ))}
            </select>
          </div>

          {/* Amount & Currency */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Amount Received (KSh) *
              </label>
              <input
                type="number"
                required
                min="100"
                step="100"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono font-bold text-emerald-800 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Date *
              </label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Payment Method & Transaction Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Method *
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="M-Pesa Paybill/Till">M-Pesa (Till / Paybill)</option>
                <option value="Bank Transfer">Bank Transfer (EFT / RTGS)</option>
                <option value="Cash">Cash (Hand-to-Hand)</option>
                <option value="Cheque">Cheque</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                M-Pesa / Bank Reference Code
              </label>
              <input
                type="text"
                value={transactionReference}
                onChange={(e) => setTransactionReference(e.target.value)}
                placeholder="e.g. QKJ4920401"
                className="w-full px-3 py-2 text-xs font-mono uppercase border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Category & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as PaymentCategory)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
              >
                <option value="Deposit">Project Deposit (50%)</option>
                <option value="Project Balance">Final Project Balance (50%)</option>
                <option value="Maintenance">Monthly Maintenance Retainer</option>
                <option value="Add-on">Optional Scope Add-on</option>
                <option value="Other">Other Remittance</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Confirmation Status
              </label>
              <select
                value={paymentStatus}
                onChange={(e) => setPaymentStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
              >
                <option value="Confirmed">Confirmed (Funds in Account)</option>
                <option value="Pending">Pending Verification</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Payment Remarks & Receipt Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Sent via Safaricom M-Pesa Till 882010 at 11:45 AM"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 text-xs text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Recording...' : 'Record Payment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
