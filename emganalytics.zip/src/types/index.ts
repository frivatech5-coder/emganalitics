export type LeadStatus =
  | 'New'
  | 'Contacted'
  | 'Responded'
  | 'Interested'
  | 'Needs analysis'
  | 'Proposal sent'
  | 'Negotiating'
  | 'Won'
  | 'Lost'
  | 'Follow up later';

export interface Lead {
  id: string;
  businessName: string;
  contactPerson: string;
  phone: string;
  whatsapp: string;
  email: string;
  location: string;
  category: string;
  website?: string;
  socialMedia?: string;
  source: string;
  status: LeadStatus;
  estimatedBudget: number;
  potentialValue: number;
  assignedPackageId?: string;
  assignedPackageName?: string;
  notes: string;
  lastContactDate?: string;
  nextFollowUpDate?: string;
  convertedToClientId?: string;
  createdAt: string;
  updatedAt?: string;
  createdBy?: string;
}

export type ContactChannel =
  | 'Phone Call'
  | 'WhatsApp'
  | 'Email'
  | 'In-Person Meeting'
  | 'Demo Presentation'
  | 'Other';

export interface ContactLog {
  id: string;
  leadId: string;
  channel: ContactChannel;
  outcome: string;
  notes: string;
  date: string;
  createdAt: string;
  createdBy?: string;
}

export interface ServicePackage {
  id: string;
  name: string;
  price: number;
  description: string;
  pages: string;
  deliveryEstimate: string;
  supportPeriod: string;
  features: string[];
  exclusions: string[];
  optionalAddOns: string[];
  isRecurring: boolean;
  createdAt: string;
}

export type QuotationStatus =
  | 'Draft'
  | 'Sent'
  | 'Accepted'
  | 'Declined'
  | 'Expired'
  | 'Negotiating';

export interface QuotationItem {
  name: string;
  description?: string;
  price: number;
}

export interface Quotation {
  id: string;
  quoteNumber: string;
  leadId?: string;
  clientName: string;
  businessName: string;
  clientEmail: string;
  clientPhone: string;
  businessLocation?: string;
  services: QuotationItem[];
  addOns?: QuotationItem[];
  scopeAndDeliverables: string;
  totalPrice: number;
  depositType: 'percentage' | 'fixed';
  depositValue: number; // e.g. 50% or KSh 20,000
  depositAmount: number;
  balanceDue: number;
  validityDays: number;
  paymentTerms: string;
  status: QuotationStatus;
  sentDate?: string;
  acceptedDate?: string;
  notes?: string;
  createdAt: string;
  createdBy?: string;
}

export type ProjectStatus =
  | 'Awaiting deposit'
  | 'Ready to start'
  | 'In progress'
  | 'Awaiting client feedback'
  | 'Testing'
  | 'Completed'
  | 'On hold'
  | 'Cancelled';

export interface ProjectTask {
  id: string;
  title: string;
  completed: boolean;
  dueDate?: string;
}

export interface Client {
  id: string;
  leadId?: string;
  quotationId?: string;
  businessName: string;
  contactPerson: string;
  phone: string;
  whatsapp: string;
  email: string;
  location: string;
  agreedProjectPrice: number;
  totalDepositPaid: number;
  remainingBalance: number;
  domainInfo?: {
    domainName?: string;
    registrar?: string;
    renewalDate?: string;
  };
  hostingInfo?: {
    provider?: string;
    renewalDate?: string;
    plan?: string;
  };
  supportExpiryDate?: string;
  maintenanceStatus: 'None' | 'Active' | 'Paused' | 'Overdue';
  notes: string;
  createdAt: string;
  createdBy?: string;
}

export interface Project {
  id: string;
  clientId: string;
  clientBusinessName: string;
  title: string;
  scope: string;
  status: ProjectStatus;
  startDate: string;
  deadline: string;
  tasks: ProjectTask[];
  stagingUrl?: string;
  liveUrl?: string;
  createdAt: string;
  createdBy?: string;
}

export type PaymentMethod =
  | 'M-Pesa Paybill/Till'
  | 'Bank Transfer'
  | 'Cash'
  | 'Cheque'
  | 'Other';

export type PaymentCategory =
  | 'Deposit'
  | 'Project Balance'
  | 'Maintenance'
  | 'Add-on'
  | 'Other';

export interface Payment {
  id: string;
  clientId: string;
  clientBusinessName: string;
  projectId?: string;
  quotationId?: string;
  amount: number;
  currency: 'KSh' | string;
  paymentDate: string;
  paymentMethod: PaymentMethod;
  transactionReference?: string; // M-Pesa code or bank ref
  paymentStatus: 'Confirmed' | 'Pending';
  category: PaymentCategory;
  notes?: string;
  createdAt: string;
  createdBy?: string;
}

export type SubscriptionStatus = 'Active' | 'Paused' | 'Cancelled' | 'Overdue';

export interface Subscription {
  id: string;
  clientId: string;
  clientBusinessName: string;
  websiteUrl: string;
  monthlyFee: number;
  startDate: string;
  nextBillingDate: string;
  status: SubscriptionStatus;
  includedServices: string[];
  supportLimits: string;
  renewalNotes?: string;
  createdAt: string;
  createdBy?: string;
}

export interface PortfolioItem {
  id: string;
  name: string;
  category: string;
  liveUrl: string;
  previewUrl?: string;
  projectType: string;
  status: 'Concept demo' | 'Client project' | 'Completed project';
  featuresDemonstrated: string[];
  featuresTested: string[];
  relatedLeadId?: string;
  notes?: string;
  createdAt: string;
  createdBy?: string;
}

export interface FollowUpItem {
  lead: Lead;
  isOverdue: boolean;
  isDueToday: boolean;
  daysRemaining: number;
}

export interface BusinessMetrics {
  totalLeads: number;
  newLeads: number;
  interestedProspects: number;
  proposalsSent: number;
  dealsWon: number;
  dealsLost: number;
  totalActiveOpportunityValue: number;
  depositsReceived: number;
  outstandingBalances: number;
  totalRevenueReceived: number;
  monthlyRecurringRevenue: number;
  conversionRate: number;
}
